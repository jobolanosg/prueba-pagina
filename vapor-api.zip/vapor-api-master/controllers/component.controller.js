const logger = require('../helpers/logger')
const Component = require('../models/component')
const validator = require('validator')

let componentController = {
  getComponents: function (req, res) {
    Component.find((err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : An error has occurred.')
        return res.json({ success: false, msg: 'An error has occurred.' })
      }
      logger.log('info', 'success : true, msg : Components found.')
      return res.json({ success: true, components: result })
    })
  },
  newComponent: function (req, res) {
    Component.create({
      name: validator.trim(validator.escape(req.body.name))
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : The component could not be created.')
        return res.json({ success: false, msg: 'The component could not be created.' })
      }
      logger.log('info', 'success : true, msg : The component has been created correctly.')
      return res.json({ success: true, component: result })
    })
  },
  seeComponent: function (req, res) {
    Component.findById(validator.trim(validator.escape(req.params.id)), (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : The component does not exist.')
        return res.json({ success: false, msg: 'The component does not exist.' })
      }
      logger.log('info', 'success : true, msg : The component was found.')
      return res.json({ success: true, component: result })
    })
  },
  editComponent: function (req, res) {
    Component.findByIdAndUpdate(validator.trim(validator.escape(req.params.id)), {
      name: validator.trim(validator.escape(req.body.name))
    }, {
      new: true,
      upsert: true
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : true, msg : The component was not found and was created correctly.')
        return res.json({ success: true })
      }
      logger.log('info', 'success : true, msg : The component was found and updated correctly.')
      return res.json({ success: true, component: result })
    })
  },
  deleteComponent: function (req, res) {
    Component.findByIdAndRemove(validator.trim(validator.escape(req.params.id)), (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : The component was not found.')
        return res.json({ success: false, msg: 'The component was not found.' })
      }
      logger.log('info', 'success : true, msg : The component was deleted correctly.')
      return res.json({ success: true })
    })
  }
}

module.exports = componentController
