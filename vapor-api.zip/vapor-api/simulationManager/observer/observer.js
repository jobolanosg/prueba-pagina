/* eslint-disable no-inner-declarations */
const util = require('util')
const fs = require('fs')
const readdir = util.promisify(require('fs').readdir)
const path = require('path')
const mongodb = require('mongodb')
const MongoClient = require('mongodb').MongoClient

let settings = {
  useNewUrlParser: true
}
let url = 'mongodb://localhost:27017'
let dbName = 'SimulationResult'

MongoClient.connect(url, settings, (err, client) => {
  if (err) {
    console.log(err)
  } else {
    async function saveSimulation (simulationId, simulationInfo, archivePath, archiveName) {
      if (fs.existsSync(`${path.resolve(__dirname, `../simulation/${simulationId}${archivePath}${archiveName}`)}`)) {
        const db = client.db(dbName)
        let bucket = new mongodb.GridFSBucket(db, {
          bucketName: 'simulation',
          chunkSizeBytes: 1048576
        })
        fs.createReadStream(`${path.resolve(__dirname, `../simulation/${simulationId}${archivePath}${archiveName}`)}`)
          .pipe(bucket.openUploadStream(`${simulationId}-${archiveName}`, {
            aliases: [`${simulationId}`],
            metadata: simulationInfo
          })).on('error', function (error) {
            console.error(error)
          })
      } else {
        console.error('Nonexistent path')
      }
    }

    async function separateFiles (simulationId, simulationInfo) {
      const db = client.db('SimulationResult')

      let bucket = new mongodb.GridFSBucket(db, {
        bucketName: 'simulation',
        chunkSizeBytes: 1048576
      })

      bucket.find({
        'filename': new RegExp(`^${simulationId}`)
      }).toArray(async function (err, docs) {
        if (err) {
          console.log(err)
        }
        if (docs.length === 0) {
          // saveSimulation(simulationId, simulationInfo, '/Data/Results/', 'OUTPUT.EGRID')
          // saveSimulation(simulationId, simulationInfo, '/Data/Results/', 'OUTPUT.SMSPEC')
          // saveSimulation(simulationId, simulationInfo, '/Data/Results/', 'OUTPUT.UNRST')
          // saveSimulation(simulationId, simulationInfo, '/Data/Results/', 'OUTPUT.UNSMRY')
          const files = await readdir(`${path.resolve(__dirname, '../simulation')}/${simulationId}/Data/Results/VTKOutput`)
          files.forEach((value, index, array) => {
            saveSimulation(simulationId, simulationInfo, '/Data/Results/VTKOutput/', value)
          })
        } else {
          let bucket = new mongodb.GridFSBucket(db, {
            bucketName: 'simulation',
            chunkSizeBytes: 1048576
          })
          let idToDelete = docs.map(value => value._id)
          idToDelete.forEach(value => {
            bucket.delete(value, (err) => {
              if (err) {
                console.log(err)
              }
            })
          })
          // saveSimulation(simulationId, simulationInfo, '/Data/Results/', 'OUTPUT.EGRID')
          // saveSimulation(simulationId, simulationInfo, '/Data/Results/', 'OUTPUT.SMSPEC')
          // saveSimulation(simulationId, simulationInfo, '/Data/Results/', 'OUTPUT.UNRST')
          // saveSimulation(simulationId, simulationInfo, '/Data/Results/', 'OUTPUT.UNSMRY')
          const files = await readdir(`${path.resolve(__dirname, '../simulation')}/${simulationId}/Data/Results/VTKOutput`)
          files.forEach((value, index, array) => {
            saveSimulation(simulationId, simulationInfo, '/Data/Results/VTKOutput/', value)
          })
        }
      })
    }

    function observer () {
      try {
        let simulationCompletedQueue = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../queue/completed.json'), 'utf8')).simulationCompleted
        if (simulationCompletedQueue.length > 0) {
          let simulationToSave = simulationCompletedQueue.shift()
          fs.writeFileSync(path.resolve(__dirname, '../queue/completed.json'), JSON.stringify({
            simulationCompleted: simulationCompletedQueue
          }), 'utf8', (err) => {
            if (err) throw `Error updating the completed queue -> ${err}`
          })
          separateFiles(simulationToSave.id, simulationToSave.info)
        }
      } catch (e) {
        console.error(e)
      }
    }

    function greetings () {
      console.log('\x1b[33m%s\x1b[0m', `
      |￣￣￣￣￣￣￣￣￣￣￣￣|
          I am watching you.
      |＿＿＿＿＿＿＿＿＿＿＿＿|
            (\\__/)||
            (•ㅅ•)||
            /  　 づ`)
    }

    greetings()

    setInterval(observer, 1500)
  }
})
