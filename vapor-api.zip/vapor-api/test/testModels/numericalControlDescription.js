const path = require('path')
const chai = require('chai')

const sinon = require('sinon')
require('sinon-mongoose')
const numericalControlDescription = require(path.resolve('./test', '../models/numericalControlDescription'))

const expect = chai.expect

describe('Numerical Control Description Model Unit Tests', () => {
  it('Should return a "numericalControlDescription" object', (done) => {
    let numericalControlDescriptionMock = sinon.mock(numericalControlDescription)
    let expected = {
      simulation_id: 'Nudu4hKKyRcCPGW6yyG3w3bT',
      maxTimeStep: 125,
      minTimeStep: 54,
      initialTimeStep: 23,
      maxAllowedPressureChange: 213,
      maxAllowedSaturationChange: 41,
      maxAllowedMolChange: 12,
      accelerationFactor: 35,
      minIterations: 652,
      maxIterations: 3753,
      maxNumberOfCuts: 367,
      toleranceType: 'minimum',
      pressureTolerance: {
        value: 654,
        type: 'meters'
      },
      molTolerance: {
        value: 1312,
        type: 'meters'
      },
      saturationTolerance: {
        value: 396,
        type: 'meters'
      }
    }
    numericalControlDescriptionMock.expects('find').yields(null, expected)
    numericalControlDescription.find((err, result) => {
      numericalControlDescriptionMock.verify()
      numericalControlDescriptionMock.restore()
      expect(err).to.be.null
      expect(result.simulation_id).to.be.not.undefined
      expect(result.maxTimeStep).to.be.a('number')
      expect(result.minTimeStep).to.be.a('number')
      expect(result.initialTimeStep).to.be.a('number')
      expect(result.maxAllowedPressureChange).to.be.a('number')
      expect(result.maxAllowedSaturationChange).to.be.a('number')
      expect(result.maxAllowedMolChange).to.be.a('number')
      expect(result.accelerationFactor).to.be.a('number')
      expect(result.minIterations).to.be.a('number')
      expect(result.maxIterations).to.be.a('number')
      expect(result.maxNumberOfCuts).to.be.a('number')
      expect(result.toleranceType).to.be.a('string')
      expect(result.pressureTolerance).to.be.a('object')
      expect(result.molTolerance).to.be.a('object')
      expect(result.saturationTolerance).to.be.a('object')
      done()
    })
  })
})
