const express = require('express')
const temporary = express.Router()
const fieldController = require('../controllers/temporary.controller')
const authMiddleware = require('../middlewares/auth')
const passport = require('passport')

require('../middlewares/passport')(passport)

temporary.post('/temporary/save', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, fieldController.saveTemporary)

temporary.post('/temporary/get', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, fieldController.getTemporary)

module.exports = temporary
