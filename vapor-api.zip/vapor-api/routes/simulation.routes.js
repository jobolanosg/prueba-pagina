const express = require('express')
const simulation = express.Router()
const simulationController = require('../controllers/simulation.controller')
const authMiddleware = require('../middlewares/auth')
const passport = require('passport')

require('../middlewares/passport')(passport)

simulation.post('/simulation/', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsAdmin, simulationController.getSimulation)

simulation.post('/simulation/new', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, simulationController.newSimulation)

simulation.post('/simulation/execute/', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, simulationController.executeSimulation)

simulation.post('/simulation/fulminate/', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, simulationController.fulminateSimulation)

simulation.post('/simulation/download/', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, simulationController.downloadSimulation)

simulation.post('/simulation/check/', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, simulationController.checkSimulation)

// simulation.post('/simulation/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, simulationController.seeSimulation)

simulation.put('/simulation/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, simulationController.editSimulation)

simulation.delete('/simulation/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, simulationController.deleteSimulation)

simulation.post('/simulation/log/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, simulationController.logSimulation)

simulation.post('/simulation/error/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, simulationController.errorSimulation)

simulation.post('/simulation/remove/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, simulationController.removeSimulation)

simulation.post('/simulation/progress/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, simulationController.progressSimulation)

simulation.post('/simulation/wells/', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, simulationController.getDataFromWells)

module.exports = simulation
