import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgxsModule } from '@ngxs/store';
import { NgxsStoragePluginModule, StorageOption } from '@ngxs/storage-plugin';
import { AppRouting } from './app-routing';

import { AppComponent } from './app.component';

import { SimulationsService } from './service/simulations/simulations.service';
import { AuthService } from './service/auth/auth.service';
import { ComponentService } from './service/component/component.service';
import { DescriptionService } from './service/description/description.service';
import { ProjectsService } from './service/projects/projects.service';
import { UserService } from './service/user/user.service';

import { UserState } from './store/state/user.state';
import { ChartsModule } from '@progress/kendo-angular-charts';
import 'hammerjs';
import { NgxsReduxDevtoolsPluginModule } from '@ngxs/devtools-plugin';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    MDBBootstrapModule.forRoot(),
    NgxsModule.forRoot([
      UserState
    ]),
    NgxsStoragePluginModule.forRoot({ storage: StorageOption.SessionStorage}),
    NgxsReduxDevtoolsPluginModule.forRoot(),
    AppRouting,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ChartsModule
  ],
  exports: [],
  providers: [
    SimulationsService,
    AuthService,
    ComponentService,
    DescriptionService,
    ProjectsService,
    UserService
  ],
  bootstrap: [AppComponent]
})

export class AppModule { }
