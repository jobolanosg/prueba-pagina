import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

// store
import { Store } from '@ngxs/store';
import { UserState } from '../../store/state/user.state';

import { Component } from '../../models/component.model';
import { Response } from '../../models/response.model';

const headers: HttpHeaders = new HttpHeaders({
  'Content-Type': 'application/json'
});

@Injectable({
  providedIn: 'root'
})

export class ComponentService {

  public urlApp: string = environment.urlApi;

  constructor(private http: HttpClient, private store: Store) { }

  getComponents(): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApp}/component`,
      {
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  createComponet(name: Component['name']): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApp}/component/new`,
      {
        'name': name,
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  seeComponent(component_id: Component['_id']): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApp}/company/${component_id}`,
      {
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  updateComponent(component_id: Component['_id'], name: Component['name']): Observable<Response> {
    return this.http.put<Response>(
      `${this.urlApp}/component/${component_id}`,
      {
        'name': name,
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  deleteComponent() { }
}
