import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators/catchError';
import { tap } from 'rxjs/operators/tap';
import { Injectable } from '@angular/core';
import { Response } from '../../models/response.model';

import { Store } from '@ngxs/store';
import { LoginUser, LogoutUser, SaveUser } from '../../store/actions/user.actions';

import { User } from '../../models/user.model';

import { environment } from '../../environments/environment';

const headers = new HttpHeaders({
  'Content-Type': 'application/json'
});

@Injectable({
  providedIn: 'root'
})

export class AuthService {
  public urlApi: string = environment.urlApi;

  constructor(private http: HttpClient, private store: Store) { }

  addToken(userToken: User['token'], userId: User['_id'], user: { username: string; email: User['email'] }): void {
    this.store.dispatch(new SaveUser(user));
    this.store.dispatch(new LoginUser(userToken, userId));
  }

  removeToken(): void {
    this.store.dispatch(new LogoutUser());
  }

  postLogin(email: User['email'], password: User['password']): Observable<any> {
    return this.http.post<any>(`${this.urlApi}/user/login`,
      {
        'email': email,
        'password': password
      },
      { headers: headers })
      .pipe(
        tap(
          res => this.addToken(res.token, res._id, res.user)
        )
      );
  }
  postLogout(token: User['token']): Observable<Response> {
    return this.http.post<Response>(`${this.urlApi}/user/logout`,
      {
        'token': token
      },
      { headers: headers }).pipe(
        tap(
          () => this.removeToken()
        )
      );
  }
}
