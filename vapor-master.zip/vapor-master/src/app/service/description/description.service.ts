import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

import { Description } from '../../models/description.model';
import { Response } from '../../models/response.model';

// store
import { Store } from '@ngxs/store';
import { UserState } from '../../store/state/user.state';

const headers = new HttpHeaders({
  'Content-Type': 'application/json'
});

@Injectable({
  providedIn: 'root'
})

export class DescriptionService {

  public urlApp: string = environment.urlApi;

  constructor(private http: HttpClient, private store: Store) { }


  newDescription(reservoirDescription: Description['reservoirDescription'],
    fluidsDescription: Description['fluidsDescription'],
    rockFluidDescription: Description['rockFluidDescription'],
    initialConditionsDescription: Description['initialConditionsDescription'],
    numericalControlDescription: Description['numericalControlDescription'],
    wellsAndTimeDescription: Description['wellsAndTimeDescription'],
    settingsDescription: Description['settingsDescription']): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApp}/description/new`,
      {
        'reservoirDescription': reservoirDescription,
        'fluidsDescription': fluidsDescription,
        'rockFluidDescription': rockFluidDescription,
        'initialConditionsDescription': initialConditionsDescription,
        'numericalControlDescription': numericalControlDescription,
        'wellsAndTimeDescription': wellsAndTimeDescription,
        'settingsDescription': settingsDescription,
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }


  seeDescription(): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApp}/description`,
      {
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }


  editDescription(reservoirDescription: Description['reservoirDescription'],
    fluidsDescription: Description['fluidsDescription'],
    rockFluidDescription: Description['rockFluidDescription'],
    initialConditionsDescription: Description['initialConditionsDescription'],
    numericalControlDescription: Description['numericalControlDescription'],
    wellsAndTimeDescription: Description['wellsAndTimeDescription'],
    settingsDescription: Description['settingsDescription']): Observable<Response> {
    return this.http.put<Response>(
      `${this.urlApp}/description`,
      {
        'reservoirDescription': reservoirDescription,
        'fluidsDescription': fluidsDescription,
        'rockFluidDescription': rockFluidDescription,
        'initialConditionsDescription': initialConditionsDescription,
        'numericalControlDescription': numericalControlDescription,
        'wellsAndTimeDescription': wellsAndTimeDescription,
        'settingsDescription': settingsDescription,
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  temporalySave(SimulationId: string, data: any): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApp}/temporary/save`,
      {
        'simulation_id': SimulationId,
        'saved': data,
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  temporalyGet(SimulationId: string): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApp}/temporary/get`,
      {
        'simulation_id': SimulationId,
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

}
