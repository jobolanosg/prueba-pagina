import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import axios from 'axios';

import { Response } from '../../models/response.model';
import { User } from '../../models/user.model';

import { Store } from '@ngxs/store';
import { UserState } from '../../store/state/user.state';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';

const headers = new HttpHeaders({
  'Content-Type': 'application/json'
});

@Injectable({
  providedIn: 'root'
})

export class UserService {

  public urlApi: string = environment.urlApi;
  public getToken: string = this.store.selectSnapshot(UserState.getToken);

  constructor(private http: HttpClient, private store: Store) { }

  getUser(): Observable<Response> {
    return this.http.post<Response>(`${this.urlApi}/user`,
      {
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  newUser(name: User['name'], lastname: User['lastname'], role: User['role'], email: User['email'], password: User['password']): Observable<Response> {
    return this.http.post<Response>(`${this.urlApi}/user/new`,
      {
        'name': name,
        'lastname': lastname,
        'role': role,
        'email': email,
        'password': password,
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  seeUser(user_id: User['_id']): Observable<Response> {
    return this.http.post<Response>(`${this.urlApi}/user/${user_id}`,
      {
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  updateUser(user_id: User['_id'], name: User['name'], lastname: User['lastname'], role: User['role'], email: User['email'], password: User['password']): Observable<Response> {
    return this.http.put<Response>(`${this.urlApi}/user/${user_id}`,
      {
        'name': name,
        'lastname': lastname,
        'role': role,
        'email': email,
        'password': password,
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  deleteUser(user_id: User['_id']) {
    const deletedUsers: any = {
      'token': this.getToken
    };
    return axios.delete(`${this.urlApi}/user/${user_id}`, { data: deletedUsers });
  }
}
