import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import axios from 'axios';
import { AxiosPromise } from 'axios';
import { Observable } from 'rxjs/Observable';

// store
import { Store } from '@ngxs/store';
import { UserState } from '../../store/state/user.state';

// models
import { Response } from '../../models/response.model';
import { Project } from '../../models/project.model';

const headers = new HttpHeaders({
  'Content-Type': 'application/json'
});

@Injectable({
  providedIn: 'root'
})

export class ProjectsService {

  private idUser = this.store.selectSnapshot(UserState.getId);
  public urlApi = environment.urlApi;

  constructor(private http: HttpClient, private store: Store) { }

  getProjectsUser(): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApi}/user/${this.idUser}/project`,
      {
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  getSimulationsUser(): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApi}/user/${this.idUser}/simulation`,
      {
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }


  getProjects(): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApi}/project`,
      {
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  createProject(name: Project['name'], description: Project['description'], collaborators: Project['collaborators'], simulation: Project['simulations']): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApi}/project/new`,
      {
        'name': name,
        'description': description,
        'owner': this.idUser,
        'collaborators': collaborators,
        'simulations': simulation,
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  seeProject(project_id: Project['_id']): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApi}/project/${project_id}`,
      {
        'token': this.store.selectSnapshot(UserState.getToken)
      },
      { headers: headers });
  }

  updateProject(project_id: Project['_id'], name: Project['name'], description: Project['description'], collaborators: Project['collaborators'], simulation: Project['simulations']): AxiosPromise<Response> {
    const service: Project = {
      'name': name,
      'description': description,
      'owner': this.idUser,
      'collaborators': collaborators,
      'simulations': simulation,
      'token': this.store.selectSnapshot(UserState.getToken)
    };
    return axios.put(`${this.urlApi}/project/${project_id}`, service);
  }

  deleteProjects(project_id: Project['_id'], confirmation: any) {
    const deletedProject: any = {
      ...confirmation,
      'token': this.store.selectSnapshot(UserState.getToken)
    };
    return axios.delete(`${this.urlApi}/project/${project_id}`, { headers: { 'content-type': 'application/json' }, data: JSON.stringify(deletedProject) });
  }

}
