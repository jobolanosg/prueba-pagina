import { User } from '../../models/user.model';

export class SaveUser {
  static readonly type = '[User] Save User';

  constructor(public user: { username: string; email: User['email'] }) { }
}

export class LogoutUser {
  static readonly type = '[User] Logout User';

  constructor() { }
}

export class LoginUser {
  static readonly type = '[User] Login User';

  constructor(public userToken: string, public userId: string) { }
}
