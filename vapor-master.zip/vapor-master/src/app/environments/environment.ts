export const environment = {
  urlApi: 'http://localhost:3000/api'
};

