import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

export const appRouting: Routes = [
  {
    path: '',
    loadChildren: './component/login/login.module#LoginModule'
  },
  {
    path: 'contact',
    loadChildren: './component/contact/contact.module#ContactModule'
  },
  {
    path: 'mysimulations',
    loadChildren: './component/simulations/simulations.module#SimulationsModule'
  },
  {
    path: 'mysimulations/projects/:project/edit-simulations/:simulations',
    loadChildren: './component/simulations/edit-simulations/edit-simulations.module#EditSimulationsModule'
  },
  {
    path: 'result',
    loadChildren: './component/simulations/result/result.module#ResultModule'
  },
  {
    path: 'user',
    loadChildren: './component/user-interface/user-interface.module#UserInterfaceModule'
  }
];

export const AppRouting: ModuleWithProviders = RouterModule.forRoot(appRouting);
