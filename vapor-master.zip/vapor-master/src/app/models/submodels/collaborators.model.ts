import { User } from '../user.model';

export interface Collaborators {
  user_id?: User['_id'];
  permission?: string;
}
