import { FluidsDescriptionByFlowUnit } from './fluids-description-by-flow-unit.model';
import { Simulations } from '../simulations.model';

export interface FluidsDescription {
  simulations_id?: Simulations['_id'];
  fluidsDescriptionByFlowUnit?: Array<FluidsDescriptionByFlowUnit>;
}
