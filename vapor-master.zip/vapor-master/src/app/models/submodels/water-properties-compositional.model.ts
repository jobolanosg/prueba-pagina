export interface WaterPropertiesCompositional {
  referencePressure?: number;
  volumetricFactor?: number;
  viscosity?: number;
  viscosityDependencePressure?: number;
  density?: number;
  acentricFactor?: number;
  criticalPressure?: number;
  criticalTemperature?: number;
  criticalVolume?: number;
  molecularWeight?: number;
}
