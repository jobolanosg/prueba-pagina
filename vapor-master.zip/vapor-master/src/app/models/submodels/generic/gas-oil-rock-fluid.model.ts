export interface GasOilRockFluid {
  gasSaturation?: Array<Number>;
  gasRelativePermeability?: Array<Number>;
  oilRelativePermeability?: Array<Number>;
  gasOilCapillaryPressure?: Array<Number>;
}
