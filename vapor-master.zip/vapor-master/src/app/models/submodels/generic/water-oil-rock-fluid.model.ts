export interface WaterOilRockFluid {
  waterSaturation?: Array<Number>;
  waterRelativePermeability?: Array<Number>;
  oilRelativePermeability?: Array<Number>;
  oilWaterCapillaryPressure?: Array<Number>;
}
