export interface Type {
  type?: string;
  values?: Array<Number>;
}
