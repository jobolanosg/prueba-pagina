import { Type } from './generic/type.model';
import { GravcapequDataByFlowUnit } from './generic/gravcapequ-data-by-flow-unit.model';
import { Simulations } from '../simulations.model';

export interface InitialConditionsDescription {
  simulations_id?: Simulations['_id'];
  type?: string;
  gravcapequDataByFlowUnit?: Array<GravcapequDataByFlowUnit>;
  pressure?: Type;
  waterSaturation?: Type;
  gasSaturation?: Type;
  globalComposition?: Type;
}
