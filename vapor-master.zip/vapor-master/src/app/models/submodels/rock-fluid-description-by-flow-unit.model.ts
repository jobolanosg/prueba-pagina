import { GasOilRockFluid } from './generic/gas-oil-rock-fluid.model';
import { WaterOilRockFluid } from './generic/water-oil-rock-fluid.model';

export interface RockFluidDescriptionByFlowUnit {
  gasOilRockFluid?: GasOilRockFluid;
  waterOilRockFluid?: WaterOilRockFluid;
}
