import { Type } from './generic/type.model';

export interface Mesh {
  type?: string;
  internalRadius?: number;
  externalRadius?: number;
  iLength?: Type;
  jLength?: Type;
  kLength?: Type;
  top?: Type;
  iPermeability?: Type;
  jPermeability?: Type;
  kPermeability?: Type;
  porosity?: Type;
  activeBlock?: Type;
  flowUnit?: Type;
}
