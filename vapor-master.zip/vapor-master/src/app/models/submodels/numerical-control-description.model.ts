import { Simulations } from '../simulations.model';

export interface NumericalControlDescription {
  simulations_id?: Simulations['_id'];
  maxTimeStep?: number;
  minTimeStep?: number;
  initialTimeStep?: number;
  maxAllowedPressureChange?: number;
  maxAllowedSaturationChange?: number;
  maxAllowedMolChange?: number;
  accelerationFactor?: number;
  minIterations?: number;
  maxIterations?: number;
  maxNumberOfCuts?: number;
  toleranceType?: string;
  tolerance?: number;
}
