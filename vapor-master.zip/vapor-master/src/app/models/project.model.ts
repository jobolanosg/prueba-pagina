import { User } from './user.model';
import { Simulations } from './simulations.model';
import { Collaborators } from './submodels/collaborators.model';
import { Token } from './submodels/token.model';

export interface Project {
  _id?: string;
  name: string;
  description?: string;
  owner: User['_id'];
  collaborators: Array<Collaborators>;
  simulations: Array<Simulations['_id']>;
  token: Token['token'];
}
