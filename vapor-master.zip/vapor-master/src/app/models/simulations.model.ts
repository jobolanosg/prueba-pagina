import { Collaborators } from './submodels/collaborators.model';
import { Token } from './submodels/token.model';

export interface Simulations {
  _id?: string;
  name: string;
  description?: string;
  project_id?: string;
  collaborators?: [Collaborators];
  type?: string;
  token?: Token['token'];
}
