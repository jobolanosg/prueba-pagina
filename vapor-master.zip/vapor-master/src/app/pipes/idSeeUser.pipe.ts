import { Pipe, PipeTransform } from '@angular/core';
import { UserService } from '../service/user/user.service';

@Pipe({ name: 'idSeeUser' })
export class IdSeeUserPipe implements PipeTransform {
  constructor(private user: UserService) { }

  transform(value: string, args: string[]): any {
    if (!value) { return value; }
    return this.user.seeUser(value);
  }
}
