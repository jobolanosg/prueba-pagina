import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../service/user/user.service';
import { Store } from '@ngxs/store';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-manage',
  templateUrl: './user-manage.component.html',
  styleUrls: ['./user-manage.component.scss'],
})
export class UserManageComponent implements OnInit {
  userGridData: any[] = [];
  userList: Array<any> = [];
  opened = false;
  isNew = false;
  deleted = false;
  currentUser: { name: string; lastname: string; email: string; role: string };
  rowIndex: any;
  constructor(private user: UserService, private router: Router, private store: Store) { }

  ngOnInit() {
    this.updateUsers();
  }

  updateUsers() {
    this.user.getUser().subscribe((res) => {
      if (res.success) {
        this.userList = res.users.map((current, index: Number) => ({ hint: index, ...current }));
        for (let i = 0; i < this.userList.length; i++) {
          this.userGridData[i] = { username: `${this.userList[i].name} ${this.userList[i].lastname}`, email: this.userList[i].email, role: this.userList[i].role };
        }
      } else {
        this.userGridData = [];
      }
    });
  }

  public addHandler() {
    this.currentUser = { name: '', lastname: '', email: '', role: '' };
    this.isNew = true;
    this.opened = true;
  }

  public editHandler({ rowIndex }) {
    this.currentUser = { name: this.userList[rowIndex].name, lastname: this.userList[rowIndex].lastname, email: this.userList[rowIndex].email, role: this.userList[rowIndex].role };
    this.isNew = false;
    this.opened = true;
    this.rowIndex = rowIndex;
  }

  public cancelHandler() {
    this.currentUser = { name: '', lastname: '', email: '', role: '' };
    this.close();
  }

  public saveHandler() {
    if (this.isNew) {
      this.user.newUser(this.currentUser.name, this.currentUser.lastname, this.currentUser.role, this.currentUser.email, '1234567890').subscribe((res) => { });
    } else {
      this.user.updateUser(this.userList[this.rowIndex]._id, this.currentUser.name, this.currentUser.lastname, this.currentUser.role, this.currentUser.email, this.userList[this.rowIndex].password).subscribe((res) => { });
    }
    this.currentUser = { name: '', lastname: '', email: '', role: '' };
    this.close();
  }

  public close() {
    this.opened = false;
    this.isNew = false;
    this.deleted = false;
    this.rowIndex = 0;
    setTimeout(() => {
      window.location.reload();
    }, 100);
  }

  public removeHandler({ rowIndex }) {
    this.deleted = true;
    this.rowIndex = rowIndex;
  }

  public onStateChange(state: any) {
    this.userGridData = [];
    this.updateUsers();
  }

  delete(choice: Boolean) {
    if (choice) {
      this.user.deleteUser(this.userList[this.rowIndex]._id);
    } else {
      this.deleted = false;
      this.rowIndex = 0;
    }
    this.close();
  }
}
