import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCheckboxModule } from '@angular/material/checkbox';

import { GridModule } from '@progress/kendo-angular-grid';
import { DropDownListModule, MultiSelectModule } from '@progress/kendo-angular-dropdowns';
import { WindowModule, DialogModule } from '@progress/kendo-angular-dialog';
import { TextBoxModule } from '@progress/kendo-angular-inputs';
import { UserInterfaceComponent } from './user-interface.component';
import { ProfileComponent } from './profile/profile.component';
import { UserManageComponent } from './user-manage/user-manage.component';
import { UserInterfaceRoutes } from './user-interface.routing';
import { NavModule } from '../nav/nav.module';

@NgModule({
  declarations: [
    ProfileComponent,
    UserInterfaceComponent,
    UserManageComponent
  ],
  imports: [
    UserInterfaceRoutes,
    GridModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    DropDownListModule,
    MultiSelectModule,
    MatTabsModule,
    MatCheckboxModule,
    WindowModule, DialogModule,
    TextBoxModule,
    NavModule
  ],
  entryComponents: [
  ]
})

export class UserInterfaceModule { }
