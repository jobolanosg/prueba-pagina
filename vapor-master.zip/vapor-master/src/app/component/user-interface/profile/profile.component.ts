import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../service/user/user.service';
import { UserState } from 'src/app/store/state/user.state';
import { Store } from '@ngxs/store';
import { Router } from '@angular/router';

import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  userForm: FormGroup;
  userInfo: any = {};
  newpassword;
  repeatpassword;
  hidePassword = true;
  hidePassword2 = true;
  id;
  name;
  lastname;

  constructor(private user: UserService, private router: Router, private store: Store, private formBuilder: FormBuilder) {
    this.createForm();
  }

  ngOnInit() {
    this.userInfo = this.store.selectSnapshot<{ username: string; email: string; role: string; }>(UserState.getUser);
    this.id = this.store.selectSnapshot(UserState.getId);
    this.name = this.userInfo.username.split(' ')[0];
    this.lastname = this.userInfo.username.split(' ')[1];
  }

  createForm() {
    this.userForm = this.formBuilder.group({
      'newpassword': new FormControl(this.newpassword, [Validators.required]),
      'repeatpassword': new FormControl(this.repeatpassword, [Validators.required])
    });
  }

  onClickSubmit(newPassword, repeatPassword) {

    if (newPassword && repeatPassword && newPassword === repeatPassword) {
      this.user.updateUser(this.id, this.name, this.lastname, this.userInfo.role, this.userInfo.email, newPassword).subscribe((res) => {
        if (res.success) {
          console.log('res', res);
        } else {
          console.error('error with service');
        }
      });
    } else {
      console.log('error with passwords');
    }
  }

}
