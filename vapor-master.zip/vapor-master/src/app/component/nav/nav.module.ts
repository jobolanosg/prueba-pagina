import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NavComponent } from '../../component/nav/nav.component';
import { SimulationManagerComponent, SimulationManagerListComponent, SimulationLogComponent } from '../../component/simulation-manager/simulation-manager.component';
import { SimulationManagerService } from '../../service/simulation-manager/simulation-manager.service';
import { MatBottomSheetModule } from '@angular/material';
import {MatListModule} from '@angular/material/list';
import {MatTableModule} from '@angular/material/table';
import { SimulationDetailComponent } from '../../component/simulation-manager/simulation-detail/simulation-detail.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import {MatDialogModule} from '@angular/material/dialog';


@NgModule({
  imports: [
    CommonModule,
    MDBBootstrapModule.forRoot(),
    MatBottomSheetModule,
    MatListModule,
    MatTableModule,
    MatDialogModule
  ],
  declarations: [
    NavComponent,
    SimulationManagerComponent,
    SimulationManagerListComponent,
    SimulationDetailComponent,
    SimulationLogComponent
  ],
  exports: [
    NavComponent,
    MDBBootstrapModule
  ],
  providers: [
    SimulationManagerService
  ],
  entryComponents: [
    SimulationManagerComponent,
    SimulationManagerListComponent,
    SimulationLogComponent
  ]
})
export class NavModule { }
