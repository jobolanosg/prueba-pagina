import { Component, OnInit, OnDestroy, Inject, ChangeDetectorRef } from '@angular/core';
import { MatBottomSheet, MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { SimulationManagerService } from '../../service/simulation-manager/simulation-manager.service';
import { UserState } from 'src/app/store/state/user.state';
import { Store, Select } from '@ngxs/store';
import { Observable } from 'rxjs';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  templateUrl: './simulation-log.component.html',
  styleUrls: ['./simulation-log.component.scss']
})
export class SimulationLogComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) public data: any) {}

  ngOnInit() {
  }

}

@Component({
  selector: 'app-simulation-manager-list',
  templateUrl: './simulation-manager-list.component.html',
  styleUrls: ['./simulation-manager-list.component.scss']
})
export class SimulationManagerListComponent implements OnInit, OnDestroy {

  runningSimulations = [];
  isAnyRunningSimulation = false;
  displayedColumns = ['name', 'status', 'actions'];
  @Select(UserState.getRunningSimulations) runningSimulations$: Observable<any>;
  simulationsStatusInterval;
  currentClass = this;

  constructor(private bottomSheetRef: MatBottomSheetRef<SimulationManagerListComponent>, private simulationManagerService: SimulationManagerService,
    private dialog: MatDialog, private changeDetectorRefs: ChangeDetectorRef) { }

  ngOnInit() {
    this.getRunningSimulations();
    this.simulationsStatusInterval = setInterval(() => {
      this.statusloop();
    }, 3000);
  }

  async statusloop() {
    for (let i = 0; i < this.runningSimulations.length; i++) {
      this.simulationManagerService.getDataFromRunningSimulation(this.runningSimulations[i].simulation_id).subscribe(data => {
        this.simulationManagerService.updateStatusFromRunningSimulation(this.runningSimulations[i].simulation_id, data.status).subscribe(() => {
          this.runningSimulations[i].status = data.status;
          this.changeDetectorRefs.detectChanges();
        });
      });
    }
  }

  ngOnDestroy() {
    clearInterval(this.simulationsStatusInterval);
  }

  openLink(event: MouseEvent): void {
    this.bottomSheetRef.dismiss();
    event.preventDefault();
  }

  getRunningSimulations() {
    this.runningSimulations$.subscribe(runningSimulationsObject => {
      this.runningSimulations = runningSimulationsObject;
      if (this.runningSimulations) {
        if (this.runningSimulations.length > 0) {
          this.isAnyRunningSimulation = true;
        } else {
          this.isAnyRunningSimulation = false;
        }
      } else {
        this.isAnyRunningSimulation = false;
      }
    });
  }

  removeRunningSimulation(id: string) {
    this.simulationManagerService.removeRunningSimulation(id).subscribe();
    this.getRunningSimulations();
  }

  fulminateRunningSimulation(id: string) {
    this.simulationManagerService.removeRunningSimulation(id).subscribe();
    this.getRunningSimulations();
    this.simulationManagerService.fulminateRunningSimulation(id).subscribe();
  }

  seeLog(id: string) {
    this.simulationManagerService.seeLog(id).subscribe(log => {
      this.dialog.open(SimulationLogComponent, {
        data: {
          log: log.log
        }
      });
    });
  }

  seeError(id: string) {
    this.simulationManagerService.seeError(id).subscribe(error => {
      this.dialog.open(SimulationLogComponent, {
        data: {
          log: error.error
        }
      });
    });
  }

}

@Component({
  selector: 'app-simulation-manager',
  templateUrl: './simulation-manager.component.html',
  styleUrls: ['./simulation-manager.component.scss']
})
export class SimulationManagerComponent implements OnInit {

  constructor(private bottomSheet: MatBottomSheet) { }

  ngOnInit() {
  }

  openBottomSheet(): void {
    this.bottomSheet.open(SimulationManagerListComponent);
  }

}


