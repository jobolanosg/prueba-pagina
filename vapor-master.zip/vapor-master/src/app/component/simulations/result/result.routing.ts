import { Routes, RouterModule } from '@angular/router';

import { ResultComponent } from './result.component';
import { AuthGuard } from '../../../guards/auth.guard';

const resultRoutes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    canActivate: [AuthGuard],
    component: ResultComponent
  }
];

export const ResultRoutes = RouterModule.forChild(resultRoutes);
