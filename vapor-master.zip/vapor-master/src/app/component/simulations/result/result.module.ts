import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NavModule } from '../../nav/nav.module';

import { ResultComponent } from './result.component';
import { ResultRoutes } from './result.routing';
import { WellsComponent } from './wells/wells.component';
// import { PropertiesNameExtended } from '../../../pipes/propertiesNameExtended.pipe';

import { RippleModule } from '@progress/kendo-angular-ripple';
import { ChartsModule } from '@progress/kendo-angular-charts';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material';
import { MatCheckboxModule } from '@angular/material';

// Charts

// import { FusionChartsModule } from 'angular-fusioncharts';
// import * as FusionCharts from 'fusioncharts';
// import * as Charts from 'fusioncharts/fusioncharts.charts';
// import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
// import * as Powercharts from 'fusioncharts/fusioncharts.powercharts';

// FusionChartsModule.fcRoot(
//   FusionCharts,
//   Charts,
//   FusionTheme,
//   Powercharts
// );

import * as PlotlyJS from 'plotly.js/dist/plotly.js';
import { PlotlyModule } from 'angular-plotly.js';

PlotlyModule.plotlyjs = PlotlyJS;

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ResultRoutes,
    ChartsModule,
    MatCardModule,
    MatCheckboxModule,
    MatExpansionModule,
    RippleModule,
    PlotlyModule,
    NavModule
  ],
  declarations: [
    ResultComponent,
    WellsComponent

  ]
})

export class ResultModule { }
