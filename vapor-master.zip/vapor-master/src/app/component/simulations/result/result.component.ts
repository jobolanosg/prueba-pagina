import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { SimulationsService } from '../../../service/simulations/simulations.service';
import { Store } from '@ngxs/store';
import { UserState } from '../../../store/state/user.state';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.scss']
})
export class ResultComponent implements OnInit {
  @ViewChild('appendTo', { read: ViewContainerRef, static: true }) public appendTo: ViewContainerRef;

  variables;
  wells;

  constructor(private simulationService: SimulationsService, private store: Store) { }

  ngOnInit() {
    const simulationId = this.store.selectSnapshot(UserState.getSimulationsId);
    this.simulationService.getDataFromWells(simulationId).subscribe((wells: any) => {
      this.wells = wells.wells;
    });
  }

}
