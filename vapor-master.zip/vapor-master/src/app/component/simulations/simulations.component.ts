import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { ProjectsService } from '../../service/projects/projects.service';
import { SimulationsService } from '../../service/simulations/simulations.service';
import { UserService } from '../../service/user/user.service';
import { Router, Event, NavigationStart, NavigationEnd } from '@angular/router';
import { SaveProject, SaveSimulations, SaveProjectId, SaveSimulationsId } from '../../store/actions/app.actions';
import { SaveProjectDescription, SaveSimulationsDescription, SaveSimulationsType } from '../../store/actions/app.actions';
import { RemoveProject, RemoveProjectId, RemoveSimulations } from '../../store/actions/app.actions';
import { RemoveSimulationsId, RemoveProjectDescription, RemoveSimulationsDescription, RemoveSimulationsType } from '../../store/actions/app.actions';
import { UserState } from '../../store/state/user.state';
import { Store } from '@ngxs/store';
import * as fileSaver from 'file-saver';
import { Project } from '../../models/project.model';
import { Simulations } from '../../models/simulations.model';
import { DropDownFilterSettings } from '@progress/kendo-angular-dropdowns';
import { NotificationService } from '@progress/kendo-angular-notification';

@Component({
  selector: 'app-simulations',
  templateUrl: './simulations.component.html',
  styleUrls: ['./simulations.component.scss']
})

export class SimulationsComponent implements OnInit {
  public opened = false;
  public deleted = false;
  public edited = false;
  public projectList;
  public projectName;
  public projectDescription;
  public simulationsName;
  public simulationsDescription;
  public data;
  public selectedValue;
  public userList;
  simulationsType = ['Chemical Gas EOR', 'Thermal CEOR', 'Chemical EOR'];
  selectedSimulationsType = 'Thermal CEOR';
  selectedUser;
  projectsTogether;
  projectHeight;
  projectHidden;
  projectResponse;
  displayedData: any = [{ name: '', description: '', collaborators: [{}], createdAt: '', updatedAt: '' }];
  coWorkers = [];
  downloadDisabled = true;
  public filterSettings: DropDownFilterSettings = {
    caseSensitive: false,
    operator: 'contains'
  };

  @ViewChild('appendTo', { read: ViewContainerRef, static: true }) public appendTo: ViewContainerRef;


  showLoadingIndicator;
  constructor(private router: Router, private notificationService: NotificationService, private projectsService: ProjectsService,
    private simulationsService: SimulationsService, private userService: UserService, private store: Store) {
    this.router.events.subscribe((routerEvent: Event) => {

      if (routerEvent instanceof NavigationStart) {
        this.showLoadingIndicator = true;
      }

      if (routerEvent instanceof NavigationEnd) {
        this.showLoadingIndicator = false;
      }
    });
  }

  ngOnInit() {
    this.updateAll();
    this.store.dispatch(new RemoveProject());
    this.store.dispatch(new RemoveProjectId());
    this.store.dispatch(new RemoveProjectDescription());
    this.store.dispatch(new RemoveSimulations());
    this.store.dispatch(new RemoveSimulationsId());
    this.store.dispatch(new RemoveSimulationsDescription());
    this.store.dispatch(new RemoveSimulationsType());
  }

  public close(): void {
    this.opened = false;
    this.deleted = false;
    this.edited = false;
  }

  public open(): void {
    this.opened = true;
  }

  updateAll() {
    this.projectsService.getSimulationsUser().subscribe(res => {
      this.standardizeTree(res.projects);
      this.projectResponse = res.projects;
      const projectResponse = res.projects;
      this.projectsTogether = projectResponse.map((value) => {
        const simulations_ids = value.simulations.map<any>((simulationsValue: any): any => {
          return simulationsValue._id;
        });
        return { name: value.name, id: value._id, description: value.description, simulations: simulations_ids };
      });
      this.projectList = projectResponse.map((value) => {
        return value.name;
      });
    });
  }

  reconfig() {
    const projectParent = this.projectsTogether.filter((current) => current.id === this.displayedData[0].project_id);
    this.router.navigate([`/mysimulations/projects/${projectParent[0].name}/edit-simulations/${this.store.selectSnapshot(UserState.getSimulations)}`]);
  }

  onSelected(data): void {
    const projectData = this.projectResponse.filter((value) => {
      return value.name === data;
    });
    if (projectData.length === 0) {
      let simulationsList = this.projectResponse.map((projectValue) => {
        return projectValue.simulations;
      });
      simulationsList = simulationsList.flat();
      const simulationsListFilter = simulationsList.filter((simulationsValue) => {
        return simulationsValue.name === data;
      });
      this.displayedData = simulationsListFilter;
      this.store.dispatch(new SaveSimulations(this.displayedData[0].name.toLowerCase()));
      this.store.dispatch(new SaveSimulationsId(this.displayedData[0]._id.toLowerCase()));
      this.store.dispatch(new SaveSimulationsDescription(this.displayedData[0].description.toLowerCase()));
      this.store.dispatch(new SaveSimulationsType(this.selectedSimulationsType));
      this.simulationsService.checkSimulations(this.displayedData[0]._id).subscribe((res: any) => {
        this.downloadDisabled = !res.success;
      });
    } else {
      this.store.dispatch(new SaveProject(projectData[0].name.toLowerCase()));
      this.store.dispatch(new SaveProjectId(projectData[0]._id.toLowerCase()));
      this.store.dispatch(new SaveProjectDescription(projectData[0].description.toLowerCase()));
      this.displayedData = projectData;
    }
    this.projectHeight = '50vh';
    this.projectHidden = 'visible';
  }

  sendProject(): void {
    this.projectsService.createProject(this.projectName, this.projectDescription, [], []).subscribe(res => {
      if (res.success) {
        this.store.dispatch(new SaveProject(res.project.name.toLowerCase()));
        this.store.dispatch(new SaveProjectId(res.project._id.toLowerCase()));
        this.store.dispatch(new SaveProjectDescription(res.project.description.toLowerCase()));

        const projectId: string = res.project._id;
        const collaborators: Simulations['collaborators'] = [{}];
        this.simulationsService.createSimulations(this.simulationsName, this.simulationsDescription, projectId, collaborators, this.selectedSimulationsType).subscribe((response: any) => {
          if (response.success) {
            this.store.dispatch(new SaveSimulations(response.simulations.name.toLowerCase()));
            this.store.dispatch(new SaveSimulationsId(response.simulations._id.toLowerCase()));
            this.store.dispatch(new SaveSimulationsDescription(response.simulations.description.toLowerCase()));
            this.store.dispatch(new SaveSimulationsType(this.selectedSimulationsType));

            const simulationsArray: Array<string> = [];
            simulationsArray.push(response.simulations._id);
            this.projectsService.updateProject(projectId, this.projectName, this.projectDescription, [], simulationsArray);
          }
        });
      }
    });
  }

  sendSimulations(projectData): void {

    this.store.dispatch(new SaveProject(projectData[0].name.toLowerCase()));
    this.store.dispatch(new SaveProjectId(projectData[0].id));
    this.store.dispatch(new SaveProjectDescription(projectData[0].description.toLowerCase()));

    const projectId: string = projectData[0].id;
    const collaborators: Simulations['collaborators'] = [{}];
    this.simulationsService.createSimulations(this.simulationsName, this.simulationsDescription, projectId, collaborators, this.selectedSimulationsType).subscribe((response: any) => {
      if (response.success) {
        this.store.dispatch(new SaveSimulations(response.simulations.name.toLowerCase()));
        this.store.dispatch(new SaveSimulationsId(response.simulations._id.toLowerCase()));
        this.store.dispatch(new SaveSimulationsDescription(response.simulations.description.toLowerCase()));
        this.store.dispatch(new SaveSimulationsType(this.selectedSimulationsType));

        const simulationsArray: Array<string> = projectData[0].simulations;
        simulationsArray.push(response.simulations._id);
        this.projectsService.updateProject(projectId, projectData[0].name, projectData[0].description, [], simulationsArray);
      }
    });
  }

  addProjectDescription(value: string): void { this.projectDescription = value.toLowerCase(); }

  addProjectName(value: string): void { this.projectName = value.toLowerCase(); }

  addSimulationsDescription(value: string): void { this.simulationsDescription = value.toLowerCase(); }

  addSimulationsName(value: string): void { this.simulationsName = value.toLowerCase(); }

  public submit(): void {
    this.sendProject();
    this.router.navigate([`/mysimulations/projects/${this.projectName}/edit-simulations/${this.simulationsName}`]);
    this.close();
  }

  public create(): void {
    const projectData: Array<Project> = this.projectsTogether.filter((value) => {
      return value.name === this.selectedValue;
    });
    this.sendSimulations(projectData);
    this.router.navigate([`/mysimulations/projects/${this.selectedValue}/edit-simulations/${this.simulationsName}`]);
  }

  standardizeTree(projects): void {
    if (projects === undefined || projects.length === 0) {
      this.data = [
        {
          text: 'Projects not found',
          items: []
        }
      ];
    } else {
      const ProjectsArraylength = projects.length;
      const ProjectsArray = [];
      for (let projectIndex = 0; projectIndex < ProjectsArraylength; projectIndex++) {
        ProjectsArray[projectIndex] = {
          text: projects[projectIndex].name,
          items: []
        };
        const SimulationsArrayLength = projects[projectIndex].simulations.length;
        const itemsArray = [];
        for (let simulationsIndex = 0; simulationsIndex < SimulationsArrayLength; simulationsIndex++) {
          itemsArray[simulationsIndex] = {
            text: projects[projectIndex].simulations[simulationsIndex].name
          };
        }
        ProjectsArray[projectIndex].items = itemsArray;
      }
      this.data = [{
        text: 'Projects',
        items: ProjectsArray
      }];
    }
  }

  delete() {
    this.projectHeight = '0vh';
    this.projectHidden = 'hidden';
    this.deleted = true;
  }

  readyToDelete(email: string, password: string) {
    if (this.displayedData[0] && (Object.keys(this.displayedData[0])).includes('project_id')) {
      this.simulationsService.deleteSimulations(this.displayedData[0]._id, { email: email, password: password }).then((res) => {
        this.displayedData = [];
        this.selectedUser = [];
        this.updateAll();
      });
    } else {
      this.projectsService.deleteProjects(this.displayedData[0]._id, { email: email, password: password }).then((res) => {
        this.displayedData = [];
        this.selectedUser = [];
        this.updateAll();
      });
    }
    this.deleted = false;
  }

  edit() {
    this.projectHeight = '0vh';
    this.projectHidden = 'hidden';
    this.edited = true;
  }

  readyToEdit(name: string, description: string) {
    if (this.displayedData[0] && (Object.keys(this.displayedData[0])).includes('project_id')) {
      this.simulationsService.updateSimulations(this.displayedData[0]._id, name, description, this.displayedData[0].project_id, this.displayedData[0].collaborators, this.displayedData[0].type).then((res) => {
        this.displayedData = [];
        this.selectedUser = [];
        this.updateAll();
      });
    } else {
      this.projectsService.updateProject(this.displayedData[0]._id, name, description, this.displayedData[0].collaborators, this.displayedData[0].simulations).then((res) => {
        this.displayedData = [];
        this.selectedUser = [];
        this.updateAll();
      });
    }
    this.edited = false;
  }

  Download(idToDownload) {
    this.notificationService.show({
      appendTo: this.appendTo,
      content: 'Your files are being downloaded',
      cssClass: 'download-notification',
      animation: { type: 'fade', duration: 400 },
      position: { horizontal: 'right', vertical: 'top' },
      type: { style: 'info', icon: true },
      closable: true
    });
    this.simulationsService.downloadSimulations(idToDownload).subscribe((res: any) => {
      fileSaver.saveAs(res, idToDownload + '.zip');
    });
  }
}
