import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SettingsComponent } from './settings.component';

import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatCardModule } from '@angular/material';

import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonModule } from '@progress/kendo-angular-buttons';
import { DropDownListModule, MultiSelectModule } from '@progress/kendo-angular-dropdowns';
import { TabStripModule } from '@progress/kendo-angular-layout';
import { DateRangeModule, DatePickerModule, TimePickerModule, DateInputModule } from '@progress/kendo-angular-dateinputs';
import { NumericTextBoxModule, TextBoxModule } from '@progress/kendo-angular-inputs';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    GridModule,
    ButtonModule,
    DropDownListModule,
    MultiSelectModule,
    TabStripModule,
    DateRangeModule,
    DatePickerModule,
    TimePickerModule,
    DateInputModule,
    NumericTextBoxModule,
    TextBoxModule,
    MatCardModule
  ],
  declarations: [
    SettingsComponent
  ],
  exports: [
    SettingsComponent
  ]
})
export class SettingsModule { }
