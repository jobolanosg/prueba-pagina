import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { UserState } from '../../../../store/state/user.state';
import { Store } from '@ngxs/store';
import { ComponentService } from '../../../../service/component/component.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})


export class SettingsComponent implements OnInit {
  @Input() settingsData: any;
  @Output() settingsDataChange: EventEmitter<string[]> = new EventEmitter();
  optionSimulationsType = '';
  workUnitsItems = ['Field', 'SI', 'Lab'];
  fluidsModelItems = ['Extended Black Oil', 'Compositional'];
  selectedWorkUnits;
  selectedFluidsModel = 'Compositional';
  componentsItems;
  componentValue;
  flowUnitsSelected: Array<string> = [];
  nanoparticleSelect = true;
  surfactantSelect = false;
  polymerSelect = false;
  foamerSelect = false;

  constructor(private componentService: ComponentService, private store: Store) { }

  ngOnInit() {
    this.optionSimulationsType = this.store.selectSnapshot(UserState.getSimulationsType);
    this.componentService.getComponents().subscribe(response => {
      this.componentsItems = response.components;
    });
    this.selectedWorkUnits = 'Field';
    this.selectedFluidsModel = 'Compositional';
    this.nanoparticleSelect = true;
    this.surfactantSelect = this.settingsData.surfactantSelect;
    this.polymerSelect = this.settingsData.polymerSelect;
    this.foamerSelect = this.settingsData.foamerSelect;
    this.componentValue = this.settingsData.componentSelect;
    this.flowUnitsSelected = this.settingsData.flowUnitsSelect;
  }

  selectionChange(data) {
    this.settingsData.selectedWorkUnits = 'Field';
    this.settingsData.selectedFluidsModel = this.selectedFluidsModel;
    this.settingsData.nanoparticleSelect = true;
    this.settingsData.surfactantSelect = this.surfactantSelect;
    this.settingsData.polymerSelect = this.polymerSelect;
    this.settingsData.foamerSelect = this.foamerSelect;
    this.settingsData.componentSelect = this.componentValue;
    this.settingsData.flowUnitsSelect = this.flowUnitsSelected;
    this.settingsDataChange.emit(this.settingsData);
  }
  surfactantSelectChange(event) {
    this.surfactantSelect = event.checked;
    this.selectionChange(event);
  }
  nanoparticleSelectChange(event) {
    this.nanoparticleSelect = event.checked;
    this.selectionChange(event);
  }
  polymerSelectChange(event) {
    this.polymerSelect = event.checked;
    this.selectionChange(event);
  }
  foamerSelectChange(event) {
    this.foamerSelect = event.checked;
    this.selectionChange(event);
  }


}
