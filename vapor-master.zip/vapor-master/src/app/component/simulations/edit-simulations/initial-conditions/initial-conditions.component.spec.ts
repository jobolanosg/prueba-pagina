import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InitialConditionsComponent } from './initial-conditions.component';

describe('InitialConditionsComponent', () => {
  let component: InitialConditionsComponent;
  let fixture: ComponentFixture<InitialConditionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InitialConditionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InitialConditionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
