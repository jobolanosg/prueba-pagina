import { Component, OnInit, Input, Output, EventEmitter, DoCheck } from '@angular/core';

@Component({
  selector: 'app-initial-conditions',
  templateUrl: './initial-conditions.component.html',
  styleUrls: ['./initial-conditions.component.scss']
})
export class InitialConditionsComponent implements OnInit, DoCheck {

  constructor() { }

  @Input() settingsConfiguration: any;
  @Input() fluidsConfiguration: any;
  @Input() reservoirConfiguration: any;
  @Input() initialConditionsData: any;
  @Output() initialConditionsDataChange: EventEmitter<any> = new EventEmitter();
  @Output() notification: EventEmitter<any> = new EventEmitter();
  unityMeasure = '';
  unityPressure = '';
  unityTemperature = '';
  panelOpenState = false;
  typeSelectedSetted = '';
  public type: Array<string>;
  public inputType: Array<string> = ['Constant for all blocks', 'Varying in K direction'];
  selectedType = '';
  pressure: any = {
    select: '',
    text: ''
  };
  globalComposition: any = {
    select: '',
    data: []
  };
  gasSaturation: any = {
    select: '',
    text: ''
  };
  waterSaturation: any = {
    select: '',
    text: ''
  };
  temperature: any = {
    select: '',
    text: ''
  };
  flowUnitSpecified = { id: 0, referenceTemperature: '', thermalGradient: '', referencePressure: '', referenceDepth: '', gasOil: '', oilWater: '', ResidualGasZone: false, ResidualWaterZone: false };
  flowUnit: any[];
  kBlocks: number[] = [1];
  numberBlocks = 1;
  componentList: string[];
  settings = {
    startCols: 0,
    rowHeaders: true,
    colHeaders: true,
    autoWrapRow: false,
    autoWrapCol: false,
    startRows: 0,
    minSpareCols: 0,
    minSpareRows: 0,
    minCols: 0,
    sortEmptyCells: false,
    autoColumnSize: { syncLimit: '100%', useHeaders: true },
    height: 200,
    width: 740,
    contextMenu: ['row_above', 'row_below', 'remove_row'],
  };

  settingsGlobal = {
    startCols: 0,
    rowHeaders: true,
    colHeaders: true,
    autoWrapRow: false,
    autoWrapCol: false,
    startRows: 0,
    minSpareCols: 0,
    minSpareRows: 0,
    minCols: 0,
    autoColumnSize: { syncLimit: '100%', useHeaders: true },
    height: 50,
    width: 740,
    contextMenu: ['row_above', 'row_below', 'remove_row'],
  };

  ngDoCheck() {
    if (this.settingsConfiguration.selectedFluidsModel === 'Extended Black Oil') {
      if (this.selectedType === 'Direct Assigment') {
        this.typeSelectedSetted = 'DirectExtended';
      } else if (this.selectedType === 'Gravitational and Capillary Equilibrium') {
        this.typeSelectedSetted = 'GravitationalExtended';
      } else {
        this.typeSelectedSetted = '';
      }
    }
    if (this.settingsConfiguration.selectedFluidsModel === 'Compositional') {
      if (this.selectedType === 'Direct Assigment') {
        this.typeSelectedSetted = 'DirectCompositional';
      } else if (this.selectedType === 'Gravitational and Capillary Equilibrium - Composition With Depth') {
        this.typeSelectedSetted = 'GravitationalCompositional';
      } else {
        this.typeSelectedSetted = '';
      }
    }

    if (this.globalComposition.select === 'Varying in K direction') {
      this.kBlocks = Array(this.numberBlocks).fill(1).map((current, index) => current + index);

      if (this.globalComposition.data.length < this.numberBlocks) {
        while (this.globalComposition.data.length < this.numberBlocks) {
          this.globalComposition.data.push({});
        }
      } else if (this.globalComposition.data.length > this.numberBlocks) {
        while (this.globalComposition.data.length > this.numberBlocks) {
          this.globalComposition.data.pop();
        }
      }
    } else {
      this.kBlocks = [1];
      this.globalComposition.data.length = 1;
    }
  }

  ngOnInit() {
    this.unitsMeasurement();
    if (this.settingsConfiguration.selectedFluidsModel === 'Extended Black Oil') {
      this.componentList = [''];
    } else {
      if (this.fluidsConfiguration.components && this.fluidsConfiguration.components.componentList && this.fluidsConfiguration.components.componentList.length > 0) {
        this.componentList = this.fluidsConfiguration.components.componentList;
      } else {
        this.componentList = [''];
      }
    }

    if (this.reservoirConfiguration.numberBlock && this.reservoirConfiguration.numberBlock.KDirection) {
      this.numberBlocks = Number(this.reservoirConfiguration.numberBlock.KDirection);
    }

    if (this.settingsConfiguration.selectedFluidsModel && this.settingsConfiguration.selectedFluidsModel === 'Compositional') {
      this.type = ['Direct Assigment', 'Gravitational and Capillary Equilibrium - Composition With Depth'];
    } else {
      this.type = ['Direct Assigment', 'Gravitational and Capillary Equilibrium'];
    }
    this.selectedType = this.initialConditionsData.selectedType;
    let flowUnitCount = 0;
    if (this.settingsConfiguration.flowUnitsSelect) {
      flowUnitCount = this.settingsConfiguration.flowUnitsSelect.length;
    }

    if (this.initialConditionsData.globalComposition) {
      this.globalComposition = this.initialConditionsData.globalComposition;
    } else {
      this.globalComposition = { select: '', data: [{}] };
    }
    this.initialConditionsData.pressure ? this.pressure = this.initialConditionsData.pressure : this.pressure = { select: '', text: '' };
    this.initialConditionsData.gasSaturation ? this.gasSaturation = this.initialConditionsData.gasSaturation : this.gasSaturation = { select: '', text: '' };
    this.initialConditionsData.waterSaturation ? this.waterSaturation = this.initialConditionsData.waterSaturation : this.waterSaturation = { select: '', text: '' };
    this.initialConditionsData.temperature ? this.temperature = this.initialConditionsData.temperature : this.temperature = { select: '', text: '' };
    if (this.initialConditionsData.flowUnit) {
      this.flowUnit = this.initialConditionsData.flowUnit;
    } else {
      this.flowUnit = Array(flowUnitCount);
      for (let i = 0; i < flowUnitCount; i++) {
        this.flowUnit[i] = { ...this.flowUnitSpecified, id: i, globalComposition: [{}] };
      }
    }
    this.typeSelected();
  }

  valueChange(data) {
    this.initialConditionsData.selectedType = this.selectedType;
    this.initialConditionsData.pressure = this.pressure;
    this.initialConditionsData.globalComposition = this.globalComposition;
    this.initialConditionsData.waterSaturation = this.waterSaturation;
    this.initialConditionsData.gasSaturation = this.gasSaturation;
    this.initialConditionsData.temperature = this.temperature;
    this.initialConditionsData.flowUnit = this.flowUnit;
    this.initialConditionsDataChange.emit(this.initialConditionsData);
  }

  typeSelected() {
    if (this.settingsConfiguration.selectedFluidsModel) {
    } else {
      this.notification.emit({ text: 'A fluid model was not selected in the settings section', style: 'error', width: 150, height: 90 });
    }
  }

  trackFlowBy(index: number, flowUnit: any): number {
    return flowUnit.id;
  }

  unitsMeasurement() {
    if (this.settingsConfiguration.selectedWorkUnits === 'Field') {
      this.unityMeasure = 'ft';
      this.unityTemperature = '°F';
      this.unityPressure = 'psi';
    } else if (this.settingsConfiguration.selectedWorkUnits === 'SI') {
      this.unityMeasure = 'm';
      this.unityTemperature = 'K';
      this.unityPressure = 'kpa';
    } else if (this.settingsConfiguration.selectedWorkUnits === 'Lab') {
      this.unityMeasure = 'cm';
      this.unityTemperature = 'K';
      this.unityPressure = 'psi';
    }
  }
}
