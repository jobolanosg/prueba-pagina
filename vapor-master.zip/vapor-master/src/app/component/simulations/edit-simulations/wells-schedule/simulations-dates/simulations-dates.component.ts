import { Component, OnInit, DoCheck, Output, Input, EventEmitter } from '@angular/core';
import { orderBy } from '@progress/kendo-data-query';
import * as moment from 'moment';

@Component({
  selector: 'app-simulations-dates',
  templateUrl: './simulations-dates.component.html',
  styleUrls: ['./simulations-dates.component.scss']
})
export class SimulationsDatesComponent implements OnInit, DoCheck {

  @Input() settingsConfiguration: any;
  @Input() wellsScheduleData: any;
  @Output() wellsScheduleDataChange: EventEmitter<any> = new EventEmitter();

  dateRangeHeight = '0';
  dateHeight = '0';
  dateHidden;
  dateRangeHidden;
  rangeDate = { start: null, end: null };
  workUnitsType;
  date;
  time;
  intervalsDatesNumber;
  DateData: Array<{ date: Object; days: number }> = [];
  SimulationData;
  dateStartRange;
  timeStartRange;
  dateEndRange;
  timeEndRange;

  constructor() { }

  ngOnInit() {
    this.DateData = this.wellsScheduleData.simulationDates ? this.wellsScheduleData.simulationDates : [];
    if (this.settingsConfiguration.selectedWorkUnits === 'Field' || this.settingsConfiguration.selectedWorkUnits === 'SI') {
      this.workUnitsType = 'Days';
    } else {
      this.workUnitsType = 'Minutes';
    }
    this.prepareData(this.orderData());
  }

  ngDoCheck() {
    if (this.settingsConfiguration.selectedWorkUnits === 'Field' || this.settingsConfiguration.selectedWorkUnits === 'SI') {
      this.workUnitsType = 'Days';
    } else {
      this.workUnitsType = 'Minutes';
    }
  }

  selectionChange(data) {
    this.wellsScheduleData.simulationDates = this.SimulationData;
    this.wellsScheduleDataChange.emit(this.wellsScheduleData);
  }

  pushDate(dateSettled): void {
    const orderedData = this.orderData();
    let days = 0;
    if (orderedData.length > 0) {
      days = moment(dateSettled).diff(orderedData[0].date, this.workUnitsType.toLowerCase(), true);
    }
    this.DateData.push({
      date: moment(dateSettled).toDate(),
      days: days
    });
    this.prepareData(this.orderData());
  }

  checkDate() {
    if (this.date !== undefined || this.date !== null || this.time !== undefined || this.time !== null) {
      const dateSettled = moment().set({ 'year': this.date.getFullYear(), 'month': this.date.getMonth(), 'date': this.date.getDate(), 'hour': this.time.getHours(), 'minute': this.time.getMinutes(), 'second': this.time.getSeconds(), 'millisecond': this.time.getMilliseconds() });
      this.date = null;
      this.time = null;
      if (this.DateData.filter(date => moment(date.date).isSame(dateSettled)).length === 0) {
        this.DateData.push({
          date: dateSettled.toDate(),
          days: 0
        });
      }
      this.prepareData(this.orderData());
    }
  }

  orderData() {
    if (this.DateData === []) {
      return this.DateData;
    } else {
      return orderBy(this.DateData, [{ field: 'date', dir: 'asc' }]);
    }
  }

  prepareData(data: any) {
    if (data.length < 2) {
      this.SimulationData = data;
    } else {
      const orderedDates = [];
      for (let i = 0; i < data.length; i++) {
        // orderedDates.push({
        //   date: data[i].date,
        //   days: moment(data[i].date).diff(data[0].date, this.workUnitsType.toLowerCase(), true)
        // });
        data[i].date = moment(data[i].date, 'YYYY-MM-DD').toDate();
        data[i].days = moment(data[i].date).diff(data[0].date, 'ms', true) / 86400000;
      }
      this.SimulationData = data;
    }
    this.selectionChange('data');
    this.date = null;
    this.time = null;
  }

  addDate() {
    this.dateHidden = 'visible';
    this.dateRangeHeight = '0';
    this.dateRangeHidden = 'hidden';
    this.dateHeight = '50vh';

  }

  AddDatesRange() {
    this.dateRangeHidden = 'visible';
    this.dateHeight = '0';
    this.dateHidden = 'hidden';
    this.dateRangeHeight = '50vh';

  }

  // checkRangeDate() {
  //   if (this.rangeDate.start === undefined || this.rangeDate.start === null || this.rangeDate.end === undefined || this.rangeDate.end === null) {
  //   } else {
  //     const dateInterval = Math.abs(moment(this.rangeDate.start).diff(moment(this.rangeDate.end), this.workUnitsType.toLowerCase()));
  //     if (dateInterval < 2) {
  //       this.maxInterval = 3;
  //     } else {
  //       this.maxInterval = dateInterval + 1;
  //     }
  //   }
  // }

  setDataRanges() {
    const firstDate = moment().set({ 'year': this.dateStartRange.getFullYear(), 'month': this.dateStartRange.getMonth(), 'date': this.dateStartRange.getDate(), 'hour': this.timeStartRange.getHours(), 'minute': this.timeStartRange.getMinutes(), 'second': this.timeStartRange.getSeconds(), 'millisecond': this.timeStartRange.getMilliseconds() });
    const lastDate = moment().set({ 'year': this.dateEndRange.getFullYear(), 'month': this.dateEndRange.getMonth(), 'date': this.dateEndRange.getDate(), 'hour': this.timeEndRange.getHours(), 'minute': this.timeEndRange.getMinutes(), 'second': this.timeEndRange.getSeconds(), 'millisecond': this.timeEndRange.getMilliseconds() });
    if (lastDate.isAfter(firstDate)) {
      const dateInterval = Math.abs(moment(firstDate).diff(moment(lastDate), 'ms'));
      const delta = dateInterval / (this.intervalsDatesNumber - 1);
      for (let i = 0; i < this.intervalsDatesNumber; i++) {
        if (this.DateData.filter(date => moment(date.date).isSame(firstDate)).length === 0) {
          this.DateData.push({
            date: firstDate.toDate(),
            days: (delta * i) / 86400000
          });
        }
        firstDate.add(delta, 'ms');
      }
      this.dateStartRange = null;
      this.timeStartRange = null;
      this.dateEndRange = null;
      this.timeEndRange = null;
      this.intervalsDatesNumber = null;
      this.prepareData(this.orderData());
    } else if (lastDate.isSame(firstDate)) {
      alert('Star and final dates are the same');
    } else {
      alert('Final date must be greater than start date');
    }
  }

  removeHandlerDate(data) {
    const newData = this.SimulationData.filter((value, index) => {
      return index !== data.rowIndex;
    });
    this.DateData = newData;
    this.prepareData(this.orderData());
  }
}
