import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { WellsScheduleComponent } from './wells-schedule.component';

import { TabStripModule } from '@progress/kendo-angular-layout';
import { HotTableModule } from '@handsontable/angular';
import { DropDownListModule, MultiSelectModule } from '@progress/kendo-angular-dropdowns';
import { DateRangeModule, DatePickerModule, TimePickerModule, DateInputModule } from '@progress/kendo-angular-dateinputs';
import { NumericTextBoxModule, TextBoxModule } from '@progress/kendo-angular-inputs';
import { GridModule } from '@progress/kendo-angular-grid';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatExpansionModule } from '@angular/material/expansion';
import { ScheduleTableComponent } from './schedule-table/schedule-table.component';
import { PerforationsTableComponent } from './perforations-table/perforations-table.component';
import { InjectionFluidCompositionTableComponent } from './injection-fluid-composition-table/injection-fluid-composition-table.component';
import { SimulationsDatesComponent } from './simulations-dates/simulations-dates.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HotTableModule,
    TabStripModule,
    MatFormFieldModule,
    MatInputModule,
    DropDownListModule,
    MultiSelectModule,
    MatExpansionModule,
    DateRangeModule,
    DatePickerModule,
    TimePickerModule,
    DateInputModule,
    NumericTextBoxModule,
    TextBoxModule,
    GridModule
  ],
  declarations: [
    WellsScheduleComponent,
    ScheduleTableComponent,
    PerforationsTableComponent,
    InjectionFluidCompositionTableComponent,
    SimulationsDatesComponent
  ],
  exports: [
    WellsScheduleComponent
  ]
})
export class WellsScheduleModule { }
