import { Component, OnInit, Input, OnDestroy, Output, EventEmitter, DoCheck } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-perforations-table',
  templateUrl: './perforations-table.component.html',
  styleUrls: ['./perforations-table.component.scss']
})
export class PerforationsTableComponent implements OnInit, OnDestroy, DoCheck {

  @Input() settingsConfiguration: any;
  @Input() wellsScheduleData: any;
  @Output() wellsScheduleDataChange: EventEmitter<any> = new EventEmitter();
  @Input() deleteWellEvent: Observable<number>;
  @Input() addWellEvent: Observable<number>;

  typeSelectedSetted;
  selectDate = [];
  private deleteWellSubscription: any;
  private addWellSubscription: any;
  perforations: any[];
  settingsWells = {
    rowHeaders: true,
    colHeaders: true,
    minSpareRows: 1,
    minSpareCols: 0,
    autoWrapRow: false,
    autoWrapCol: false,
    startRows: 1,
    contextMenu: ['row_above', 'row_below', 'remove_row'],
  };

  constructor() { }

  ngOnInit() {
    if (this.wellsScheduleData.scheduleDates && this.wellsScheduleData.scheduleDates.length > 0) {
      this.selectDate = this.wellsScheduleData.scheduleDates;
    }

    if (this.wellsScheduleData && this.wellsScheduleData.perforations && this.wellsScheduleData.perforations.length === this.wellsScheduleData.wells.length) {
      this.perforations = this.wellsScheduleData.perforations;
    } else {
      if (this.wellsScheduleData.wells && this.wellsScheduleData.wells.length) {
        this.perforations = Array(this.wellsScheduleData.wells.length);
        for (let i = 0; i < this.wellsScheduleData.wells.length; i++) {
          const currentProperties = {
            name: this.wellsScheduleData.wells[i].name,
            id: i,
            tableData: []
          };
          currentProperties.tableData.push(this.tableObject(i));
          this.perforations[i] = currentProperties;
        }
      }
    }

    this.deleteWellSubscription = this.deleteWellEvent.subscribe((index) => {
      this.perforations.splice(index, 1);
    });

    this.addWellSubscription = this.addWellEvent.subscribe((index) => {
      this.perforations.push({ name: this.wellsScheduleData.wells[index].name, id: index, tableData: Array(1).fill(this.tableObject(index)) });
    });
  }

  ngOnDestroy() {
    this.deleteWellSubscription.unsubscribe();
    this.addWellSubscription.unsubscribe();
  }

  ngDoCheck(): void {
    for (let wellNameIndex = 0; wellNameIndex < this.wellsScheduleData.wells.length; wellNameIndex++) {
      this.perforations[wellNameIndex].name = this.wellsScheduleData.wells[wellNameIndex].name;
    }
  }

  getKeys(obj) {
    const keys = Object.keys(obj[0]);
    keys.shift();
    return keys;
  }

  getMaxPerforation(index: number) {
    const perforations = this.getPerforations();
    const allPerforations = perforations[index];
    return Math.max(...allPerforations);
  }

  getPerforations() {
    if (this.wellsScheduleData.schedule && this.wellsScheduleData.schedule.length > 0) {
      const perforationsNumber = this.wellsScheduleData.schedule.map((currentSchedule, currentIndex) => {
        const perforations = currentSchedule.tableData.filter((value) => {
          return value[`numberOfPerforations${currentIndex}`] !== null;
        }).map((value) => {
          return value[`numberOfPerforations${currentIndex}`];
        });
        return perforations;
      });
      return perforationsNumber;
    } else {
      return [0];
    }
  }

  valueChange(data) {
    this.wellsScheduleData.perforations = this.perforations;
    this.wellsScheduleDataChange.emit(this.wellsScheduleData);
  }

  tableObject(index: number): any {
    const maxPerforations = this.getMaxPerforation(index);
    const tableObject = {};
    Object.defineProperty(tableObject, `datePerforations${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    if (maxPerforations) {
      for (let i = 1; i < maxPerforations + 1; i++) {
        Object.defineProperty(tableObject, `perforation${index}-${i}`, {
          value: '',
          writable: true,
          enumerable: true,
          configurable: true
        });
      }
    }
    return tableObject;
  }

}
