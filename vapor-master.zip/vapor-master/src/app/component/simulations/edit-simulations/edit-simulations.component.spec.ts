import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditSimulationsComponent } from './editsimulations.component';

describe('EditSimulationsComponent', () => {
  let component: EditSimulationsComponent;
  let fixture: ComponentFixture<EditSimulationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditSimulationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditSimulationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
