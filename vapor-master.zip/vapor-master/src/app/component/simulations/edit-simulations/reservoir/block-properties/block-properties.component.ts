import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-block-properties',
  templateUrl: './block-properties.component.html',
  styleUrls: ['./block-properties.component.scss']
})
export class BlockPropertiesComponent implements OnInit {
  @Input() settingsConfiguration: any;
  @Input() selectedGridTypeConfiguration: string;
  @Input() blockPropertiesData: any;
  @Output() blockPropertiesChange: EventEmitter<any> = new EventEmitter();
  @Output() notification: EventEmitter<any> = new EventEmitter();
  panelOpenState = false;
  enterBlockProperties = false;
  unityMeasure = '';
  poreCompressibility: string;
  referencePressure: string;
  matrixDensity: string;
  public layerTop: Array<string> = ['Constant for all blocks', 'Specified for all blocks'];
  public permeabilityOptions: Array<string> = ['Constant for all blocks', 'Varying in K direction', 'Specified for all blocks'];
  public porosityOptions: Array<string> = ['Constant for all blocks', 'Varying in K direction', 'Specified for all blocks'];
  public activeBlocksOptions: Array<string> = ['Constant for all blocks', 'Varying in K direction', 'Specified for all blocks'];
  public flowUnitOptions: Array<string> = ['Constant for all blocks', 'Varying in K direction'];
  firstLayerTop: any;
  permeability: any = {
    IDirection: {
      select: '',
      text: ''
    },
    JDirection: {
      select: '',
      text: ''
    },
    KDirection: {
      select: '',
      text: ''
    }
  };
  porosity: any = {
    select: '',
    text: ''
  };
  activeBlocks: any = {
    select: '',
    text: ''
  };
  flowUnit: any = {
    select: '',
    text: ''
  };

  constructor() { }

  ngOnInit() {
    this.unitsMeasurement();
    this.poreCompressibility = this.blockPropertiesData.poreCompressibility;
    this.referencePressure = this.blockPropertiesData.referencePressure;
    this.matrixDensity = this.blockPropertiesData.matrixDensity;
    this.blockPropertiesData.firstLayerTop ? this.firstLayerTop = this.blockPropertiesData.firstLayerTop : this.firstLayerTop = { select: '', text: '' };
    this.blockPropertiesData.enterBlockProperties ? this.enterBlockProperties = this.blockPropertiesData.enterBlockProperties : this.enterBlockProperties = false;
    this.blockPropertiesData.porosity ? this.porosity = this.blockPropertiesData.porosity : this.porosity = { select: '', text: '' };
    this.blockPropertiesData.activeBlocks ? this.activeBlocks = this.blockPropertiesData.activeBlocks : this.activeBlocks = { select: '', text: '' };
    this.blockPropertiesData.flowUnit ? this.flowUnit = this.blockPropertiesData.flowUnit : this.flowUnit = { select: '', text: '' };
    if (this.blockPropertiesData.permeability) {
      if (this.blockPropertiesData.permeability.IDirection) {
        this.permeability.IDirection = this.blockPropertiesData.permeability.IDirection;
      }
      if (this.blockPropertiesData.permeability.JDirection) {
        this.permeability.JDirection = this.blockPropertiesData.permeability.JDirection;
      }
      if (this.blockPropertiesData.permeability.KDirection) {
        this.permeability.KDirection = this.blockPropertiesData.permeability.KDirection;
      }
    } else {
      this.permeability = {
        IDirection: {
          select: '',
          text: ''
        },
        JDirection: {
          select: '',
          text: ''
        },
        KDirection: {
          select: '',
          text: ''
        }
      };
    }
  }

  unitsMeasurement() {
    if (this.settingsConfiguration.selectedWorkUnits === 'Field') {
      this.unityMeasure = 'ft';
    } else if (this.settingsConfiguration.selectedWorkUnits === 'SI') {
      this.unityMeasure = 'm';
    } else if (this.settingsConfiguration.selectedWorkUnits === 'Lab') {
      this.unityMeasure = 'cm';
    }
  }
  clearData(stringToClear): string[] {
    return stringToClear.split(/[ ,]+/).filter((value) => {
      return value !== '\n' && value !== '';
    });
  }

  valueChange(data) {
    this.blockPropertiesData.poreCompressibility = this.poreCompressibility;
    this.blockPropertiesData.referencePressure = this.referencePressure;
    this.blockPropertiesData.matrixDensity = this.matrixDensity;
    this.blockPropertiesData.firstLayerTop = this.firstLayerTop;
    this.blockPropertiesData.enterBlockProperties = this.enterBlockProperties;
    this.blockPropertiesData.permeability = this.permeability;
    this.blockPropertiesData.porosity = this.porosity;
    this.blockPropertiesData.activeBlocks = this.activeBlocks;
    this.blockPropertiesData.flowUnit = this.flowUnit;
    if (data.target && data.target.name === 'IPermeabilityDirectionText') {
      const iPermeabilityTextArray = this.clearData(this.permeability.IDirection.text);
      const validateData = iPermeabilityTextArray.every((value: any): boolean => {
        return value >= 0;
      });
      if (validateData) {
        this.blockPropertiesData.permeability.IDirection = { select: this.permeability.IDirection.select, text: iPermeabilityTextArray.toString() };
      } else {
        this.blockPropertiesData.permeability.IDirection = { select: this.permeability.IDirection.select, text: iPermeabilityTextArray.toString() };
        this.notification.emit({ text: 'error Permeability IDirection', style: 'warning', width: 150, height: 90 });
      }
    }

    if (data.target && data.target.name === 'JPermeabilityDirectionText') {
      const jPermeabilityTextArray = this.clearData(this.permeability.JDirection.text);
      const validateData = jPermeabilityTextArray.every((value: any): boolean => {
        return value >= 0;
      });
      if (validateData) {
        this.blockPropertiesData.permeability.JDirection = { select: this.permeability.JDirection.select, text: jPermeabilityTextArray.toString() };
      } else {
        this.blockPropertiesData.permeability.JDirection = { select: this.permeability.JDirection.select, text: jPermeabilityTextArray.toString() };
        this.notification.emit({ text: 'error Permeability IDirection', style: 'warning', width: 150, height: 90 });
      }
    }

    if (data.target && data.target.name === 'KPermeabilityDirectionText') {
      const kPermeabilityTextArray = this.clearData(this.permeability.KDirection.text);
      const validateData = kPermeabilityTextArray.every((value: any): boolean => {
        return value >= 0;
      });
      if (validateData) {
        this.blockPropertiesData.permeability.KDirection = { select: this.permeability.KDirection.select, text: kPermeabilityTextArray.toString() };
      } else {
        this.blockPropertiesData.permeability.KDirection = { select: this.permeability.KDirection.select, text: kPermeabilityTextArray.toString() };
        this.notification.emit({ text: 'error Permeability IDirection', style: 'warning', width: 150, height: 90 });
      }
    }

    if (data.target && data.target.name === 'porosityText') {
      const porosityTextArray = this.clearData(this.porosity.text);
      const validateData = porosityTextArray.every((value: any): boolean => {
        return value >= 0 && value < 1;
      });
      if (validateData) {
        this.blockPropertiesData.porosity = { select: this.porosity.select, text: porosityTextArray.toString() };
      } else {
        this.blockPropertiesData.porosity = { select: this.porosity.select, text: porosityTextArray.toString() };
        this.notification.emit({ text: 'error Porosity', style: 'warning', width: 150, height: 90 });
      }
    }

    if (data.target && data.target.name === 'activeBlocksText') {
      const activeBlocksTextArray = this.clearData(this.activeBlocks.text);
      const validateData = activeBlocksTextArray.every((value: any): boolean => {
        return (value === 0 || value === '0') || (value === 1 || value === '1');
      });
      if (validateData) {
        this.blockPropertiesData.activeBlocks = { select: this.activeBlocks.select, text: activeBlocksTextArray.toString() };
      } else {
        this.blockPropertiesData.activeBlocks = { select: this.activeBlocks.select, text: activeBlocksTextArray.toString() };
        this.notification.emit({ text: 'error activeBlocks', style: 'warning', width: 150, height: 90 });
      }
    }

    if (data.target && data.target.name === 'flowUnitText') {
      const flowUnitTextArray = this.clearData(this.flowUnit.text);
      if (this.settingsConfiguration && this.settingsConfiguration.flowUnitsSelect && this.settingsConfiguration.flowUnitsSelect.length) {
        const validateData = flowUnitTextArray.every((value: any): boolean => {
          return Object.keys(this.settingsConfiguration.flowUnitsSelect).includes(value);
        });
        const validateOrder = flowUnitTextArray.every((number, i) => i === 0 || flowUnitTextArray[i - 1] <= number);
        if (validateData && validateOrder) {
          this.blockPropertiesData.flowUnit = { select: this.flowUnit.select, text: flowUnitTextArray.toString() };
        } else {
          this.blockPropertiesData.flowUnit = { select: this.flowUnit.select, text: flowUnitTextArray.toString() };
          this.notification.emit({ text: 'error flowUnit', style: 'warning', width: 150, height: 90 });
        }
      } else {
        this.notification.emit({ text: 'no flowUnits selected', style: 'error', width: 150, height: 90 });
      }
    }
    this.blockPropertiesChange.emit(this.blockPropertiesData);
  }
}
