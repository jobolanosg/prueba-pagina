import { Component, OnInit, DoCheck, Output, Input, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-reservoir',
  templateUrl: './reservoir.component.html',
  styleUrls: ['./reservoir.component.scss']
})
export class ReservoirComponent implements OnInit, DoCheck {

  @Input() settingsConfiguration: any = {};
  @Input() reservoirData: any;
  @Output() reservoirDataChange: EventEmitter<any> = new EventEmitter();
  @Output() notification: EventEmitter<any> = new EventEmitter();
  constructor() { }
  public gridType: Array<string> = ['Cartesian - Reservoir', 'Cartesian - Core', 'Radial', 'Corner Point'];
  selectedGridType;
  public iDirection: Array<string> = ['Constant for all blocks', 'Varying in I direction'];
  public jDirection: Array<string> = ['Constant for all blocks', 'Varying in J direction'];
  public kDirection: Array<string> = ['Constant for all blocks', 'Varying in K direction'];
  numberBlocks: any;
  blockWidths: any;
  panelOpenState = false;
  reservoirSelection = '';
  unityMeasure = '';


  ngOnInit() {
    this.unitsMeasurement();

    this.selectedGridType = this.reservoirData.selectedGridType;
    this.reservoirData.numberBlock ? this.numberBlocks = this.reservoirData.numberBlock : this.numberBlocks = { IDirection: '', KDirection: '', JDirection: '' };
    if (this.reservoirData.blockWidths) {
      this.blockWidths = this.reservoirData.blockWidths;
    } else {
      this.blockWidths = {
        IDirection: {
          select: '',
          value: ''
        },
        JDirection: {
          select: '',
          value: ''
        },
        KDirection: {
          select: '',
          value: ''
        },
        InternalRadius: '',
        ExternalRadius: ''
      };
    }
    if (!this.reservoirData.blockPropertiesData) {
      this.reservoirData.blockPropertiesData = {};
    }
  }

  valueChange(data) {
    this.reservoirData.selectedGridType = this.selectedGridType;
    this.reservoirData.numberBlock = this.numberBlocks;
    this.reservoirData.blockWidths = this.blockWidths;
    this.reservoirDataChange.emit(this.reservoirData);
  }

  ngDoCheck() {
    if (this.selectedGridType === 'Cartesian - Reservoir' || this.selectedGridType === 'Cartesian - Core') {
      this.reservoirSelection = 'Cartesian';
    } else {
      if (this.selectedGridType === 'Radial') {
        this.reservoirSelection = 'Radial';
      } else {
        if (this.selectedGridType === 'Corner Point') {
          this.reservoirSelection = 'Corner';
        }
      }
    }
  }

  sendNotification(data) {
    this.notification.emit(data);
  }

  unitsMeasurement() {
    if (this.settingsConfiguration.selectedWorkUnits === 'Field') {
      this.unityMeasure = 'ft';
    } else if (this.settingsConfiguration.selectedWorkUnits === 'SI') {
      this.unityMeasure = 'm';
    } else if (this.settingsConfiguration.selectedWorkUnits === 'Lab') {
      this.unityMeasure = 'cm';
    }
  }
}
