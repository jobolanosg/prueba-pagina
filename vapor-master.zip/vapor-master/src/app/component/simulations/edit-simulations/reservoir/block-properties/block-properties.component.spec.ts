import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockPropertiesComponent } from './block-porperties.component';

describe('BlockPropertiesComponent', () => {
  let component: BlockPropertiesComponent;
  let fixture: ComponentFixture<BlockPropertiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlockPropertiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlockPropertiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
