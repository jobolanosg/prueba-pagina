import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { EditSimulationsComponent } from './edit-simulations.component';
import { EditSimulationsRouter } from './edit-simulations.routing';

import { FluidsModule } from './fluids/fluids.module';
import { InitialConditionsModule } from './initial-conditions/initial-conditions.module';
import { NumericalSettingsModule } from './numerical-settings/numerical-settings.module';
import { ReservoirModule } from './reservoir/reservoir.module';
import { RockFluidModule } from './rock-fluid/rock-fluid.module';
import { SettingsModule } from './settings/settings.module';
import { WellsScheduleModule } from './wells-schedule/wells-schedule.module';
import { ComponentsModule } from './components/components.module';
import { ThermalModule } from './thermal/thermal.module';

import { MatTabsModule } from '@angular/material/tabs';

import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { NotificationModule } from '@progress/kendo-angular-notification';

import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NavModule } from '../../nav/nav.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    EditSimulationsRouter,
    FluidsModule,
    InitialConditionsModule,
    NumericalSettingsModule,
    ReservoirModule,
    RockFluidModule,
    SettingsModule,
    WellsScheduleModule,
    ComponentsModule,
    ThermalModule,
    TooltipModule,
    NotificationModule,
    MatTabsModule,
    MatProgressSpinnerModule,
    NavModule
  ],
  declarations: [
    EditSimulationsComponent
  ]
})
export class EditSimulationsModule { }
