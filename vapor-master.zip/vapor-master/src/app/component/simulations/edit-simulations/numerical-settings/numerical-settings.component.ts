import { Component, OnInit, Input, Output, EventEmitter, DoCheck } from '@angular/core';

@Component({
  selector: 'app-numerical-settings',
  templateUrl: './numerical-settings.component.html',
  styleUrls: ['./numerical-settings.component.scss']
})

export class NumericalSettingsComponent implements OnInit, DoCheck {

  @Input() settingsConfiguration: any;
  @Input() numericalSettingsData: any;
  @Output() numericalSettingsDataChange: EventEmitter<any> = new EventEmitter();
  @Output() notification: EventEmitter<any> = new EventEmitter();
  typeSelectedSetted = '';
  toleranceTypeItems = ['IUTOL', 'STOL', 'RELTOL', 'INFTOL', 'ABSTOL', 'DXTOL', 'RXTOL'];
  unityPressure = '';
  unityTime = '';
  numericalSettings: any;
  constructor() { }

  ngOnInit() {
    this.unitsMeasurement();
    this.sendNotification();
    if (this.numericalSettingsData && Object.keys(this.numericalSettingsData).length) {
      this.numericalSettings = this.numericalSettingsData;
    } else {
      this.numericalSettings = {
        maxTimeChange: '',
        minTimeChange: '',
        initialTimeChange: '',
        maxPressureChange: '',
        maxSaturationChange: '',
        maxMolarChange: '',
        maxTemperatureChange: '',
        accelerationFactor: '',
        maxIterations: '',
        minIterations: '',
        acceleratmaxNumberOfCutsInNewtonMethodionFactor: '',
        pressure: {
          toleranceType: '',
          tolerance: ''
        },
        mol: {
          toleranceType: '',
          tolerance: ''
        },
        thermalProperty: {
          toleranceType: '',
          tolerance: ''
        }
      };
    }
  }

  ngDoCheck(): void {
    if (this.settingsConfiguration.selectedFluidsModel === 'Extended Black Oil') {
      this.typeSelectedSetted = 'Condensate';
    } else {
      if (this.settingsConfiguration.selectedFluidsModel === 'Compositional') {
        this.typeSelectedSetted = 'Compositional';
      }
    }
  }

  sendNotification() {
    if (!this.settingsConfiguration.selectedFluidsModel) {
      this.notification.emit({ text: 'A fluid model has not been selected', style: 'error', width: 150, height: 90 });
    }
  }

  valueChange(data) {
    this.numericalSettingsData = this.numericalSettings;
    this.numericalSettingsDataChange.emit(this.numericalSettingsData);
  }

  unitsMeasurement(): void {
    if (this.settingsConfiguration.selectedWorkUnits === 'Field') {
      this.unityPressure = 'psi';
      this.unityTime = 'day';
    } else if (this.settingsConfiguration.selectedWorkUnits === 'SI') {
      this.unityPressure = 'kpa';
      this.unityTime = 'day';
    } else if (this.settingsConfiguration.selectedWorkUnits === 'Lab') {
      this.unityPressure = 'psi';
      this.unityTime = 'min';
    }
  }
}
