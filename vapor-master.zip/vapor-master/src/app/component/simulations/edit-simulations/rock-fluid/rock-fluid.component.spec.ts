import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RockFluidComponent } from './rock-fluid.component';

describe('RockFluidComponent', () => {
  let component: RockFluidComponent;
  let fixture: ComponentFixture<RockFluidComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RockFluidComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RockFluidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
