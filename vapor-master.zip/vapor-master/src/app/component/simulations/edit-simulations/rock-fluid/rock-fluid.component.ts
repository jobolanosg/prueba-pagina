import { Component, OnInit, Input, Output, EventEmitter, DoCheck } from '@angular/core';

@Component({
  selector: 'app-rock-fluid',
  templateUrl: './rock-fluid.component.html',
  styleUrls: ['./rock-fluid.component.scss']
})
export class RockFluidComponent implements OnInit, DoCheck {

  @Input() settingsConfiguration: any = {};
  @Input() flowUnitConfiguration = [];
  @Input() rockFluidData: any[];
  @Output() rockFluidDataChange: EventEmitter<any[]> = new EventEmitter();
  @Output() notification: EventEmitter<any> = new EventEmitter();

  panelOpenState = false;
  rockFlowData: any[];

  rockFluidObject = {
    id: 0,
    gasOilRelativePermeability: [{}],
    oilWaterRelativePermeability: [{}]
  };

  unityPressure = '';

  constructor() { }

  valueChange(data: any[], index: number, type: string) {
    if (type === 'gas-oil') {
      this.rockFlowData[index].gasOilRelativePermeability = data;
    }
    if (type === 'oil-water') {
      this.rockFlowData[index].oilWaterRelativePermeability = data;
    }
    this.rockFluidData = this.rockFlowData;
    this.rockFluidDataChange.emit(this.rockFluidData);
  }

  ngOnInit() {
    this.unitsMeasurement();
    this.setArrays();
  }

  ngDoCheck() {
  }

  trackRockFluidBy(index: number, rockFluid: any): number {
    return rockFluid.id;
  }

  unitsMeasurement(): void {
    if (this.settingsConfiguration.selectedWorkUnits === 'Field' || this.settingsConfiguration.selectedWorkUnits === 'Lab') {
      this.unityPressure = 'psi';
    } else if (this.settingsConfiguration.selectedWorkUnits === 'SI') {
      this.unityPressure = 'kpa';
    }
  }


  setArrays() {
    if (this.rockFluidData.length) {
      this.rockFlowData = this.rockFluidData;
    } else {
      if (this.settingsConfiguration.flowUnitsSelect) {
        this.rockFlowData = Array(this.settingsConfiguration.flowUnitsSelect.length);
        for (let i = 0; i < this.settingsConfiguration.flowUnitsSelect.length; i++) {
          this.rockFlowData[i] = { ...this.rockFluidObject, id: i };
          const currentRockFlowDataGasOil = {};
          Object.defineProperty(currentRockFlowDataGasOil, `gasSaturationGasOil${i}`, {
            value: '',
            writable: true,
            enumerable: true,
            configurable: true
          });
          Object.defineProperty(currentRockFlowDataGasOil, `gasRelativePermeabilityGasOil${i}`, {
            value: '',
            writable: true,
            enumerable: true,
            configurable: true
          });
          Object.defineProperty(currentRockFlowDataGasOil, `oilRelativePermeabilityGasOil${i}`, {
            value: '',
            writable: true,
            enumerable: true,
            configurable: true
          });
          Object.defineProperty(currentRockFlowDataGasOil, `oilGasCapillaryPressureGasOil${i}`, {
            value: '',
            writable: true,
            enumerable: true,
            configurable: true
          });
          this.rockFlowData[i].gasOilRelativePermeability = [currentRockFlowDataGasOil];
          const currentRockFlowDataOilWater = {};
          Object.defineProperty(currentRockFlowDataOilWater, `waterSaturationOilWater${i}`, {
            value: '',
            writable: true,
            enumerable: true,
            configurable: true
          });
          Object.defineProperty(currentRockFlowDataOilWater, `waterRelativePermeabilityOilWater${i}`, {
            value: '',
            writable: true,
            enumerable: true,
            configurable: true
          });
          Object.defineProperty(currentRockFlowDataOilWater, `oilRelativePermeabilityOilWater${i}`, {
            value: '',
            writable: true,
            enumerable: true,
            configurable: true
          });
          Object.defineProperty(currentRockFlowDataOilWater, `waterOilCapillaryPressureOilWater${i}`, {
            value: '',
            writable: true,
            enumerable: true,
            configurable: true
          });
          this.rockFlowData[i].oilWaterRelativePermeability = [currentRockFlowDataOilWater];
        }
      } else {
        this.notification.emit({ text: 'Add Flow Units in the settings section', style: 'error', width: 150, height: 90 });
      }
    }
  }
}
