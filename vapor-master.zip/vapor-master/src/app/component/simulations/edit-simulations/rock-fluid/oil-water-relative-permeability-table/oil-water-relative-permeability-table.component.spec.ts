import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OilWaterRelativePermeabilityTableComponent } from './oil-water-relative-permeability-table.component';

describe('OilWaterRelativePermeabilityTableComponent', () => {
  let component: OilWaterRelativePermeabilityTableComponent;
  let fixture: ComponentFixture<OilWaterRelativePermeabilityTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OilWaterRelativePermeabilityTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OilWaterRelativePermeabilityTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
