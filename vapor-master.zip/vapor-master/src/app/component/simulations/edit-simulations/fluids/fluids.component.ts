import { Component, OnInit, Input, DoCheck, Output, EventEmitter } from '@angular/core';
import { Store } from '@ngxs/store';
import { UserState } from '../../../../store/state/user.state';

@Component({
  selector: 'app-fluids',
  templateUrl: './fluids.component.html',
  styleUrls: ['./fluids.component.scss']
})
export class FluidsComponent implements OnInit, DoCheck {
  @Input() settingsConfiguration: any = {};
  @Input() fluidsData: any;
  @Output() fluidsDataChange: EventEmitter<any> = new EventEmitter();

  typeSelectedSetted = '';
  panelOpenState = false;
  isThermal = false;
  // Units of Measurement
  units: any = {
    unityPressure: '',
    unityCompressibility: '',
    unityVolumetricFactorOil: '',
    unityViscosity: '',
    unityDensity: '',
    unityTemperature: '',
    unityVolume: '',
    unityMolecular: ''
  };
  waterPropertiesData: any[];

  constructor(private store: Store) { }

  ngOnInit() {
    this.unitsMeasurement();
    this.isThermal = this.store.selectSnapshot(UserState.getSimulationsType) === 'Thermal CEOR';
    if (this.fluidsData.waterProperties && this.fluidsData.waterProperties.length > 0) {
      this.waterPropertiesData = this.fluidsData.waterProperties;
    } else {
      if (this.settingsConfiguration.flowUnitsSelect) {
        this.waterPropertiesData = Array(this.settingsConfiguration.flowUnitsSelect.length);
        for (let i = 0; i < this.settingsConfiguration.flowUnitsSelect.length; i++) {
          const currentProperties = {
            referencePressure: '',
            volumetricFactor: '',
            viscosity: '',
            density: '',
            criticalPressure: '',
            molecularWeigth: '',
            compressibility: '',
            dependeceOfViscosityWithPressure: '',
            acentricFactor: '',
            criticalTemperature: '',
            criticalVolume: '',
            heatCapacityCoefficient1: '',
            heatCapacityCoefficient2: '',
            heatCapacityCoefficient3: '',
            heatCapacityCoefficient4: '',
            heatCapacityCoefficient5: '',
            volumeShift: '',
            volumeShiftCoefficient: ''
          };
          this.waterPropertiesData[i] = currentProperties;
        }
      }
    }
    if (!(this.fluidsData.properties)) {
      this.fluidsData.properties = [];
    }
    if (!(this.fluidsData.components)) {
      this.fluidsData.components = {};
    }
    if (!(this.fluidsData.viscosity)) {
      this.fluidsData.viscosity = {};
    }
    if (!(this.fluidsData.fluidComponents)) {
      this.fluidsData.fluidComponents = [];
    }
  }

  ngDoCheck(): void {
    if (this.settingsConfiguration.selectedFluidsModel === 'Extended Black Oil') {
      this.typeSelectedSetted = 'Extended';
    } else {
      if (this.settingsConfiguration.selectedFluidsModel === 'Compositional') {
        this.typeSelectedSetted = 'Compositional';
      }
    }
  }

  valueChange(data) {
    this.fluidsData.waterProperties = this.waterPropertiesData;
    this.fluidsDataChange.emit(this.fluidsData);
  }

  unitsMeasurement(): void {
    if (this.settingsConfiguration.selectedWorkUnits === 'Field' || this.settingsConfiguration.selectedWorkUnits === 'Lab') {
      this.units.unityPressure = 'psi';
      this.units.unityVolumetricFactorOil = 'RB/STB';
      this.units.unityCompressibility = '1/psi';
      this.units.unityViscosity = 'cp/psi';

      if (this.settingsConfiguration.selectedWorkUnits === 'Field') {
        this.units.unityDensity = 'lbm/ft³';
        this.units.unityTemperature = '°R';
        this.units.unityVolume = 'ft³/lbm';
        this.units.unityMolecular = 'lbm/lbmol';
      } else if (this.settingsConfiguration.selectedWorkUnits === 'Lab') {
        this.units.unityDensity = 'g/cm³';
        this.units.unityTemperature = 'K';
        this.units.unityVolume = 'cm³/g';
        this.units.unityMolecular = 'g/mol';
      }
    } else if (this.settingsConfiguration.selectedWorkUnits === 'SI') {
      this.units.unityDensity = 'kg/m³';
      this.units.unityPressure = 'kpa';
      this.units.unityVolumetricFactorOil = 'm³/m³';
      this.units.unityCompressibility = '1/kpa';
      this.units.unityViscosity = 'cp/kpa';
      this.units.unityTemperature = 'K';
      this.units.unityVolume = 'm³/kg';
      this.units.unityMolecular = 'kg/mol';
    }
  }
}
