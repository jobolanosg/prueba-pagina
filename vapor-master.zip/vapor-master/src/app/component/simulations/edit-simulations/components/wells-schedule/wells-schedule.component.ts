import { Component, OnInit, Input, Output, EventEmitter, DoCheck } from '@angular/core';

@Component({
  selector: 'app-wells-schedule',
  templateUrl: './wells-schedule.component.html',
  styleUrls: ['./wells-schedule.component.scss']
})
export class WellsScheduleComponent implements OnInit, DoCheck {

  @Input() settingsConfiguration: any;
  @Input() wellsScheduleConfiguration: any;
  @Input() componentsData: any;
  @Output() componentsDataChange: EventEmitter<any> = new EventEmitter();

  typeWellScheduleOptions: string[] = ['ppm', 'bbl/day'];
  wellSchedule: any[] = [];
  selectDate: Array<string[]>;
  panelOpenState = false;
  settings = {
    rowHeaders: true,
    colHeaders: true,
    minRows: 1,
    minSpareRows: 1,
    startRows: 1,
    autoColumnSize: { syncLimit: '100%', useHeaders: true },
    contextMenu: ['row_above', 'row_below', 'remove_row'],
  };
  constructor() { }

  ngOnInit() {
    if (this.wellsScheduleConfiguration.scheduleDates && this.wellsScheduleConfiguration.scheduleDates.length > 0) {
      this.selectDate = this.wellsScheduleConfiguration.scheduleDates;
    } else {
      this.selectDate = Array(this.wellsScheduleConfiguration.schedule.length).fill([]);
    }
    if (this.componentsData.wellSchedule && this.componentsData.wellSchedule.length > 0) {
      this.wellSchedule = this.componentsData.wellSchedule;
    } else {
      if (this.wellsScheduleConfiguration.wells && this.wellsScheduleConfiguration.wells.length > 0) {
        this.wellSchedule = [];
        for (let i = 0; i < this.wellsScheduleConfiguration.wells.length; i++) {
          this.wellSchedule[i] = {
            type: {
              polymer: '',
              surfactant: '',
              nanoparticle: ''
            },
            data: this.getTable(i)
          };
        }
      } else {
        this.wellSchedule = [];
      }
    }
  }

  ngDoCheck(): void {
    if (this.wellsScheduleConfiguration.wells) {
      if (this.wellsScheduleConfiguration.wells.length > this.wellSchedule.length) {
        for (let i = this.wellSchedule.length; i < this.wellsScheduleConfiguration.wells.length; i++) {
          this.wellSchedule.push({
            type: {
              polymer: '',
              surfactant: '',
              nanoparticle: ''
            },
            data: this.getTable(i)
          });
        }
      } else if (this.wellsScheduleConfiguration.wells.length < this.wellSchedule.length) {
        for (let i = this.wellsScheduleConfiguration.wells.length; i < this.wellSchedule.length + 1; i++) {
          this.wellSchedule.pop();
        }
      }
    }
  }

  getTable(index) {
    const currentObject = {};
    Object.defineProperty(currentObject, `date${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    if (this.settingsConfiguration.polymerSelect) {
      Object.defineProperty(currentObject, `polymer${index}`, {
        value: '',
        writable: true,
        enumerable: true,
        configurable: true
      });
    }
    if (this.settingsConfiguration.surfactantSelect) {
      Object.defineProperty(currentObject, `surfactant${index}`, {
        value: '',
        writable: true,
        enumerable: true,
        configurable: true
      });
    }
    if (this.settingsConfiguration.nanoparticleSelect) {
      Object.defineProperty(currentObject, `nanoparticle${index}`, {
        value: '',
        writable: true,
        enumerable: true,
        configurable: true
      });
    }
    return [currentObject];
  }

  valueChange(data) {
    this.componentsData.wellSchedule = this.wellSchedule;
    this.componentsDataChange.emit(this.componentsData);
  }
}
