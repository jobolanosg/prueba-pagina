import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-polymer',
  templateUrl: './polymer.component.html',
  styleUrls: ['./polymer.component.scss']
})
export class PolymerComponent implements OnInit {

  @Input() settingsConfiguration: any = {};
  @Input() componentsData: any;
  @Output() componentsDataChange: EventEmitter<any> = new EventEmitter();

  polymerModel = ['Herschel', 'Carreau', 'HB-MPR'];
  polymer: any;

  constructor() { }

  ngOnInit() {
    if (this.componentsData.polymer) {
      this.polymer = this.componentsData.polymer;
    } else {
      this.polymer = {
        properties: {
          density: '',
          specificGravity: '',
          molecularWeight: '',
          rrf: '',
          ipv: '',
        },
        kinetics: {
          adsorption: {
            equilibriumRateConstant: '',
            adjustParameter: '',
            adsorptionTable: [{
              adsorbedPolymer: '',
              equilibriumAdsorbedPolymer: ''
            }]
          },
          degradation: {
            quemicalDegradationConstant: '',
            mechanicalDegradationConstant: '',
            mechanicalDegradationExponent: '',
            degradationTable: [{
              concentration: '',
              degradationTemperature: '',
              activationEnergy: ''
            }]
          }
        },
        rheology: {
          model: '',
          consistencyIndex: '',
          fluxIndex: '',
          infinityViscosity: '',
          apparentShearRateParameter: '',
          flowIndex: '',
          adjustParameter: '',
          consistencyIndexChecked: false,
          relaxionTimeChecked: false,
          relaxionTime: '',
          salinityConstantChecked: '',
          salinityConstant1: '',
          salinityConstant2: '',
          salinityConstant3: '',
          viscosityAtRate0Checked: false,
          viscosityAtRate0: '',
          solvationConstant: '',
          dispersionIndex: '',
          shapeFactor: '',
        }
      };
    }
  }

  valueChange($event) {
    this.componentsData.polymer = this.polymer;
    this.componentsDataChange.emit(this.componentsData);
  }
}
