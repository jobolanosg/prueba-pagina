import { Component, OnInit, Input, Output, EventEmitter, DoCheck } from '@angular/core';

@Component({
  selector: 'app-nanoparticle',
  templateUrl: './nanoparticle.component.html',
  styleUrls: ['./nanoparticle.component.scss']
})
export class NanoparticleComponent implements OnInit, DoCheck {
  window: any = { open: false, index: 0 };
  componentList: any;
  preEdit: any;
  constructor() { }

  @Input() settingsConfiguration: any;
  @Input() fluidsConfiguration: any;
  @Input() componentsData: any;
  @Output() componentsDataChange: EventEmitter<any> = new EventEmitter();

  selectDate = [];
  adsorptionIsothermForTheReactantItems: string[] = ['None', 'Langmuir'];
  reactionPhaseItems: string[] = ['Oil', 'Water', 'Gas'];
  public propertiesPanelOpenState = false;
  public wellsPanelOpenState = false;
  nanoparticleItems = ['Double Site'];
  nanoparticleSelect: string;
  nanoparticle: any;
  settings = {
    rowHeaders: true,
    colHeaders: true,
    minRows: 1,
    minSpareRows: 1,
    startRows: 1,
    autoColumnSize: { syncLimit: '100%', useHeaders: true },
    contextMenu: ['row_above', 'row_below', 'remove_row'],
  };
  settingsReaction = {
    rowHeaders: true,
    colHeaders: true,
    minRows: 1,
    minSpareRows: 0,
    startRows: 2,
    autoColumnSize: { syncLimit: '100%', useHeaders: true },
    contextMenu: ['row_above', 'row_below', 'remove_row'],
  };

  ngOnInit() {
    if (this.fluidsConfiguration.components && Object.keys(this.fluidsConfiguration.components).length) {
      if (this.fluidsConfiguration.components && this.fluidsConfiguration.components.componentList.length > 0) {
        this.componentList = this.fluidsConfiguration.components.componentList;
        if (this.componentList.indexOf('Water') === -1 || this.componentList.indexOf('water') === -1) {
          this.componentList.push('Water');
        }
      } else {
        this.componentList = ['Water'];
      }
    } else {
      this.componentList = [];
    }

    if (this.componentsData.nanoparticle && Object.keys(this.componentsData.nanoparticle).length) {
      this.nanoparticle = this.componentsData.nanoparticle;
    } else {
      this.nanoparticle = {
        properties: {
          density: '',
          diameter: '',
          molecularWeight: '',
          surfaceAreaCoefficient: '',
          specificGravity: ''
        },
        kinetics: {
          retention: {
            model: '',
            criticalVelocity: '',
            maxRetentionSite1: '',
            maxRetentionSite2: '',
            coefficientOfDeposition: '',
            coefficientOfReleaseRate: '',
            coefficientOfPluggingRate: ''
          },
          interception: {
            GasOil: '',
            GasWater: ''
          },
          equilibriumRatio: {
            OilWater: '',
            temperatureList: [0],
            temperature: Array(1).fill(this.getTemperatureTable(0))
          }
        },
        modifiers: {
          porosity: false,
          permeability: false,
          relativePermeability: false,
          optimalConcentration: ''
        },
        viscosity: {
          viscositySelect: false,
          temperatureViscosityList: [0],
          temperatureViscosity: Array(1).fill(this.getTemperatureViscosityTable(0))
        },
        upgrading: {
          reactionsSelect: false,
          reactions: [this.getReactionObject()]
        },
        flowAlteration: this.getTable()
      };
    }
  }
  getTemperatureViscosityTable(index: number): any {
    const temperatureViscosityObject = {};
    const tableObject = {};

    Object.defineProperty(tableObject, `AdsorptionOfAsphaltenesOnNanoparticles${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `viscosityReduction${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(temperatureViscosityObject, `temperatureViscosity${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(temperatureViscosityObject, `data${index}`, {
      value: Array(1).fill(tableObject),
      writable: true,
      enumerable: true,
      configurable: true
    });

    return temperatureViscosityObject;
  }

  getTemperatureReactionTable(index: number): any {
    const temperatureViscosityObject = {};
    const tableObject = {};

    Object.defineProperty(tableObject, `nanoparticlesConcentration${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `adsorptionConcentration${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(temperatureViscosityObject, `temperature${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(temperatureViscosityObject, `data${index}`, {
      value: Array(1).fill(tableObject),
      writable: true,
      enumerable: true,
      configurable: true
    });

    return temperatureViscosityObject;
  }

  getTemperatureTable(index: number) {
    const temperatureObject = {};
    const tableObject = {};

    Object.defineProperty(tableObject, `pressure${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `k-value${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(temperatureObject, `temperature${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(temperatureObject, `data${index}`, {
      value: Array(1).fill(tableObject),
      writable: true,
      enumerable: true,
      configurable: true
    });

    return temperatureObject;
  }

  ngDoCheck() {
    if (this.nanoparticle) {
      if (this.nanoparticle.kinetics.retention.model === 'Double Site') {
        this.nanoparticleSelect = 'Double';
      } else if (this.nanoparticle.kinetics.retention.model === 'Critical Velocity') {
        this.nanoparticleSelect = 'Critical';
      }
    }
  }

  valueChange(data) {
    this.componentsData.nanoparticle = this.nanoparticle;
    this.componentsDataChange.emit(this.componentsData);
  }

  getTable() {
    let currentTable = [];
    if (this.settingsConfiguration.flowUnitsSelect) {
      currentTable = Array(this.settingsConfiguration.flowUnitsSelect.length);
      for (let i = 0; i < this.settingsConfiguration.flowUnitsSelect.length; i++) {
        currentTable[i] = { id: i, gasOilData: [this.getGasOilPropertiesTable(i)], oilWaterData: [this.getOilWaterPropertiesTable(i)] };
      }
    }
    return currentTable;
  }

  getGasOilPropertiesTable(index: number): any {
    const tableObject = {};
    Object.defineProperty(tableObject, `gasSaturation${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `gasRelativePermeability${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `oilRelativePermeabilityr${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `oilGasCapillaryPressure${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    return tableObject;
  }

  addTemperature() {
    const temperatureLength = this.nanoparticle.kinetics.equilibriumRatio.temperatureList.length;
    this.nanoparticle.kinetics.equilibriumRatio.temperatureList.push(temperatureLength);
    this.nanoparticle.kinetics.equilibriumRatio.temperature.push(this.getTemperatureTable(temperatureLength));
    this.valueChange('added');
  }

  addTemperatureViscosity() {
    const temperatureViscosityLength = this.nanoparticle.viscosity.temperatureViscosityList.length;
    this.nanoparticle.viscosity.temperatureViscosityList.push(temperatureViscosityLength);
    this.nanoparticle.viscosity.temperatureViscosity.push(this.getTemperatureViscosityTable(temperatureViscosityLength));
    this.valueChange('added');
  }

  getOilWaterPropertiesTable(index: number): any {
    const tableObject = {};
    Object.defineProperty(tableObject, `waterSaturation${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `waterRelativePermeability${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `oilWaterRelativePermeabilityr${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `oilwaterCapillaryPressure${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    return tableObject;
  }

  getReactionObject() {
    const componentObject = {};
    const componentListFiltered = this.componentList.filter(current => current !== 'Water');
    componentListFiltered.push('Water');
    for (let component = 0; component < componentListFiltered.length; component++) {
      Object.defineProperty(componentObject, `component-${component}`, {
        value: null,
        writable: true,
        enumerable: true,
        configurable: true
      });
    }
    const stoichiometry = [JSON.parse(JSON.stringify(componentObject)), JSON.parse(JSON.stringify(componentObject))];
    const reactionObject = {
      name: 'default',
      stoichiometry: stoichiometry,
      reactionOrder: '',
      reactionPhase: '',
      preExponentialFactor: '',
      activationEnergy: '',
      enthalpyOfReaction: '',
      adsorptionIsothermForTheReactant: '',
      temperatureReactionList: [0],
      temperatureReaction: Array(1).fill(this.getTemperatureReactionTable(0))
    };
    return reactionObject;
  }

  openWindow(index: number) {
    this.window = { open: true, index: index };
    this.preEdit = JSON.parse(JSON.stringify(this.nanoparticle.upgrading.reactions[this.window.index]));
  }

  close() {
    this.window = { open: false, index: 0 };
  }

  cancel() {
    this.nanoparticle.upgrading.reactions[this.window.index] = JSON.parse(JSON.stringify(this.preEdit));
    this.close();
    this.preEdit = JSON.parse(JSON.stringify({}));
  }

  editReaction(currentObject: any) {
    this.nanoparticle.upgrading.reactions[this.window.index] = currentObject;
    this.close();
  }

  addTemperatureReactions(index: number) {
    const temperatureReductionLength = this.nanoparticle.upgrading.reactions[index].temperatureReactionList.length;
    this.nanoparticle.upgrading.reactions[index].temperatureReactionList.push(temperatureReductionLength);
    this.nanoparticle.upgrading.reactions[index].temperatureReaction.push(this.getTemperatureReactionTable(temperatureReductionLength));
    this.valueChange('added');
  }

  addReaction() {
    this.nanoparticle.upgrading.reactions.push(this.getReactionObject());
  }
}
