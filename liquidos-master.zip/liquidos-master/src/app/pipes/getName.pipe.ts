import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'getName' })
export class GetNamePipe implements PipeTransform {

  transform(value: any, args: string[]): any {
    if (!value) { return value; }
    return `${value.user.name} ${value.user.lastname}`;
  }
}
