export class SaveProject {
  static readonly type = '[User] Save Project';

  constructor(public projectName: string) { }
}
export class SaveProjectId {
  static readonly type = '[User] Save ProjectId';

  constructor(public projectId: string) { }
}
export class SaveProjectDescription {
  static readonly type = '[User] Save ProjectDescription';

  constructor(public projectDescription: string) { }
}

export class SaveSimulations {
  static readonly type = '[User] Save Simulations';

  constructor(public simulationsName: string) { }
}
export class SaveSimulationsId {
  static readonly type = '[User] Save SimulationsId';

  constructor(public simulationsId: string) { }
}
export class SaveSimulationsDescription {
  static readonly type = '[User] Save SimulationsDescription';

  constructor(public simulationsDescription: string) { }
}
export class SaveSimulationsType {
  static readonly type = '[User] Save SimulationsType';

  constructor(public simulationsType: string) { }
}

export class RemoveProject {
  static readonly type = '[User] Remove Project';

  constructor() { }
}

export class RemoveProjectId {
  static readonly type = '[User] Remove ProjectId';

  constructor() { }
}
export class RemoveProjectDescription {
  static readonly type = '[User] Remove ProjectDescription';

  constructor() { }
}

export class RemoveSimulations {
  static readonly type = '[User] Remove Simulations';

  constructor() { }
}

export class RemoveSimulationsId {
  static readonly type = '[User] Remove SimulationsId';

  constructor() { }
}
export class RemoveSimulationsDescription {
  static readonly type = '[User] Remove SimulationsDescription';

  constructor() { }
}

export class RemoveSimulationsType {
  static readonly type = '[User] Remove SimulationsType';

  constructor() { }
}

export class RemoveRunningSimulation {
  static readonly type = '[User] Remove RunningSimulation';

  constructor(public simulation_id: string) { }
}

export class AddRunningSimulation {
  static readonly type = '[User] Add RunningSimulations';

  constructor(public simulationData: any) { }
}

export class UpdateStatusRunningSimulation {
  static readonly type = '[User] Update Status RunningSimulations';

  constructor(public simulation_id: string, public status: string) { }
}
