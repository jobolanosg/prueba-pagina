import { State, Action, Selector } from '@ngxs/store';
import { SaveUser, LogoutUser, LoginUser } from './../actions/user.actions';
import { SaveProject, SaveSimulations } from './../actions/app.actions';
import { SaveProjectId, SaveSimulationsId, SaveProjectDescription, SaveSimulationsDescription, SaveSimulationsType } from './../actions/app.actions';
import { RemoveProject, RemoveProjectId } from './../actions/app.actions';
import { RemoveSimulations, RemoveSimulationsId, RemoveProjectDescription, RemoveSimulationsDescription, RemoveSimulationsType } from './../actions/app.actions';
import { RemoveRunningSimulation, AddRunningSimulation, UpdateStatusRunningSimulation } from './../actions/app.actions';
import { patch, append, removeItem, insertItem, updateItem } from '@ngxs/store/operators';

@State({
  name: 'user',
  defaults: {
    is_logged_in: false,
    user: {
      username: '',
      email: '',
      role: ''
    },
    token: null,
    id: '',
    project: '',
    projectId: '',
    projectDescription: '',
    simulations: '',
    simulationsId: '',
    simulationsDescription: '',
    simulationsType: '',
    runningSimulations: []
  }
})

export class UserState {
  @Selector()
  static getUser(user) {
    return user.user;
  }
  @Selector()
  static getToken(user) {
    return user.token;
  }
  @Selector()
  static getId(user) {
    return user.id;
  }
  @Selector()
  static getProject(user) {
    return user.project;
  }
  @Selector()
  static getProjectId(user) {
    return user.projectId;
  }
  @Selector()
  static getProjectDescription(user) {
    return user.projectDescription;
  }
  @Selector()
  static getSimulations(user) {
    return user.simulations;
  }
  @Selector()
  static getSimulationsId(user) {
    return user.simulationsId;
  }
  @Selector()
  static getSimulationsDescription(user) {
    return user.simulationsDescription;
  }
  @Selector()
  static getSimulationsType(user) {
    return user.simulationsType;
  }
  @Selector()
  static getRunningSimulations(user) {
    return user.runningSimulations;
  }
  @Action(LoginUser)
  loginUser(context, action: LoginUser) {
    context.patchState({
      token: action.userToken,
      is_logged_in: true,
      id: action.userId
    });
  }
  @Action(SaveUser)
  saveUser(context, action: SaveUser) {
    context.patchState({
      user: action.user
    });
  }
  @Action(LogoutUser)
  logoutUser(context) {
    context.setState({
      is_logged_in: false,
      token: null,
      id: ''
    });
  }
  @Action(SaveProject)
  saveProject(context, action: SaveProject) {
    context.patchState({
      project: action.projectName
    });
  }
  @Action(SaveProjectId)
  saveProjectId(context, action: SaveProjectId) {
    context.patchState({
      projectId: action.projectId
    });
  }
  @Action(SaveProjectDescription)
  saveProjectDescription(context, action: SaveProjectDescription) {
    context.patchState({
      projectDescription: action.projectDescription
    });
  }
  @Action(SaveSimulations)
  saveSimulations(context, action: SaveSimulations) {
    context.patchState({
      simulations: action.simulationsName
    });
  }
  @Action(SaveSimulationsId)
  saveSimulationsId(context, action: SaveSimulationsId) {
    context.patchState({
      simulationsId: action.simulationsId
    });
  }
  @Action(SaveSimulationsDescription)
  saveSimulationsDescription(context, action: SaveSimulationsDescription) {
    context.patchState({
      simulationsDescription: action.simulationsDescription
    });
  }
  @Action(SaveSimulationsType)
  saveSimulationsType(context, action: SaveSimulationsType) {
    context.patchState({
      simulationsType: action.simulationsType
    });
  }
  @Action(RemoveProject)
  removeProject(context) {
    context.patchState({
      project: ''
    });
  }
  @Action(RemoveProjectId)
  removeProjectId(context) {
    context.patchState({
      projectId: ''
    });
  }
  @Action(RemoveProjectDescription)
  removeProjectDescription(context) {
    context.patchState({
      projectDescription: ''
    });
  }
  @Action(RemoveSimulations)
  removeSimulations(context) {
    context.patchState({
      simulations: ''
    });
  }
  @Action(RemoveSimulationsId)
  removeSimulationsId(context) {
    context.patchState({
      simulationsId: ''
    });
  }
  @Action(RemoveSimulationsDescription)
  removeSimulationsDescription(context) {
    context.patchState({
      simulationsDescription: ''
    });
  }

  @Action(RemoveRunningSimulation)
  removeRunningSimulation(context, action: RemoveRunningSimulation) {
    context.setState(
      patch({
        runningSimulations: removeItem<any>(runningSimulation => runningSimulation.simulation_id === action.simulation_id)
      })
    );
  }

  @Action(AddRunningSimulation)
  addRunningSimulation(context, action: AddRunningSimulation) {
    context.setState(
      patch({
        runningSimulations: append(action.simulationData)
      })
    );
  }

  @Action(UpdateStatusRunningSimulation)
  updateStatusRunningSimulation(context, action: UpdateStatusRunningSimulation) {
    context.setState(
      patch({
        runningSimulations: updateItem<any>(runningSimulation => runningSimulation.simulation_id === action.simulation_id,
          patch({
            status: action.status
          })
        )
      })
    );
  }

}
