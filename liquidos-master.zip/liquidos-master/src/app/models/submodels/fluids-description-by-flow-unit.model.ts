import { PvtTable } from './ptv-table.model';
import { WaterProperties } from './water-properties.model';
import { ComponentsProperties } from './components-properties.model';
import { WaterPropertiesCompositional } from './water-properties-compositional.model';

export interface FluidsDescriptionByFlowUnit {
  pvtTable?: PvtTable;
  waterProperties?: WaterProperties;
  gasDensity?: number;
  oilDensity?: number;
  waterDensity?: number;
  equationOfState?: string;
  componentsProperties?: ComponentsProperties;
  binaryInteractionCoefficients?: Array<Number>;
  waterPropertiesCompositional?: WaterPropertiesCompositional;
}
