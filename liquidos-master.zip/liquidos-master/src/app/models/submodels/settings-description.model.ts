import { Simulations } from '../simulations.model';
import { Component } from '../component.model';

export interface SettingsDescription {
  simulations_id?: Simulations['_id'];
  workUnits?: string;
  fluidModel?: string;
  dualPorosityDualPermeability?: Boolean;
  flowUnitsName?: Array<String>;
  components?: Array<Component['_id']>;
}
