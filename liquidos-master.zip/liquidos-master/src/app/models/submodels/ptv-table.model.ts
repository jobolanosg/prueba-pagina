export interface PvtTable {
  pressure?: Array<Number>;
  solutionGas?: Array<Number>;
  volatilizedOil?: Array<Number>;
  oilVolumetricFactor?: Array<Number>;
  gasVolumetricFactor?: Array<Number>;
  oilViscosity?: Array<Number>;
  gasViscosity?: Array<Number>;
}
