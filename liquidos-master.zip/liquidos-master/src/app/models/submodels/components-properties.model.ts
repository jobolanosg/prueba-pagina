export interface ComponentsProperties {
  name?: Array<String>;
  acentricFactor?: Array<Number>;
  criticalPressure?: Array<Number>;
  criticalTemperature?: Array<Number>;
  criticalVolume?: Array<Number>;
  molecularWeight?: Array<Number>;
}
