import { Perforations } from './generic/perforations.model';

export interface Schedule {
  time?: number;
  wellIndex?: number;
  typeOfWell?: string;
  injectedFluid?: string;
  wellRadius?: number;
  skin?: number;
  operativeConditionType?: string;
  operativeConditionValue?: number;
  scheduleType?: string;
  numberOfPerforations?: number;
  perforations?: Array<Perforations>;
}
