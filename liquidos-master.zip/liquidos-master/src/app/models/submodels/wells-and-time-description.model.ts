import { Schedule } from './schedule.model';
import { Simulations } from '../simulations.model';

export interface WellsAndTimeDescription {
  simulations_id?: Simulations['_id'];
  times?: Array<Number>;
  timesWithChange?: Array<Number>;
  schedule?: Array<Schedule>;
}
