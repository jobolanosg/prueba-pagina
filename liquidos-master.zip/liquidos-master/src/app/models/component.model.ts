import { Token } from './submodels/token.model';

export interface Component {
  _id?: string;
  name: string;
  token?: Token['token'];
}
