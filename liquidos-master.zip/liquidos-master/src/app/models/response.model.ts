import { Token } from './submodels/token.model';
import { User } from './user.model';
import { Project } from './project.model';
import { Simulations } from './simulations.model';
import { Component } from './component.model';
import { Description } from './description.model';

export interface Response {
  success: Boolean;
  msg?: string;
  token?: Token['token'];
  id?: User['_id'];
  simulation?: Simulations;
  simulations?: Array<Simulations>;
  component?: Component;
  components?: Array<Component>;
  description?: Description;
  project?: Project;
  projects?: Array<Project>;
  temporary?: any;
  user?: User;
  users?: User[];
}
