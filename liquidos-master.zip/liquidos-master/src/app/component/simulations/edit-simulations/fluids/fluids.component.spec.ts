import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FluidsComponent } from './fluids.component';

describe('FluidsComponent', () => {
  let component: FluidsComponent;
  let fixture: ComponentFixture<FluidsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FluidsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FluidsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
