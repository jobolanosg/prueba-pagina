import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FluidsComponentsComponent } from './fluids-components.component';

describe('FluidsComponentsComponent', () => {
  let component: FluidsComponentsComponent;
  let fixture: ComponentFixture<FluidsComponentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FluidsComponentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FluidsComponentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
