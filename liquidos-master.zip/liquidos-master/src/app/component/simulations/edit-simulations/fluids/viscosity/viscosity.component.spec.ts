import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViscosityComponent } from './viscosity.component';

describe('ViscosityComponent', () => {
  let component: ViscosityComponent;
  let fixture: ComponentFixture<ViscosityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViscosityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViscosityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
