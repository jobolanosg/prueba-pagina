import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-viscosity',
  templateUrl: './viscosity.component.html',
  styleUrls: ['./viscosity.component.scss']
})
export class ViscosityComponent implements OnInit {
  @Input() viscosityData: any;
  @Output() viscosityDataChange: EventEmitter<any> = new EventEmitter();

  viscosity: any;
  modelViscosity: string[] = [''];
  constructor() { }

  ngOnInit() {
    if (Object.entries(this.viscosityData).length) {
      this.viscosity = this.viscosityData;
    } else {
      this.viscosity = {
        model: '',
        coefficient1: '',
        coefficient2: '',
        coefficient3: '',
        coefficient4: '',
        coefficient5: ''
      };
    }
  }

  valueChange(data) {
    this.viscosityData = this.viscosity;
    this.viscosityDataChange.emit(this.viscosityData);
  }
}



