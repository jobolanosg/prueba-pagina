import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ReservoirComponent } from './reservoir.component';
import { BlockPropertiesModule } from './block-properties/block-properties.module';

import { DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { UploadModule } from '@progress/kendo-angular-upload';
import { TabStripModule } from '@progress/kendo-angular-layout';
import { RippleModule } from '@progress/kendo-angular-ripple';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatExpansionModule } from '@angular/material/expansion';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    BlockPropertiesModule,
    DropDownListModule,
    UploadModule,
    TabStripModule,
    RippleModule,
    MatFormFieldModule,
    MatInputModule,
    MatExpansionModule
  ],
  declarations: [
    ReservoirComponent
  ],
  exports: [
    ReservoirComponent
  ]
})
export class ReservoirModule { }
