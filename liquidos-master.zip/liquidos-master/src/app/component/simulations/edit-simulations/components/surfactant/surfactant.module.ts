import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SurfactantComponent } from './surfactant.component';

import { HotTableModule } from '@handsontable/angular';
import { PanelBarModule } from '@progress/kendo-angular-layout';
import { DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { RippleModule } from '@progress/kendo-angular-ripple';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTabsModule } from '@angular/material/tabs';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HotTableModule,
    PanelBarModule,
    DropDownListModule,
    RippleModule,
    MatFormFieldModule,
    MatInputModule,
    MatExpansionModule,
    MatTabsModule
  ],
  declarations: [
    SurfactantComponent
  ],
  exports: [
    SurfactantComponent
  ]
})
export class SurfactantModule { }
