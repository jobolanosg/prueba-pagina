import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-polymer',
  templateUrl: './polymer.component.html',
  styleUrls: ['./polymer.component.scss']
})
export class PolymerComponent implements OnInit {

  @Input() settingsConfiguration: any = {};
  @Input() componentsData: any;
  @Output() componentsDataChange: EventEmitter<any> = new EventEmitter();

  polymerModel = ['Carreau'];
  polymer: any;
  toleranceTypeItems = ['IUTOL', 'STOL', 'RELTOL', 'INFTOL', 'ABSTOL', 'DXTOL', 'RXTOL'];
  settings = {
    rowHeaders: true,
    colHeaders: true,
    minRows: 1,
    minSpareRows: 1,
    startRows: 1,
    autoColumnSize: { syncLimit: '100%', useHeaders: true },
    contextMenu: ['row_above', 'row_below', 'remove_row'],
    height: 150,
    width: 800,
  };

  constructor() { }

  ngOnInit() {
    if (this.componentsData.polymer) {
      this.polymer = this.componentsData.polymer;
    } else {
      this.polymer = {
        properties: {
          density: '',
          specificGravity: '',
          molecularWeight: '',
          rrf: '',
          ipv: '',
        },
        kinetics: {
          adsorption: {
            equilibriumRateConstant: '',
            adjustParameter: '',
            adsorptionTable: [{
              concentration: '',
              kineticParameter: '',
              equilibriumAdsorbedPolymer: ''
            }]
          },
          degradation: {
            checked: false,
            quemicalDegradationConstant: '',
            degradationTable: [{
              degradationTemperature: '',
              activationEnergy: ''
            }],
            checkedPolyNanoSinergy: false,
            quemicalDegradationConstant2: '',
            polymerNanoparticleAdsorption: '',
          }
        },
        rheology: {
          model: '',
          consistencyIndexTable: [{
            concentration1: '',
            flowIndex1: '',
            viscosityAtRate01: '',
            consistencyIndex: ''
          }],
          relaxionTimeTable: [{
            concentration2: '',
            flowIndex2: '',
            viscosityAtRate02: '',
            relaxionTime: ''
          }],
          infinityViscosity: '',
          apparentShearRateParameter: '',
          adjustParameter: '',
          consistencyIndexChecked: false,
          relaxionTimeChecked: false,
          checkedRheologyPolyNanoSinergy: false,
          sinergyTable: [{
            concentration: '',
            factor: ''
          }]
        },
        numericalSettings: {
          toleranceType: '',
          tolerance: '',
          sequential: ''
        }
      };
    }
  }

  valueChange($event) {
    this.componentsData.polymer = this.polymer;
    this.componentsDataChange.emit(this.componentsData);
  }

  CarreauChange(option: string): void {
    if (option === 'relaxionTimeChecked') {
      this.polymer.rheology.relaxionTimeChecked = !this.polymer.rheology.relaxionTimeChecked;
      this.polymer.rheology.consistencyIndexChecked = false;
    }

    if (option === 'consistencyIndexChecked') {
      this.polymer.rheology.consistencyIndexChecked = !this.polymer.rheology.consistencyIndexChecked;
      this.polymer.rheology.relaxionTimeChecked = false;
    }

    this.valueChange('hey');
  }
}
