import { Component, OnInit, Input, Output, EventEmitter, DoCheck } from '@angular/core';

@Component({
  selector: 'app-surfactant',
  templateUrl: './surfactant.component.html',
  styleUrls: ['./surfactant.component.scss']
})
export class SurfactantComponent implements OnInit, DoCheck {

  constructor() { }

  @Input() settingsConfiguration: any;
  @Input() componentsData: any;
  @Output() componentsDataChange: EventEmitter<any> = new EventEmitter();

  propertiesPanelOpenState = false;
  surfactant: any;
  foamerModel = ['Kovscek', 'Kam'];
  foamerSeletedModel: string;
  toleranceTypeItems = ['IUTOL', 'STOL', 'RELTOL', 'INFTOL', 'ABSTOL', 'DXTOL', 'RXTOL'];
  sequentialItems = ['YES', 'NOT'];
  settings = {
    rowHeaders: true,
    colHeaders: true,
    minRows: 1,
    minSpareRows: 1,
    startRows: 1,
    autoColumnSize: { syncLimit: '100%', useHeaders: true },
    contextMenu: ['row_above', 'row_below', 'remove_row'],
    height: 150,
    width: 800,
  };

  ngOnInit() {
    if (this.componentsData.surfactant) {
      this.surfactant = this.componentsData.surfactant;
    } else {
      this.surfactant = {
        properties: {
          specificGravity: '',
          optimalConcentration: '',
          molecularWeight: ''
        },
        kinetics: {
          interception: {
            GasOil: '',
            GasWater: ''
          },
          dissolution: [{ chemicalConcentration: '', dilutedChemicalAtEquilibriumConcentration: '', kineticParameter: '' }],
          sorption: [{ chemicalConcentration: '', adsorbedChemicalAtEquilibriumConcentration: '', kineticParameter: '' }]
        },
        flowAlteration: this.getTable(),
        foamer: {
          addFoamer: false,
          specificGravity: '',
          optimalMiscellarConcentration: '',
          foamerModel: '',
          Kg_k: '',
          Kc_k: '',
          Alfa_k: '',
          Xt_Max: '',
          Beta_K: '',
          PcCr_Max: '',
          Ref_Foamer: '',
          Foam_corey: '',
          Surten: '',
          Grapo: '',
          Swc_K: ''
        },
        numericalSettings: {
          toleranceType: '',
          tolerance: '',
          sequential: ''
        },
        sorptionKValue: {
          temperatureKValueList: [0],
          temperatureKValue: Array(1).fill(this.getTemperatureKValueTable(0))
        }
      };
    }
  }

  ngDoCheck() {
    if (this.surfactant.foamer.foamerModel === 'Kovscek') {
      this.foamerSeletedModel = 'KovscekSelect';
    } else if (this.surfactant.foamer.foamerModel === 'Kam') {
      this.foamerSeletedModel = 'KamSelect';
    }
  }

  valueChange(data) {
    this.componentsData.surfactant = this.surfactant;
    this.componentsDataChange.emit(this.componentsData);
  }

  getTable() {
    let currentTable = [];
    if (this.settingsConfiguration.flowUnitsSelect) {
      currentTable = Array(this.settingsConfiguration.flowUnitsSelect.length);
      for (let i = 0; i < this.settingsConfiguration.flowUnitsSelect.length; i++) {
        currentTable[i] = { id: i, gasOilData: [this.getGasOilPropertiesTable(i)], oilWaterData: [this.getOilWaterPropertiesTable(i)] };
      }
    }
    return currentTable;
  }

  getGasOilPropertiesTable(index: number): any {
    const tableObject = {};
    Object.defineProperty(tableObject, `gasSaturation${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `gasRelativePermeability${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `oilRelativePermeabilityr${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `oilGasCapillaryPressure${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    return tableObject;
  }

  getOilWaterPropertiesTable(index: number): any {
    const tableObject = {};
    Object.defineProperty(tableObject, `waterSaturation${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `waterRelativePermeability${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `oilWaterRelativePermeabilityr${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `oilwaterCapillaryPressure${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    return tableObject;
  }

  addTemperatureKValue() {
    const temperatureKValueLength = this.surfactant.sorptionKValue.temperatureKValueList.length;
    this.surfactant.sorptionKValue.temperatureKValueList.push(temperatureKValueLength);
    this.surfactant.sorptionKValue.temperatureKValue.push(this.getTemperatureKValueTable(temperatureKValueLength));
    this.valueChange('added');
  }

  getTemperatureKValueTable(index: number): any {
    const temperatureKValueObject = {};
    const tableObject = {};

    Object.defineProperty(tableObject, `pressure${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `kValue${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(temperatureKValueObject, `temperatureKValue${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(temperatureKValueObject, `data${index}`, {
      value: Array(1).fill(tableObject),
      writable: true,
      enumerable: true,
      configurable: true
    });

    return temperatureKValueObject;
  }
}
