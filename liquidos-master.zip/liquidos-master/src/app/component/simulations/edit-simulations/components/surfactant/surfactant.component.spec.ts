import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SurfactantComponent } from './surfactant.component';

describe('SurfactantComponent', () => {
  let component: SurfactantComponent;
  let fixture: ComponentFixture<SurfactantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SurfactantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SurfactantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
