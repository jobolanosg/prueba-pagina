import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NanoparticleComponent } from './nanoparticle.component';

describe('NanoparticleComponent', () => {
  let component: NanoparticleComponent;
  let fixture: ComponentFixture<NanoparticleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NanoparticleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NanoparticleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
