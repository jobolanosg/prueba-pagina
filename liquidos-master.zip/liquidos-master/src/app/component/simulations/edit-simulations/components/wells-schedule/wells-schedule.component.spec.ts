import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WellsScheduleComponent } from './wells-schedule.component';

describe('WellsScheduleComponent', () => {
  let component: WellsScheduleComponent;
  let fixture: ComponentFixture<WellsScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WellsScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WellsScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
