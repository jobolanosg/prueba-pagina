import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ComponentsComponent } from './components.component';

import { TabStripModule } from '@progress/kendo-angular-layout';
import { DropDownListModule } from '@progress/kendo-angular-dropdowns';

import { MatExpansionModule } from '@angular/material/expansion';
import { HotTableModule } from '@handsontable/angular';

import { NanoparticleModule } from './nanoparticle/nanoparticle.module';
import { SurfactantModule } from './surfactant/surfactant.module';
import { WellsScheduleComponent } from './wells-schedule/wells-schedule.component';
import { PolymerModule } from './polymer/polymer.module';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    TabStripModule,
    NanoparticleModule,
    PolymerModule,
    SurfactantModule,
    DropDownListModule,
    MatExpansionModule,
    HotTableModule
  ],
  declarations: [
    ComponentsComponent,
    WellsScheduleComponent
  ],
  exports: [
    ComponentsComponent
  ]
})
export class ComponentsModule { }
