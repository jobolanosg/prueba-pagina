import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-thermal',
  templateUrl: './thermal.component.html',
  styleUrls: ['./thermal.component.scss']
})
export class ThermalComponent implements OnInit {

  constructor() { }

  @Input() thermalData: any;
  @Output() thermalDataChange: EventEmitter<string[]> = new EventEmitter();
  @Input() settingsConfiguration: any;
  thermal: any;

  ngOnInit() {
    if (this.thermalData) {
      this.thermal = this.thermalData;
    } else {
      this.thermal = {
        heatLoss: {
          heatCapacityOverburden: '',
          conductivityOverburden: '',
          heatCapacityUnderburden: '',
          conductivityUnderburden: '',
          temperatureOverburden: '',
          gradientOverburden: ''
        },
        properties: {
          thermalModel: '',
          data: this.getProperties()
        }
      };
    }
  }

  getProperties() {
    if (this.settingsConfiguration.flowUnitsSelect && this.settingsConfiguration.flowUnitsSelect.length) {
      const dataArray = Array(this.settingsConfiguration.flowUnitsSelect.length);
      for (let flowUnitIndex = 0; flowUnitIndex < this.settingsConfiguration.flowUnitsSelect.length; flowUnitIndex++) {
        dataArray[flowUnitIndex] = {
          oilConductivity: '',
          gasConductivity: '',
          waterConductivity: '',
          rockConductivity: '',
          rockHeatCapacity: '',
          porosityChangeThermalCoefficient: '',
          referenceTemperature: ''
        };
      }
      return dataArray;
    } else {
      return [];
    }
  }

  valueChange(eventData) {
    this.thermalData = this.thermal;
    this.thermalDataChange.emit(this.thermalData);
  }

}
