import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ThermalComponent } from './thermal.component';

import { TabStripModule } from '@progress/kendo-angular-layout';
import { DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatExpansionModule } from '@angular/material/expansion';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    TabStripModule,
    DropDownListModule,
    MatFormFieldModule,
    MatInputModule,
    MatExpansionModule
  ],
  declarations: [
    ThermalComponent
  ],
  exports: [
    ThermalComponent
  ]
})
export class ThermalModule { }
