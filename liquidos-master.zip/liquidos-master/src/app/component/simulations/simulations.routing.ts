import { Routes, RouterModule } from '@angular/router';

import { SimulationsComponent } from './simulations.component';
import { AuthGuard } from '../../guards/auth.guard';

const simulationsRoutes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    canActivate: [AuthGuard],
    component: SimulationsComponent
  },
  {
    path: 'projects',
    pathMatch: 'full',
    canActivate: [AuthGuard],
    component: SimulationsComponent
  }
];

export const SimulationsRoutes = RouterModule.forChild(simulationsRoutes);
