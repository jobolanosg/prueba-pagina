import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ProjectListModule } from './project-list/project-list.module';

import { SimulationsComponent } from './simulations.component';

import { IdSeeUserPipe } from '../../pipes/idSeeUser.pipe';
import { GetNamePipe } from '../../pipes/getName.pipe';
import { LogPipe } from '../../pipes/log.pipe';
import { PropertiesNameExtended } from '../../pipes/propertiesNameExtended.pipe';

import { SimulationsRoutes } from './simulations.routing';

import { WindowModule } from '@progress/kendo-angular-dialog';
import { TabStripModule } from '@progress/kendo-angular-layout';
import { DropDownListModule, MultiSelectModule } from '@progress/kendo-angular-dropdowns';
import { TextBoxModule } from '@progress/kendo-angular-inputs';
import { NotificationModule } from '@progress/kendo-angular-notification';

import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NavModule } from '../nav/nav.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ProjectListModule,
    WindowModule,
    TabStripModule,
    DropDownListModule,
    MultiSelectModule,
    NotificationModule,
    TextBoxModule,
    SimulationsRoutes,
    MatProgressSpinnerModule,
    NavModule
  ],
  declarations: [
    SimulationsComponent,
    IdSeeUserPipe,
    GetNamePipe,
    LogPipe,
    PropertiesNameExtended
  ]
})
export class SimulationsModule { }
