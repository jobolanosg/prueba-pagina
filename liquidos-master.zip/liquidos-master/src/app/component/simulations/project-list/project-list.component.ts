import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-project-list',
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.scss']
})
export class ProjectListComponent implements OnInit {
  @Input() projects: Array<Object>;
  @Output() selected: EventEmitter<string> = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }

  handleSelection(data: any): void {
    if (data.dataItem.text === 'Projects') {
    } else {
      this.selected.emit(data.dataItem.text);
    }
  }
}
