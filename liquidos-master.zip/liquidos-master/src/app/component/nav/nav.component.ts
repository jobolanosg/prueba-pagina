import { Router } from '@angular/router';
import { Component, DoCheck, OnInit } from '@angular/core';

import { LogoutUser } from '../../store/actions/user.actions';
import { AuthService } from '../../service/auth/auth.service';
import { UserState } from 'src/app/store/state/user.state';
import { Store, Select } from '@ngxs/store';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent implements DoCheck, OnInit {

  logged: boolean;
  username = '';
  email = '';
  @Select(UserState.getUser) user$: Observable<any>;

  constructor(private Auth: AuthService,
    private router: Router, private store: Store) {
    this.user$.subscribe(user => {
      this.username = user.username;
      this.email = user.email;
    });
  }

  ngDoCheck(): void {
    this.logged = Boolean(this.store.selectSnapshot(UserState.getToken));
  }

  ngOnInit(): void {
    // const user = this.store.selectSnapshot<{ username: string; email: string; }>(UserState.getUser);
    // if (this.router.url === '') {
    //   this.logout();
    // }
    // if (user) {
    //   this.username = user.username;
    //   this.email = user.email;
    // } else {
    //   const userForced = this.store.selectSnapshot<{ username: string; email: string; }>(UserState.getUser);
    //   while (!userForced) {
    //     this.username = userForced.username;
    //     this.email = userForced.email;
    //   }
    // }

  }

  simulations() {
    this.router.navigate(['mysimulations']);
  }

  user() {
    this.router.navigate(['user']);
  }

  logout() {
    this.Auth.postLogout(this.store.selectSnapshot(UserState.getToken)).subscribe(response => { });
    this.store.dispatch(new LogoutUser());
    this.router.navigate(['']);
  }
}
