import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import axios from 'axios';
import { AxiosPromise } from 'axios';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';

import { Simulations } from '../../models/simulations.model';

import { Store } from '@ngxs/store';
import { UserState } from '../../store/state/user.state';

import { environment } from '../../environments/environment';

const headers: HttpHeaders = new HttpHeaders({
  'Content-Type': 'application/json'
});

@Injectable({
  providedIn: 'root'
})

export class SimulationsService {

  public urlApi: string = environment.urlApi;
  public getToken: string = this.store.selectSnapshot(UserState.getToken);


  constructor(private http: HttpClient, private store: Store) { }

  getSimulations(): Observable<Simulations> {
    return this.http.post<Simulations>(
      `${this.urlApi}/simulation`,
      {
        'token': this.getToken
      },
      { headers: headers });
  }

  createSimulations(name: Simulations['name'], description: Simulations['description'], project_id: Simulations['project_id'], collaborators: Simulations['collaborators'], type: Simulations['type']): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApi}/simulation/new`,
      {
        'name': name,
        'description': description,
        'project_id': project_id,
        'collaborators': collaborators,
        'type': type,
        'token': this.getToken
      },
      { headers: headers });
  }

  seeSimulations(simulation_id: Simulations['_id']): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApi}/simulation/${simulation_id}`,
      {
        'token': this.getToken
      },
      { headers: headers });

  }

  updateSimulations(simulation_id: Simulations['_id'], name: Simulations['name'], description: Simulations['description'], project_id: Simulations['project_id'], collaborators: Simulations['collaborators'], type: Simulations['type']): AxiosPromise<Response> {
    const newSimulations = {
      'name': name,
      'description': description,
      'project_id': project_id,
      'collaborators': collaborators,
      'type': type,
      'token': this.getToken
    };
    return axios.put(`${this.urlApi}/simulation/${simulation_id}`, newSimulations);
  }

  deleteSimulations(simulation_id: Simulations['_id'], confirmation: any) {
    const deletedSimulations: any = {
      ...confirmation,
      'token': this.getToken
    };
    return axios.delete(`${this.urlApi}/simulation/${simulation_id}`, { data: deletedSimulations });
  }

  executeSimulations(data: any): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApi}/simulation/execute/`,
      {
        ...data
      },
      { headers: headers });
  }

  downloadSimulations(id: Simulations['_id']) {
    return this.http.post(
      `${this.urlApi}/simulation/download/`,
      {
        'id': id,
        'token': this.getToken
      },
      {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Accept': 'application/zip'
        }),
        responseType: 'blob'
      }).pipe(map((response) => {
        if (response instanceof Response) {
          return response.blob();
        }
        return response;
      }));
  }

  checkSimulations(id: Simulations['_id']): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApi}/simulation/check/`,
      {
        'id': id,
        'token': this.getToken
      },
      { headers: headers });
  }

  getDataFromWells(id: Simulations['_id']): Observable<Response> {
    return this.http.post<Response>(
      `${this.urlApi}/simulation/wells/`,
      {
        'id': id,
        'token': this.getToken
      },
      { headers: headers });
  }
}
