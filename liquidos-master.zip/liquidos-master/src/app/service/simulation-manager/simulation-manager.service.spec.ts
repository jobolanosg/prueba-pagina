import { TestBed } from '@angular/core/testing';

import { SimulationManagerService } from './simulation-manager.service';

describe('SimulationManagerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SimulationManagerService = TestBed.get(SimulationManagerService);
    expect(service).toBeTruthy();
  });
});
