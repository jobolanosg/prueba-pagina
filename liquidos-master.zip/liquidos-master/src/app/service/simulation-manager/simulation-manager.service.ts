import { Injectable } from '@angular/core';
import * as io from 'socket.io-client';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
import axios from 'axios';
import { Store } from '@ngxs/store';
import { AddRunningSimulation, RemoveRunningSimulation, UpdateStatusRunningSimulation } from '../../store/actions/app.actions';
import { UserState } from '../../store/state/user.state';
import { Simulations } from '../../models/simulations.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const headers: HttpHeaders = new HttpHeaders({
  'Content-Type': 'application/json'
});

@Injectable({
  providedIn: 'root'
})
export class SimulationManagerService {

  public urlApi: string = environment.urlApi;
  public getToken: string = this.store.selectSnapshot(UserState.getToken);
  private socket;

  constructor(private http: HttpClient, private store: Store) {
    // this.socket = io(environment.urlSocket);
  }

  updateStatusFromRunningSimulation(simulation_id: Simulations['_id'], status: string): Observable<any> {
    return this.store.dispatch(new UpdateStatusRunningSimulation(simulation_id, status));
  }

  getDataFromRunningSimulation(simulation_id: Simulations['_id']): Observable<any> {
    return this.http.post<Response>(
      `${this.urlApi}/simulation/progress/${simulation_id}`,
      {
        'token': this.getToken
      },
      { headers: headers });
  }

  removeRunningSimulation(simulation_id: Simulations['_id']): Observable<any> {
    this.store.dispatch(new RemoveRunningSimulation(simulation_id));
    return this.http.post<Response>(
      `${this.urlApi}/simulation/remove/${simulation_id}`,
      {
        'token': this.getToken
      },
      { headers: headers });
  }

  seeLog(simulation_id: Simulations['_id']): Observable<any> {
    return this.http.post<Response>(
      `${this.urlApi}/simulation/log/${simulation_id}`,
      {
        'token': this.getToken
      },
      { headers: headers });
  }

  seeError(simulation_id: Simulations['_id']): Observable<any> {
    return this.http.post<Response>(
      `${this.urlApi}/simulation/error/${simulation_id}`,
      {
        'token': this.getToken
      },
      { headers: headers });
  }

  fulminateRunningSimulation(simulation_id: Simulations['_id']): Observable<any> {
    this.store.dispatch(new RemoveRunningSimulation(simulation_id));
    return this.http.post<Response>(
      `${this.urlApi}/simulation/fulminate`,
      {
        'id': simulation_id,
        'token': this.getToken
      },
      { headers: headers });
  }

}
