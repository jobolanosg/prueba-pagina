const path = require('path')
const chai = require('chai')

const sinon = require('sinon')
require('sinon-mongoose')
const simulation = require(path.resolve('./test', '../models/simulation'))

const expect = chai.expect

describe('Simulation Models Unit Tests', () => {
  it('Should return "SimulationName1", "An simulation" and Ids', (done) => {
    let simulationMock = sinon.mock(simulation)
    let expected = {
      name: 'SimulationName1',
      description: 'An simulation',
      project_id: 'mVX5rjaW8fGexnEJyzegXBUx',
      collaborators: [
        {
          user_id: 'wttVurEs5KLXPUkmbPfe86fE',
          permission: Math.random() % 2 === 0
            ? 'r'
            : 'rw'
        }
      ],
      type: 'Chemical EOR'
    }
    simulationMock.expects('find').yields(null, expected)
    simulation.find((err, result) => {
      simulationMock.verify()
      simulationMock.restore()
      expect(err).to.be.null
      expect(result.name).to.be.a('string').that.equal('SimulationName1')
      expect(result.description).to.be.a('string').that.equal('An simulation')
      expect(result.type).to.be.a('string').that.equal('Chemical EOR')
      expect(result).to.have.not.undefined
      expect(result.collaborators).to.be.a('array')
      result.collaborators.every((collaboratorsObject) => {
        return expect(collaboratorsObject.user_id).to.be.not.undefined && expect(collaboratorsObject.permission).to.satisfy((val) => {
          return val === 'r' || val === 'rw'
        })
      })
      done()
    })
  })
})
