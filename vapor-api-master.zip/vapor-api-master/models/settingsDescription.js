const mongoose = require('mongoose')

let settingsDescriptionSchema = mongoose.Schema({
  simulation_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Simulation',
    required: true,
    unique: true
  },
  workUnits: String,
  fluidModel: {
    type: String,
    enum: ['Blackoil', 'Gas Condensate']
  },
  dualPorosityDualPermeability: Boolean,
  flowUnitsName: [String],
  components: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Component' }]
}, { timestamps: true })

module.exports = mongoose.model('SettingsDescription', settingsDescriptionSchema)
