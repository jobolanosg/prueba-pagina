const cluster = require('cluster')
const cCPUs = require('os').cpus().length

if (cluster.isMaster) {
  console.log(`Master ${process.pid} is running`)
  if (cCPUs <= 3) {
    cluster.fork()
  } else {
    for (let i = 0; i < cCPUs - 3; i++) {
      cluster.fork()
    }
  }

  cluster.on('online', function (worker) {
    console.log(`Worker ${worker.process.pid} is online.`)
  })
  cluster.on('exit', function (worker, code, signal) {
    console.log(`Worker ${worker.process.pid} died with code/signal ${signal || code}. Restarting worker...`)
    cluster.fork()
  })
} else {
  require('./executor.js')
}
