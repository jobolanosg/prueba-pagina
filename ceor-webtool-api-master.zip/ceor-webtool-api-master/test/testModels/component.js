const path = require('path')
const chai = require('chai')

const sinon = require('sinon')
require('sinon-mongoose')
const component = require(path.resolve('./test', '../models/component'))

const expect = chai.expect

describe('Component Model Unit Tests', () => {
  it('Should return "Exergy"', (done) => {
    let componentMock = sinon.mock(component)
    let expected = {
      name: 'Exergy'
    }
    componentMock.expects('find').yields(null, expected)
    component.find((err, result) => {
      componentMock.verify()
      componentMock.restore()
      expect(err).to.be.null
      expect(result.name).to.be.equal('Exergy')
      done()
    })
  })
})
