const path = require('path')
const chai = require('chai')

const sinon = require('sinon')
require('sinon-mongoose')
const wellsAndTimeDescription = require(path.resolve('./test', '../models/wellsAndTimeDescription'))

const expect = chai.expect

describe('Wells And Time Description Model Unit Tests', () => {
  it('Should return a "wellsAndTimeDescription" object', (done) => {
    let wellsAndTimeDescriptionMock = sinon.mock(wellsAndTimeDescription)
    let expected = {
      simulation_id: 'YXRGphRJjjHdaQea6rvbqmKG',
      times: [
        1, 3, 5, 7, 9
      ],
      timesWithChange: [
        2, 4, 6, 8
      ],
      schedule: [
        {
          time: 12,
          wellIndex: 87,
          typeOfWell: Math.random() % 2 === 0
            ? 'Producer'
            : 'Injector',
          injectedFluid: 'Water',
          wellRadius: 45,
          skin: 1,
          operativeConditionType: 'New',
          operativeConditionValue: 32,
          scheduleType: 'Periodic',
          numberOfPerforations: 12,
          perforations: [
            {
              iIndex: 47,
              jIndex: 78,
              kIndex: 25
            }
          ]
        }
      ]
    }
    wellsAndTimeDescriptionMock.expects('find').yields(null, expected)
    wellsAndTimeDescription.find((err, result) => {
      wellsAndTimeDescriptionMock.verify()
      wellsAndTimeDescriptionMock.restore()
      expect(err).to.be.null
      expect(result.simulation_id).to.be.not.undefined
      expect(result.times).to.be.a('array')
      expect(result.timesWithChange).to.be.a('array')
      expect(result.schedule).to.be.a('array')
      result.schedule.every((scheduleObject) => {
        expect(scheduleObject.time).to.be.a('number').which.be.equal(12)
        expect(scheduleObject.wellIndex).to.be.a('number').which.be.equal(87)
        expect(scheduleObject.typeOfWell).to.satisfy((val) => {
          return val === 'Producer' || val === 'Injector'
        })
        expect(scheduleObject.injectedFluid).to.be.a('string').which.be.equal('Water')
        expect(scheduleObject.wellRadius).to.be.a('number').which.be.equal(45)
        expect(scheduleObject.skin).to.be.a('number').which.be.equal(1)
        expect(scheduleObject.operativeConditionType).to.be.a('string').which.be.equal('New')
        expect(scheduleObject.operativeConditionValue).to.be.a('number').which.be.equal(32)
        expect(scheduleObject.scheduleType).to.be.a('string').which.be.equal('Periodic')
        expect(scheduleObject.numberOfPerforations).to.be.a('number').which.be.equal(12)
        expect(scheduleObject.perforations).to.be.a('array')
        scheduleObject.perforations.every((perforationsObject) => {
          expect(perforationsObject.iIndex).to.be.a('number').which.be.equal(47)
          expect(perforationsObject.jIndex).to.be.a('number').which.be.equal(78)
          expect(perforationsObject.kIndex).to.be.a('number').which.be.equal(25)
          return true
        })
        return true
      })
      done()
    })
  })
})
