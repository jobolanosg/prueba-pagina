const path = require('path')
const chai = require('chai')

const sinon = require('sinon')
require('sinon-mongoose')
const fluidsDescription = require(path.resolve('./test', '../models/fluidsDescription'))

const expect = chai.expect

describe('Fluids Description Model Unit Tests', () => {
  it('Should return a "fluidsDescription" Object', (done) => {
    let fluidsDescriptionMock = sinon.mock(fluidsDescription)
    let expected = {
      simulation_id: 'ZmpjzUEJaLLuUEzktd8e6u6z',
      fluidsDescriptionByFlowUnit: [
        {
          pvtTable:
            {
              pressure: [
                1, 5
              ],
              solutionGas: [
                1, 8, 9
              ],
              volatilizedOil: [
                20, 56
              ],
              oilVolumetricFactor: [
                0, 45
              ],
              gasVolumetricFactor: [
                98, 67, 67
              ],
              oilViscosity: [
                45, 793
              ],
              gasViscosity: [7830, 334]
            },
          waterProperties:
            {
              referencePressure: 23,
              volumetricFactor: 45,
              viscosity: 65,
              compressibility: 453,
              viscosityDependencePressure: 23
            },
          gasDensity: 87,
          oilDensity: 344,
          waterDensity: 45,
          equationOfState: 'Peng-Robinson',
          componentsProperties:
            {
              name: [
                'Exergy', ''
              ],
              acentricFactor: [
                1.8, 12, 4
              ],
              criticalPressure: [
                25, 34
              ],
              criticalTemperature: [
                89, 53
              ],
              criticalVolume: [
                67, 89
              ],
              molecularWeight: [12, 8]
            },
          binaryInteractionCoefficients: [
            0.54, 0
          ],
          waterPropertiesCompositional:
            {
              referencePressure: 84,
              volumetricFactor: 8514,
              viscosity: 15,
              viscosityDependencePressure: 78,
              density: 23,
              acentricFactor: 5489,
              criticalPressure: 78,
              criticalTemperature: 44,
              criticalVolume: 1566,
              molecularWeight: 615
            }

        }
      ]
    }
    fluidsDescriptionMock.expects('find').yields(null, expected)
    fluidsDescription.find((err, result) => {
      fluidsDescriptionMock.verify()
      fluidsDescriptionMock.restore()
      expect(err).to.be.null
      expect(result.simulation_id).to.be.not.undefined
      result.fluidsDescriptionByFlowUnit.every((fluidsDescriptionByFlowUnitObject) => {
        expect(fluidsDescriptionByFlowUnitObject.pvtTable).to.be.a('Object')
        expect(fluidsDescriptionByFlowUnitObject.pvtTable).to.have.property('pressure' && 'solutionGas' && 'volatilizedOil' && 'oilVolumetricFactor' && 'gasVolumetricFactor' && 'oilViscosity' && 'gasViscosity')

        expect(fluidsDescriptionByFlowUnitObject.waterProperties).to.be.a('Object')
        expect(fluidsDescriptionByFlowUnitObject.waterProperties).to.have.property('referencePressure' && 'volumetricFactor' && 'viscosity' && 'compressibility' && 'viscosityDependencePressure')

        expect(fluidsDescriptionByFlowUnitObject.gasDensity).to.be.a('number').which.is.equal(87)
        expect(fluidsDescriptionByFlowUnitObject.oilDensity).to.be.a('number').which.is.equal(344)
        expect(fluidsDescriptionByFlowUnitObject.waterDensity).to.be.a('number').which.is.equal(45)

        expect(fluidsDescriptionByFlowUnitObject.equationOfState).to.be.equal('Peng-Robinson')

        expect(fluidsDescriptionByFlowUnitObject.componentsProperties).to.be.a('Object')
        expect(fluidsDescriptionByFlowUnitObject.componentsProperties).to.have.property('name' && 'acentricFactor' && 'criticalPressure' && 'criticalTemperature' && 'criticalVolume' && 'molecularWeight')

        expect(fluidsDescriptionByFlowUnitObject.binaryInteractionCoefficients).to.be.a('array')

        expect(fluidsDescriptionByFlowUnitObject.waterPropertiesCompositional).to.be.a('Object')
        expect(fluidsDescriptionByFlowUnitObject.waterPropertiesCompositional).to.have.property('referencePressure' && 'volumetricFactor' && 'viscosity' && 'viscosityDependencePressure' && 'density' && 'acentricFactor' && 'criticalPressure' && 'criticalTemperature' && 'criticalVolume' && 'molecularWeight')
      })
      done()
    })
  })
})
