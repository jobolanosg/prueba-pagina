const express = require('express')
const app = express()
const morgan = require('morgan')
const mongoose = require('mongoose')
const config = require('./config')
const helmet = require('helmet')
const compression = require('compression')
const logger = require('./helpers/logger')
const path = require('path')
const passport = require('passport')
const contentLength = require('express-content-length-validator')
const cors = require('cors')
const nocache = require('nocache');                             // <---sudo npm i nocache

app.set('env', config.ENV)
app.set('case sensitive routing', false)
app.set('strict routing', false)

app.use(helmet())

//app.use(helmet.noCache())
app.use(nocache())                                             // Agregar ésta línea luego de instalar el "nocache" paquete
app.use(helmet.referrerPolicy())
app.use(cors())
app.use(helmet.contentSecurityPolicy({
  directives: {
    defaultSrc: ["'self'"]
  }
}))
app.use(helmet.permittedCrossDomainPolicies())
app.use(compression())

app.use(morgan(config.LOG.ENV, { stream: logger.stream }))

mongoose.connect(config.DATABASE.NAME, config.DATABASE.OPTIONS)
  .then(() => logger.log('info', 'Connection successful with MongoDB'))
  .catch((err) => logger.error(`${err.status || 500} - ${err.message}`))

app.use(contentLength.validateMax({ max: 99999, status: 400, message: 'Stop it!' }))

app.use(require('./middlewares/parser.js').parseJson)
app.use(require('./middlewares/parser.js').parseUrlencoded)

app.use(express.static(path.resolve(__dirname, '/public')))

app.use(passport.initialize())
app.use(passport.session())

app.use('/api/', require('./routes/user.routes'))
app.use('/api/', require('./routes/component.routes'))
app.use('/api/', require('./routes/project.routes'))
app.use('/api/', require('./routes/simulation.routes'))
app.use('/api/', require('./routes/temporary.routes'))
app.use('/api/', require('./routes/descriptions.routes'))

app.use(function (err, req, res, next) {
  res.locals.message = err.message
  res.locals.error = config.ENV === 'dev' ? err : {}
  logger.error(`${err.status || 500} - ${err.message} - ${req.originalUrl} - ${req.method} - ${req.ip}`)
  res.status(err.status || 500).json({ error: `a error was been found - ${err}` })
})

module.exports = app
