const logger = require('../helpers/logger')
const mongoose = require('mongoose')
const FluidsDescription = require('../models/fluidsDescription')
const InitialConditionsDescription = require('../models/initialConditionsDescription')
const NumericalControlDescription = require('../models/numericalControlDescription')
const ReservoirDescription = require('../models/reservoirDescription')
const RockFluidDescription = require('../models/rockFluidDescription')
const WellsAndTimeDescription = require('../models/wellsAndTimeDescription')
const SettingsDescription = require('../models/settingsDescription')
const validator = require('validator')

let descriptionValidator = {
  reservoirDescriptionValidator: function (reservoirDescriptionBodyData) {
    return {
      simulation_id: new mongoose.mongo.ObjectId(validator.trim(validator.escape(reservoirDescriptionBodyData.simulation_id))),
      mesh: {
        type: validator.trim(validator.escape(reservoirDescriptionBodyData.mesh.type)),
        internalRadius: reservoirDescriptionBodyData.mesh.internalRadius,
        externalRadius: reservoirDescriptionBodyData.mesh.externalRadius,
        iLength: {
          type: reservoirDescriptionBodyData.mesh.iLength.type,
          values: reservoirDescriptionBodyData.mesh.iLength.values
        },
        jLength: {
          type: reservoirDescriptionBodyData.mesh.jLength.type,
          values: reservoirDescriptionBodyData.mesh.jLength.values
        },
        kLength: {
          type: reservoirDescriptionBodyData.mesh.kLength.type,
          values: reservoirDescriptionBodyData.mesh.kLength.values
        },
        top: {
          type: reservoirDescriptionBodyData.mesh.top.type,
          values: reservoirDescriptionBodyData.mesh.top.values
        },
        iPermeability: {
          type: reservoirDescriptionBodyData.mesh.iPermeability.type,
          values: reservoirDescriptionBodyData.mesh.iPermeability.values
        },
        jPermeability: {
          type: reservoirDescriptionBodyData.mesh.jPermeability.type,
          values: reservoirDescriptionBodyData.mesh.jPermeability.values
        },
        kPermeability: {
          type: reservoirDescriptionBodyData.mesh.kPermeability.type,
          values: reservoirDescriptionBodyData.mesh.kPermeability.values
        },
        porosity: {
          type: reservoirDescriptionBodyData.mesh.porosity.type,
          values: reservoirDescriptionBodyData.mesh.porosity.values
        },
        activeBlock: {
          type: reservoirDescriptionBodyData.mesh.activeBlock.type,
          values: reservoirDescriptionBodyData.mesh.activeBlock.values
        },
        flowUnit: {
          type: reservoirDescriptionBodyData.mesh.flowUnit.type,
          values: reservoirDescriptionBodyData.mesh.flowUnit.values
        }
      },
      poreCompressibility: reservoirDescriptionBodyData.poreCompressibility,
      referencePressure: reservoirDescriptionBodyData.referencePressure,
      matrixDensity: reservoirDescriptionBodyData.matrixDensity
    }
  },
  fluidsDescriptionValidator: function (fluidsDescriptionBodyData) {
    let fluidsDescriptionByFlowUnit = []
    let fluidsDescriptionByFlowUnitlength = fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit.length
    for (let fluidsDescriptionByFlowUnitIndex = 0; fluidsDescriptionByFlowUnitIndex < fluidsDescriptionByFlowUnitlength; fluidsDescriptionByFlowUnitIndex++) {
      fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex] = {
        pvtTable: {
          pressure: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].pvtTable.pressure,
          solutionGas: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].pvtTable.solutionGas,
          volatilizedOil: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].pvtTable.volatilizedOil,
          oilVolumetricFactor: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].pvtTable.oilVolumetricFactor,
          gasVolumetricFactor: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].pvtTable.gasVolumetricFactor,
          oilViscosity: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].pvtTable.oilViscosity,
          gasViscosity: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].pvtTable.gasViscosity
        },
        waterProperties: {
          referencePressure: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterProperties.referencePressure,
          volumetricFactor: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterProperties.volumetricFactor,
          viscosity: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterProperties.viscosity,
          compressibility: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterProperties.compressibility,
          viscosityDependencePressure: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterProperties.viscosityDependencePressure
        },
        gasDensity: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].gasDensity,
        oilDensity: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].oilDensity,
        waterDensity: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterDensity,
        equationOfState: validator.trim(validator.escape(fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].equationOfState)),
        componentsProperties: {
          name: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].componentsProperties.name,
          acentricFactor: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].componentsProperties.acentricFactor,
          criticalPressure: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].componentsProperties.criticalPressure,
          criticalTemperature: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].componentsProperties.criticalTemperature,
          criticalVolume: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].componentsProperties.criticalVolume,
          molecularWeight: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].componentsProperties.molecularWeight
        },
        binaryInteractionCoefficients: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].binaryInteractionCoefficients,
        waterPropertiesCompositional: {
          referencePressure: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterPropertiesCompositional.referencePressure,
          volumetricFactor: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterPropertiesCompositional.volumetricFactor,
          viscosity: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterPropertiesCompositional.viscosity,
          viscosityDependencePressure: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterPropertiesCompositional.viscosityDependencePressure,
          density: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterPropertiesCompositional.density,
          acentricFactor: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterPropertiesCompositional.acentricFactor,
          criticalPressure: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterPropertiesCompositional.criticalPressure,
          criticalTemperature: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterPropertiesCompositional.criticalTemperature,
          criticalVolume: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterPropertiesCompositional.criticalVolume,
          molecularWeight: fluidsDescriptionBodyData.fluidsDescriptionByFlowUnit[fluidsDescriptionByFlowUnitIndex].waterPropertiesCompositional.molecularWeight
        }
      }
    }
    return {
      simulation_id: new mongoose.mongo.ObjectId(validator.trim(validator.escape(fluidsDescriptionBodyData.simulation_id))),
      fluidsDescriptionByFlowUnit: fluidsDescriptionByFlowUnit
    }
  },
  rockFluidDescriptionValidator: function (rockFluidDescriptionBodyData) {
    let rockFluidDescriptionByFlowUnit = []
    let rockFluidDescriptionLength = rockFluidDescriptionBodyData.rockFluidDescriptionByFlowUnit.length
    for (let rockFluidDescriptionByFlowUnitIndex = 0; rockFluidDescriptionByFlowUnitIndex < rockFluidDescriptionLength; rockFluidDescriptionByFlowUnitIndex++) {
      rockFluidDescriptionByFlowUnit[rockFluidDescriptionByFlowUnitIndex] = {
        gasOilRockFluid: {
          gasSaturation: rockFluidDescriptionBodyData.rockFluidDescriptionByFlowUnit[rockFluidDescriptionByFlowUnitIndex].gasOilRockFluid.gasSaturation,
          gasRelativePermeability: rockFluidDescriptionBodyData.rockFluidDescriptionByFlowUnit[rockFluidDescriptionByFlowUnitIndex].gasOilRockFluid.gasRelativePermeability,
          oilRelativePermeability: rockFluidDescriptionBodyData.rockFluidDescriptionByFlowUnit[rockFluidDescriptionByFlowUnitIndex].gasOilRockFluid.oilRelativePermeability,
          gasOilCapillaryPressure: rockFluidDescriptionBodyData.rockFluidDescriptionByFlowUnit[rockFluidDescriptionByFlowUnitIndex].gasOilRockFluid.gasOilCapillaryPressure
        },
        waterOilRockFluid: {
          waterSaturation: rockFluidDescriptionBodyData.rockFluidDescriptionByFlowUnit[rockFluidDescriptionByFlowUnitIndex].waterOilRockFluid.waterSaturation,
          waterRelativePermeability: rockFluidDescriptionBodyData.rockFluidDescriptionByFlowUnit[rockFluidDescriptionByFlowUnitIndex].waterOilRockFluid.waterRelativePermeability,
          oilRelativePermeability: rockFluidDescriptionBodyData.rockFluidDescriptionByFlowUnit[rockFluidDescriptionByFlowUnitIndex].waterOilRockFluid.oilRelativePermeability,
          oilWaterCapillaryPressure: rockFluidDescriptionBodyData.rockFluidDescriptionByFlowUnit[rockFluidDescriptionByFlowUnitIndex].waterOilRockFluid.oilWaterCapillaryPressure
        }
      }
    }
    return {
      simulation_id: new mongoose.mongo.ObjectId(validator.trim(validator.escape(rockFluidDescriptionBodyData.simulation_id))),
      rockFluidDescriptionByFlowUnit: rockFluidDescriptionByFlowUnit
    }
  },
  initialConditionsDescriptionValidator: function (initialConditionsDescriptionBodyData) {
    let gravcapequDataByFlowUnit = []
    let initialConditionsDescriptionLength = initialConditionsDescriptionBodyData.gravcapequDataByFlowUnit.length
    for (let gravcapequDataByFlowUnitIndex = 0; gravcapequDataByFlowUnitIndex < initialConditionsDescriptionLength; gravcapequDataByFlowUnitIndex++) {
      gravcapequDataByFlowUnit[gravcapequDataByFlowUnitIndex] = {
        referencePressure: initialConditionsDescriptionBodyData.gravcapequDataByFlowUnit[gravcapequDataByFlowUnitIndex].referencePressure,
        referenceDepth: initialConditionsDescriptionBodyData.gravcapequDataByFlowUnit[gravcapequDataByFlowUnitIndex].referenceDepth,
        gasOilContactDepth: initialConditionsDescriptionBodyData.gravcapequDataByFlowUnit[gravcapequDataByFlowUnitIndex].gasOilContactDepth,
        oilWaterContactDepth: initialConditionsDescriptionBodyData.gravcapequDataByFlowUnit[gravcapequDataByFlowUnitIndex].oilWaterContactDepth,
        oilResidualSaturationAtGasZone: initialConditionsDescriptionBodyData.gravcapequDataByFlowUnit[gravcapequDataByFlowUnitIndex].oilResidualSaturationAtGasZone,
        oilResidualSaturationAtWaterzone: initialConditionsDescriptionBodyData.gravcapequDataByFlowUnit[gravcapequDataByFlowUnitIndex].oilResidualSaturationAtWaterzone
      }
    }
    let gravcapequCompDepthDataByFlowUnit = []
    let initialConditionsDescriptionGravcapequCompDepthDataByFlowUnitLength = initialConditionsDescriptionBodyData.gravcapequCompDepthDataByFlowUnit.length
    for (let gravcapequCompDepthDataByFlowUnitIndex = 0; gravcapequCompDepthDataByFlowUnitIndex < initialConditionsDescriptionGravcapequCompDepthDataByFlowUnitLength; gravcapequCompDepthDataByFlowUnitIndex++) {
      gravcapequCompDepthDataByFlowUnit[gravcapequCompDepthDataByFlowUnitIndex] = {
        referencePressure: initialConditionsDescriptionBodyData.gravcapequCompDepthDataByFlowUnit[gravcapequCompDepthDataByFlowUnitIndex].referencePressure,
        referenceDepth: initialConditionsDescriptionBodyData.gravcapequCompDepthDataByFlowUnit[gravcapequCompDepthDataByFlowUnitIndex].referenceDepth,
        thermalGradient: initialConditionsDescriptionBodyData.gravcapequCompDepthDataByFlowUnit[gravcapequCompDepthDataByFlowUnitIndex].thermalGradient,
        referenceTemperature: initialConditionsDescriptionBodyData.gravcapequCompDepthDataByFlowUnit[gravcapequCompDepthDataByFlowUnitIndex].referenceTemperature,
        oilResidualSaturationAtGasZone: initialConditionsDescriptionBodyData.gravcapequCompDepthDataByFlowUnit[gravcapequCompDepthDataByFlowUnitIndex].oilResidualSaturationAtGasZone,
        oilResidualSaturationAtWaterzone: initialConditionsDescriptionBodyData.gravcapequCompDepthDataByFlowUnit[gravcapequCompDepthDataByFlowUnitIndex].oilResidualSaturationAtWaterzone
      }
    }
    return {
      simulation_id: new mongoose.mongo.ObjectId(validator.trim(validator.escape(initialConditionsDescriptionBodyData.simulation_id))),
      type: validator.trim(validator.escape(initialConditionsDescriptionBodyData.type)),
      gravcapequDataByFlowUnit: gravcapequDataByFlowUnit,
      pressure: {
        type: validator.trim(validator.escape(initialConditionsDescriptionBodyData.pressure.type)),
        values: initialConditionsDescriptionBodyData.pressure.values
      },
      waterSaturation: {
        type: validator.trim(validator.escape(initialConditionsDescriptionBodyData.waterSaturation.type)),
        values: initialConditionsDescriptionBodyData.waterSaturation.values
      },
      gasSaturation: {
        type: validator.trim(validator.escape(initialConditionsDescriptionBodyData.gasSaturation.type)),
        values: initialConditionsDescriptionBodyData.gasSaturation.values
      },
      globalComposition: {
        type: validator.trim(validator.escape(initialConditionsDescriptionBodyData.globalComposition.type)),
        values: initialConditionsDescriptionBodyData.globalComposition.values
      },
      gravcapequCompDepthDataByFlowUnit: gravcapequCompDepthDataByFlowUnit
    }
  },
  numericalControlDescriptionValidator: function (numericalControlDescriptionBodyData) {
    return {
      simulation_id: new mongoose.mongo.ObjectId(validator.trim(validator.escape(numericalControlDescriptionBodyData.simulation_id))),
      maxTimeStep: numericalControlDescriptionBodyData.maxTimeStep,
      minTimeStep: numericalControlDescriptionBodyData.minTimeStep,
      initialTimeStep: numericalControlDescriptionBodyData.initialTimeStep,
      maxAllowedPressureChange: numericalControlDescriptionBodyData.maxAllowedPressureChange,
      maxAllowedSaturationChange: numericalControlDescriptionBodyData.maxAllowedSaturationChange,
      maxAllowedMolChange: numericalControlDescriptionBodyData.maxAllowedMolChange,
      accelerationFactor: numericalControlDescriptionBodyData.accelerationFactor,
      minIterations: numericalControlDescriptionBodyData.minIterations,
      maxIterations: numericalControlDescriptionBodyData.maxIterations,
      maxNumberOfCuts: numericalControlDescriptionBodyData.maxNumberOfCuts,
      toleranceType: validator.trim(validator.escape(numericalControlDescriptionBodyData.toleranceType)),
      pressureTolerance: {
        value: numericalControlDescriptionBodyData.pressureTolerance.value,
        type: numericalControlDescriptionBodyData.pressureTolerance.type
      },
      molTolerance: {
        value: numericalControlDescriptionBodyData.molTolerance.value,
        type: numericalControlDescriptionBodyData.molTolerance.type
      },
      saturationTolerance: {
        value: numericalControlDescriptionBodyData.saturationTolerance.value,
        type: numericalControlDescriptionBodyData.saturationTolerance.type
      }
    }
  },
  wellsAndTimeDescriptionValidator: function (wellsAndTimeDescriptionBodyData) {
    let schedule = []
    let wellsAndTimeDescriptionLength = wellsAndTimeDescriptionBodyData.schedule.length
    for (let wellsAndTimeDescriptionIndex = 0; wellsAndTimeDescriptionIndex < wellsAndTimeDescriptionLength; wellsAndTimeDescriptionIndex++) {
      let perforations = []
      let perforationsLength = wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].length
      for (var perforationsIndex = 0; perforationsIndex < perforationsLength; perforationsIndex++) {
        perforations[perforationsIndex] = {
          iIndex: wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].perforations[perforationsIndex].iIndex,
          jIndex: wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].perforations[perforationsIndex].jIndex,
          kIndex: wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].perforations[perforationsIndex].kIndex
        }
      }
      schedule[wellsAndTimeDescriptionIndex] = {
        time: wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].time,
        wellIndex: wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].wellIndex,
        typeOfWell: validator.trim(validator.escape(wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].typeOfWell)),
        injectedFluid: validator.trim(validator.escape(wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].injectedFluid)),
        wellRadius: wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].wellRadius,
        skin: wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].skin,
        operativeConditionType: validator.trim(validator.escape(wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].operativeConditionType)),
        operativeConditionValue: wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].operativeConditionValue,
        scheduleType: validator.trim(validator.escape(wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].scheduleType)),
        numberOfPerforations: wellsAndTimeDescriptionBodyData.schedule[wellsAndTimeDescriptionIndex].numberOfPerforations,
        perforations: perforations
      }
    }
    return {
      simulation_id: new mongoose.mongo.ObjectId(validator.trim(validator.escape(wellsAndTimeDescriptionBodyData.simulation_id))),
      times: wellsAndTimeDescriptionBodyData.times,
      timesWithChange: wellsAndTimeDescriptionBodyData.timesWithChange,
      schedule: schedule
    }
  },
  settingsDescriptionValidator: function (settingsDescriptionBodyData) {
    return {
      simulation_id: new mongoose.mongo.ObjectId(validator.trim(validator.escape(settingsDescriptionBodyData.simulation_id))),
      workUnits: validator.trim(validator.escape(settingsDescriptionBodyData.workUnits)),
      fluidModel: validator.trim(validator.escape(settingsDescriptionBodyData.fluidModel)),
      dualPorosityDualPermeability: settingsDescriptionBodyData.dualPorosityDualPermeability,
      flowUnitsName: settingsDescriptionBodyData.flowUnitsName,
      components: settingsDescriptionBodyData.components
    }
  }
}

let descriptionController = {
  newDescription: async function (req, res) {
    let ErrorStack = []
    let response = {}
    logger.log('info', 'ReservoirDescription created')
    let reservoirDescriptionData = descriptionValidator.reservoirDescriptionValidator(req.body.reservoirDescription)
    await ReservoirDescription.create(reservoirDescriptionData, (err, result) => {
      if (err) {
        logger.log('error', `error creating reservoir Description, ${err}`)
        ErrorStack.push('error creating reservoir Description')
      }
      logger.log('info', 'success : true, msg :Successful Reservoir Description.')
      response.reservoirDescription = result
    })
    logger.log('info', 'FluidsDescription created')
    let FluidsDescriptionData = descriptionValidator.fluidsDescriptionValidator(req.body.fluidsDescription)
    await FluidsDescription.create(FluidsDescriptionData, (err, result) => {
      if (err) {
        logger.log('error', `error creating fluids Description, ${err}`)
        ErrorStack.push('error creating fluids Description')
      }
      logger.log('info', 'success : true, msg :Successful Fluids Description.')
      response.fluidsDescription = result
    })
    logger.log('info', 'rockFluidDescription created')
    let rockFluidDescriptionData = descriptionValidator.rockFluidDescriptionValidator(req.body.rockFluidDescription)
    await RockFluidDescription.create(rockFluidDescriptionData, (err, result) => {
      if (err) {
        logger.log('error', `error creating rock Fluid Description, ${err}`)
        ErrorStack.push('error creating rock Fluid Description')
      }
      logger.log('info', 'success : true, msg :Successful Rock Fluid Description.')
      response.rockFluidDescription = result
    })
    logger.log('info', 'initialConditionsDescription created')
    let initialConditionsDescriptionData = descriptionValidator.initialConditionsDescriptionValidator(req.body.initialConditionsDescription)
    await InitialConditionsDescription.create(initialConditionsDescriptionData, (err, result) => {
      if (err) {
        logger.log('error', `error creating initial Conditions Description, ${err}`)
        ErrorStack.push('error creating initial Conditions Description')
      }
      logger.log('info', 'success : true, msg :Successful Initial Conditions Description.')
      response.initialConditionsDescription = result
    })
    logger.log('info', 'numericalControlDescription created')
    let numericalControlDescriptionData = descriptionValidator.numericalControlDescriptionValidator(req.body.numericalControlDescription)
    await NumericalControlDescription.create(numericalControlDescriptionData, (err, result) => {
      if (err) {
        logger.log('error', `error creating numerical Control Description, ${err}`)
        ErrorStack.push('error creating numerical Control Description')
      }
      logger.log('info', 'success : true, msg :Successful Numerical Control Description.')
      response.numericalControlDescription = result
    })
    logger.log('info', 'wellsAndTimeDescription created')
    let wellsAndTimeDescriptionData = descriptionValidator.wellsAndTimeDescriptionValidator(req.body.wellsAndTimeDescription)
    await WellsAndTimeDescription.create(wellsAndTimeDescriptionData, (err, result) => {
      if (err) {
        logger.log('error', `error creating wells And Time Description, ${err}`)
        ErrorStack.push('error creating wells And Time Description')
      }
      logger.log('info', 'success : true, msg :Successful Wells And Time Description.')
      response.wellsAndTimeDescription = result
    })
    logger.log('info', 'settingsDescription created')
    let settingsDescriptionData = descriptionValidator.settingsDescriptionValidator(req.body.settingsDescription)
    await SettingsDescription.create(settingsDescriptionData, (err, result) => {
      if (err) {
        logger.log('error', `error creating settings Description, ${err}`)
        ErrorStack.push('error creating settings Description')
      }
      logger.log('info', 'success : true, msg :Successful Settings Description.')
      response.settingsDescription = result
    })
    if (ErrorStack.length !== 0) {
      logger.log('info', 'success : false, msg : Errors have occurred.')
      res.json({ success: false, msg: 'Errors have occurred.', errors: ErrorStack })
    }
    logger.log('info', 'success : true, msg : Correctly created.')
    res.json({ success: true, msg: 'Correctly created.', description: response })
  },
  seeDescription: async function (req, res) {
    let ErrorStack = []
    let response = {}
    let query = {
      simulation_id: validator.trim(validator.escape(req.params.id))
    }
    logger.log('info', 'ReservoirDescription searched')
    await ReservoirDescription.findOne(query, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Reservoir Description not found.')
        ErrorStack.push('Reservoir Description not found')
      }
      logger.log('info', 'success : true, msg : Reservoir Description found.')
      response.reservoirDescription = result
    })
    logger.log('info', 'FluidsDescription searched')
    await FluidsDescription.findOne(query, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Fluids Description not found.')
        ErrorStack.push('Fluids Description not found')
      }
      logger.log('info', 'success : true, msg : Fluids Description found.')
      response.fluidsDescription = result
    })
    logger.log('info', 'rockFluidDescription searched')
    await RockFluidDescription.findOne(query, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Rock Fluid Description not found.')
        ErrorStack.push('Rock Fluids Description not found')
      }
      logger.log('info', 'success : true, msg : Rock Fluids Description found.')
      response.rockFluidDescription = result
    })
    logger.log('info', 'initialConditionsDescription searched')
    await InitialConditionsDescription.findOne(query, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Initial Conditions Description not found.')
        ErrorStack.push('Initial Conditions Description not found')
      }
      logger.log('info', 'success : true, msg : Initial Conditions Description found.')
      response.initialConditionsDescription = result
    })
    logger.log('info', 'numericalControlDescription searched')
    await NumericalControlDescription.findOne(query, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Numerical Control Description not found.')
        ErrorStack.push('Numerical Control Description not found')
      }
      logger.log('info', 'success : true, msg : Numerical Control Description found.')
      response.numericalControlDescription = result
    })
    logger.log('info', 'wellsAndTimeDescription searched')
    await WellsAndTimeDescription.findOne(query, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Wells And Time Description not found.')
        ErrorStack.push('Wells And Time Description not found')
      }
      logger.log('info', 'success : true, msg : Wells And Time Description found.')
      response.wellsAndTimeDescription = result
    })
    logger.log('info', 'settingsDescription searched')
    await SettingsDescription.findOne(query, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Settings Description not found.')
        ErrorStack.push('Settings Description not found')
      }
      logger.log('info', 'success : true, msg : Settings Description found.')
      response.settingsDescription = result
    })
    if (ErrorStack.length !== 0) {
      logger.log('info', 'success : false, msg : Errors have occurred.')
      res.json({ success: false, msg: 'Errors have occurred.', errors: ErrorStack })
    }
    logger.log('info', 'success : true, msg : Found correctly.')
    res.json({ success: true, msg: 'Found correctly.', description: response })
  },
  editDescription: async function (req, res) {
    let response = {}
    let query = {
      simulation_id: validator.trim(validator.escape(req.params.id))
    }
    logger.log('info', 'ReservoirDescription initiate')
    let reservoirDescriptionData = descriptionValidator.reservoirDescriptionValidator(req.body.reservoirDescription)
    await ReservoirDescription.findOneAndUpdate(query, reservoirDescriptionData, {
      new: true,
      upsert: true
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Reservoir Description was not found and was created correctly.')
      }
      logger.log('info', 'success : true, msg : Reservoir Description was found and updated correctly.')
      response.reservoirDescription = result
    })
    logger.log('info', 'FluidsDescription initiate')
    let FluidsDescriptionData = descriptionValidator.fluidsDescriptionValidator(req.body.fluidsDescription)
    await FluidsDescription.findOneAndUpdate(query, FluidsDescriptionData, {
      new: true,
      upsert: true
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Fluids Description was not found and was created correctly.')
      }
      logger.log('info', 'success : true, msg : Fluids Description was found and updated correctly.')
      response.fluidsDescription = result
    })
    logger.log('info', 'rockFluidDescription initiate')
    let rockFluidDescriptionData = descriptionValidator.rockFluidDescriptionValidator(req.body.rockFluidDescription)
    await RockFluidDescription.findOneAndUpdate(query, rockFluidDescriptionData, {
      new: true,
      upsert: true
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Rock Fluid Description was not found and was created correctly.')
      }
      logger.log('info', 'success : true, msg : Rock Fluids Description was found and updated correctly.')
      response.rockFluidDescription = result
    })
    logger.log('info', 'initialConditionsDescription initiate')
    let initialConditionsDescriptionData = descriptionValidator.initialConditionsDescriptionValidator(req.body.initialConditionsDescription)
    await InitialConditionsDescription.findOneAndUpdate(query, initialConditionsDescriptionData, {
      new: true,
      upsert: true
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Initial Conditions Description was not found and was created correctly.')
      }
      logger.log('info', 'success : true, msg : Initial Conditions Description was found and updated correctly.')
      response.initialConditionsDescription = result
    })
    logger.log('info', 'numericalControlDescription initiate')
    let numericalControlDescriptionData = descriptionValidator.numericalControlDescriptionValidator(req.body.numericalControlDescription)
    await NumericalControlDescription.findOneAndUpdate(query, numericalControlDescriptionData, {
      new: true,
      upsert: true
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Numerical Control Description was not found and was created correctly.')
      }
      logger.log('info', 'success : true, msg : Numerical Control Description was found and updated correctly.')
      response.numericalControlDescription = result
    })
    logger.log('info', 'wellsAndTimeDescription initiate')
    let wellsAndTimeDescriptionData = descriptionValidator.wellsAndTimeDescriptionValidator(req.body.wellsAndTimeDescription)
    await WellsAndTimeDescription.findOneAndUpdate(query, wellsAndTimeDescriptionData, {
      new: true,
      upsert: true
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Wells And Time Description was not found and was created correctly.')
      }
      logger.log('info', 'success : true, msg : Wells And Time Description was found and updated correctly.')
      response.wellsAndTimeDescription = result
    })
    logger.log('info', 'settingsDescription initiate')
    let settingsDescriptionData = descriptionValidator.settingsDescriptionValidator(req.body.settingsDescription)
    await SettingsDescription.findOneAndUpdate(query, settingsDescriptionData, {
      new: true,
      upsert: true
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Settings Description was not found and was created correctly.')
      }
      logger.log('info', 'success : true, msg : Settings Description was found and updated correctly.')
      response.settingsDescription = result
    })
    logger.log('info', 'success : true, msg : The descriptions were found and updated correctly.')
    res.json({ success: true, msg: 'The descriptions were found and updated correctly.', description: response })
  }
}

module.exports = descriptionController
