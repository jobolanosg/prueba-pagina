const logger = require('../helpers/logger')
const User = require('../models/user')
const auth = require('../middlewares/auth')
const validator = require('validator')
const Project = require('../models/project')
const bcrypt = require('bcryptjs')

let userController = {
  getUsers: function (req, res) {
    User.find((err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : An error has occurred.')
        return res.json({ success: false, msg: 'An error has occurred.' })
      }
      logger.log('info', 'success : true, msg : Users found.')
      return res.json({ success: true, users: result })
    })
  },
  newUser: function (req, res) {
    User.create({
      name: validator.trim(validator.escape(req.body.name)),
      lastname: validator.trim(validator.escape(req.body.lastname)),
      role: validator.trim(validator.escape(req.body.role)),
      email: validator.trim(validator.escape(req.body.email)),
      password: validator.trim(validator.escape(req.body.password))
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : Username already exists.')
        return res.json({ success: false, msg: `Error: ${err}` })
      }
      logger.log('info', 'success : true, msg :Successful created new user.')
      return res.json({ success: true, user: result })
    })
  },
  seeUser: function (req, res) {
    User.findById(validator.trim(validator.escape(req.params.id)), (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : The user does not exist.')
        return res.json({ success: false, msg: 'The user does not exist.' })
      }
      logger.log('info', 'success : true, msg : The user was found.')
      return res.json({ success: true, user: result })
    })
  },
  editUser: function (req, res) {
    let newPassword = bcrypt.hashSync(validator.trim(validator.escape(req.body.password)), 10)
    User.findByIdAndUpdate(validator.trim(validator.escape(req.params.id)), {
      name: validator.trim(validator.escape(req.body.name)),
      lastname: validator.trim(validator.escape(req.body.lastname)),
      role: validator.trim(validator.escape(req.body.role)),
      email: validator.trim(validator.escape(req.body.email)),
      password: newPassword
    }, {
      new: true,
      upsert: true
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : true, msg : The user was not found and was created correctly.')
        return res.json({ success: true })
      }
      logger.log('info', 'success : true, msg : The user was found and updated correctly.')
      return res.json({ success: true, user: result })
    })
  },
  deleteUser: function (req, res) {
    User.findByIdAndRemove(validator.trim(validator.escape(req.params.id)), (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : The user was not found.')
        return res.json({ success: false, msg: 'The user was not found.' })
      }
      logger.log('info', 'success : true, msg : The user was deleted correctly.')
      return res.json({ success: true })
    })
  },
  LoginUser: function (req, res) {
    User.findOne({
      email: validator.trim(validator.escape(req.body.email))
    }, function (err, user) {
      if (err) {
        logger.error('Error', err)
        throw err
      }
      if (!user) {
        logger.log('info', 'success : false, msg : Authentication failed. User not found.')
        res.status(401).send({ success: false, msg: 'Authentication failed. User not found.' })
      } else {
        if (user.comparePassword(validator.trim(validator.escape(req.body.password)))) {
          let token = auth.createToken(user)
          logger.log('info', 'success : true, msg : Authentication Successful')
          res.json({ success: true, token: token, _id: user._id, user: { username: `${user.name} ${user.lastname}`, email: user.email, role: user.role } })
        } else {
          logger.log('info', 'success : false, msg : Authentication failed. Wrong password.')
          res.status(401).send({ success: false, msg: 'Authentication failed. Wrong password.' })
        }
      }
    })
  },
  LogoutUser: function (req, res) {
    logger.log('info', 'success : true, msg : Good Bye.')
    res.json({ success: true })
  },
  UserSimulation: function (req, res) {
    Project.find({
      owner: validator.trim(validator.escape(req.params.id))
    }).populate({ path: 'simulations', select: '-__v' }).exec(function (err, projects) {
      if (err) {
        logger.error('Error', err)
        throw err
      }
      logger.log('info', 'success : true, msg : Projects and Simulation found.')
      res.send({ success: true, projects: projects })
    })
  },
  UserProject: function (req, res) {
    Project.find({
      owner: validator.trim(validator.escape(req.params.id))
    }).exec(function (err, projects) {
      if (err) {
        logger.error('Error', err)
        throw err
      }
      logger.log('info', 'success : true, msg : Projects found.')
      res.send({ success: true, projects: projects })
    })
  }
}

module.exports = userController
