const path = require('path')
const chai = require('chai')

const sinon = require('sinon')
require('sinon-mongoose')
const project = require(path.resolve('./test', '../models/project'))

const expect = chai.expect

describe('Project Models Unit Tests', () => {
  it('Should return "ProjectName1", "An project" and Ids', (done) => {
    let projectMock = sinon.mock(project)
    let expected = {
      name: 'ProjectName1',
      description: 'An project',
      owner: 'M35YYSQeh9EjJLjVDzr5Qe2A',
      collaborators: [
        {
          user_id: 'wttVurEs5KLXPUkmbPfe86fE',
          permission: Math.random() % 2 === 0
            ? 'r'
            : 'rw'
        }
      ]
    }
    projectMock.expects('find').yields(null, expected)
    project.find((err, result) => {
      projectMock.verify()
      projectMock.restore()
      expect(err).to.be.null
      expect(result.name).to.be.a('string').that.equal('ProjectName1')
      expect(result.description).to.be.a('string').that.equal('An project')
      expect(result.owner).to.be.not.undefined
      expect(result.collaborators).to.be.a('array')
      result.collaborators.every((collaboratorsObject) => {
        return expect(collaboratorsObject.user_id).to.be.not.undefined && expect(collaboratorsObject.permission).to.satisfy((val) => {
          return val === 'r' || val === 'rw'
        })
      })
      done()
    })
  })
})
