const logger = require('../helpers/logger')
const deleteSimulation = require('../helpers/deleteSimulation')
const Project = require('../models/project')
const User = require('../models/user')
const validator = require('validator')
const mongoose = require('mongoose')

let projectController = {
  getProjects: function (req, res) {
    Project.find((err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : An error has occurred.')
        return res.json({ success: false, msg: 'An error has occurred.' })
      }
      logger.log('info', 'success : true, msg : Projects found.')
      return res.json({ success: true, projects: result })
    })
  },
  newProject: function (req, res) {
    let collaborators = []
    if (req.body.collaborators && req.body.collaborators[0] && Object.keys(req.body.collaborators[0]).length > 0) {
      let collaboratorsLength = req.body.collaborators.length
      for (let i = 0; i < collaboratorsLength; i++) {
        collaborators[ i ] = {
          user_id: new mongoose.mongo.ObjectId(validator.trim(validator.escape(req.body.collaborators[ i ].user_id))),
          permission: validator.trim(validator.escape(req.body.collaborators[ i ].permission))
        }
      }
    }
    Project.create({
      name: validator.trim(validator.escape(req.body.name)),
      description: validator.trim(validator.escape(req.body.description)),
      owner: new mongoose.mongo.ObjectId(validator.trim(validator.escape(req.body.owner))),
      simulations: req.body.simulations,
      collaborators: collaborators
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : The project could not be created.')
        return res.json({ success: false, msg: 'The project could not be created.' })
      }
      logger.log('info', 'success : true, msg : The project has been created correctly.')
      return res.json({ success: true, project: result })
    })
  },
  seeProject: function (req, res) {
    Project.findById(validator.trim(validator.escape(req.params.id)), (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : The project does not exist.')
        return res.json({ success: false, msg: 'The project does not exist.' })
      }
      logger.log('info', 'success : true, msg : The project was found.')
      return res.json({ success: true, project: result })
    })
  },
  editProject: function (req, res) {
    let collaborators = []
    if (req.body.collaborators && req.body.collaborators[0] && Object.keys(req.body.collaborators[0]).length > 0) {
      let collaboratorsLength = req.body.collaborators.length
      for (let i = 0; i < collaboratorsLength; i++) {
        collaborators[ i ] = {
          user_id: new mongoose.mongo.ObjectId(validator.trim(validator.escape(req.body.collaborators[ i ].user_id))),
          permission: validator.trim(validator.escape(req.body.collaborators[ i ].permission))
        }
      }
    }
    Project.findByIdAndUpdate(validator.trim(validator.escape(req.params.id)), {
      name: validator.trim(validator.escape(req.body.name)),
      description: validator.trim(validator.escape(req.body.description)),
      owner: new mongoose.mongo.ObjectId(validator.trim(validator.escape(req.body.owner))),
      simulations: req.body.simulations,
      collaborators: collaborators
    }, {
      new: true,
      upsert: true
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : true, msg : The project was not found and was created correctly.')
        return res.json({ success: true })
      }
      logger.log('info', 'success : true, msg : The project was found and updated correctly.')
      return res.json({ success: true, project: result })
    })
  },
  deleteProject: function (req, res) {
    User.findOne({
      email: validator.trim(validator.escape(req.body.email))
    }, function (err, user) {
      if (err) {
        logger.error('Error', err)
        throw err
      }
      if (!user) {
        logger.log('info', 'success : false, msg : Confirmation failed. User not found.')
        res.status(401).send({ success: false, msg: 'Confirmation failed. User not found.' })
      } else {
        if (user.comparePassword(validator.trim(validator.escape(req.body.password)))) {
          logger.log('info', 'success : true, msg : Confirmation Successful')
          deleteSimulation.deletingWithProjectId(validator.trim(validator.escape(req.params.id)))
          Project.findByIdAndRemove(validator.trim(validator.escape(req.params.id)), (err, result) => {
            if (err) {
              logger.log('info', 'success : false, msg : The project was not found.')
              return res.json({ success: false })
            }
            logger.log('info', 'success : true, msg : The project was deleted correctly.')
            return res.json({ success: true })
          })
        } else {
          logger.log('info', 'success : false, msg : Confirmation failed. Wrong password.')
          res.status(401).send({ success: false, msg: 'Confirmation failed. Wrong password.' })
        }
      }
    })
  }
}

module.exports = projectController
