const logger = require('../helpers/logger')
const Temporary = require('../models/temporary')
const validator = require('validator')

let applicationController = {
  getTemporary: function (req, res) {
    if (req.body.simulation_id) {
      Temporary.findOne({ simulation_id: validator.trim(validator.escape(req.body.simulation_id)) }).exec((err, result) => {
        if (err) {
          logger.log('info', 'success : false, msg : An error has occurred.')
          return res.json({ success: false, msg: 'An error has occurred.' })
        }

        if (result === null) {
          logger.log('info', 'success : true, msg : Temporary empty.')
          return res.json({ success: true, temporary: { saved: JSON.stringify({ settingsData: {}, reservoirData: {}, initialConditionsData: {}, numericalSettingsData: {}, rockFluidData: [], wellsScheduleData: {}, fluidsData: {}, componentsData: {} }) } })
        } else {
          logger.log('info', 'success : true, msg : Temporary files required.')
          return res.json({ success: true, temporary: result })
        }
      })
    } else {
      return res.json({ success: false, msg: 'No id' })
    }
  },
  saveTemporary: function (req, res) {
    Temporary.findOneAndUpdate({ simulation_id: validator.trim(validator.escape(req.body.simulation_id)) }, {
      simulation_id: validator.trim(validator.escape(req.body.simulation_id)),
      saved: JSON.stringify(req.body.saved)
    }, {
      new: true,
      upsert: true
    }).exec((err, result) => {
      if (err) {
        console.log(err)
        logger.log('info', 'success : false, msg : Temporary files could not be saved correctly.')
        return res.json({ success: false, msg: 'Temporary files could not be saved correctly.' })
      }
      logger.log('info', 'success : true, msg : Temporary files saved correctly.')
      return res.json({ success: true })
    })
  }
}

module.exports = applicationController
