const path = require('path')
const bcrypt = require('bcryptjs')
const chai = require('chai')

const sinon = require('sinon')
require('sinon-mongoose')
const user = require(path.resolve('./test', '../models/user'))

const expect = chai.expect

function comparePassword (password) {
  let validate = bcrypt.compareSync('password123', password)
  return validate
}

function createPassword (salt) {
  let password = bcrypt.hashSync('password123', salt)
  return password
}

describe('User Model Unit Tests', () => {
  it('Should return a User', (done) => {
    let userMock = sinon.mock(user)
    let expected = {
      name: 'Root',
      lastname: 'Admin',
      role: 'system_admin',
      email: 'root@admin.com',
      password: createPassword(8)
    }
    userMock.expects('find').yields(null, expected)
    user.find((err, result) => {
      userMock.verify()
      userMock.restore()
      expect(err).to.be.null
      expect(result.name).to.be.a('string').that.equal('Root')
      expect(result.lastname).to.be.a('string').that.equal('Admin')
      expect(result.role).to.be.a('string').that.satisfy((val) => {
        return val === 'system_admin' || val === 'user'
      })
      expect(result.email).to.be.a('string').that.match(/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/)
      expect(comparePassword(result.password)).to.be.true
      done()
    })
  })
})
