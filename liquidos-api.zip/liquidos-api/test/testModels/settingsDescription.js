const path = require('path')
const chai = require('chai')

const sinon = require('sinon')
require('sinon-mongoose')
const settingsDescription = require(path.resolve('./test', '../models/settingsDescription'))

const expect = chai.expect

describe('Settings Description Models Unit Tests', () => {
  it('Should return "SettingsDescriptionName1", "An settingsDescription" and Ids', (done) => {
    let settingsDescriptionMock = sinon.mock(settingsDescription)
    let expected = {
      simulation_id: 'M35YYSQeh9EjJLjVDzr5Qe2A',
      workUnits: 'meters',
      fluidModel: Math.random() % 2 === 0
        ? 'Blackoil'
        : 'Gas Condensate',
      dualPorosityDualPermeability: true,
      flowUnitsName: [
        'hec', 'meters'
      ],
      components: ['wttVurEs5KLXPUkmbPfe86fE', 'mVX5rjaW8fGexnEJyzegXBUx']
    }
    settingsDescriptionMock.expects('find').yields(null, expected)
    settingsDescription.find((err, result) => {
      settingsDescriptionMock.verify()
      settingsDescriptionMock.restore()
      expect(err).to.be.null
      expect(result.simulation_id).to.be.not.undefined
      expect(result.workUnits).to.be.a('string').that.equal('meters')
      expect(result.fluidModel).to.satisfy((val) => {
        return val === 'Blackoil' || val === 'Gas Condensate'
      })
      expect(result.dualPorosityDualPermeability).to.be.equal(true)
      expect(result.flowUnitsName).to.be.a('array')
      expect(result.components).to.be.a('array')
      done()
    })
  })
})
