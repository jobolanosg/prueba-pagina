const path = require('path')
const chai = require('chai')

const sinon = require('sinon')
require('sinon-mongoose')
const reservoirDescription = require(path.resolve('./test', '../models/reservoirDescription'))

const expect = chai.expect

describe('Reservoir Description Model Unit Test', () => {
  it('Should return a "Reservoir Description" object', (done) => {
    let reservoirDescriptionMock = sinon.mock(reservoirDescription)
    let expected = {
      simulation_id: 'yFTF9yauC8FRVV2P9fZ9Jrts',
      mesh:
        {
          type: 'Petrol',
          internalRadius: 24,
          externalRadius: 569,
          iLength:
            {
              type: 'meter',
              values: [2, 4, 8, 10]
            },
          jLength:
            {
              type: 'meter',
              values: [1, 3, 5, 7, 9]
            },
          kLength:
            {
              type: 'hectare',
              values: [5, 10]
            },
          top:
            {
              type: 'inch',
              values: [200, 500]
            },
          iPermeability:
            {
              type: 'square_meter',
              values: [12, 18]
            },
          jPermeability:
            {
              type: 'square_meter',
              values: [20, 40]
            },
          kPermeability:
            {
              type: 'square_meter',
              values: [15, 87]
            },
          porosity:
            {
              type: 'volume',
              values: [0.1, 0.05]
            },
          activeBlock:
            {
              type: 'density',
              values: [34, 45]
            },
          flowUnit:
            {
              type: 'flow',
              values: [12, 36, 48]
            }

        },
      poreCompressibility: 0.0000000000000001,
      referencePressure: 0.005,
      matrixDensity: 0.0012
    }
    reservoirDescriptionMock.expects('find').yields(null, expected)
    reservoirDescription.find((err, result) => {
      reservoirDescriptionMock.verify()
      reservoirDescriptionMock.restore()
      expect(err).to.be.null
      expect(result.simulation_id).to.be.not.undefined
      expect(result.mesh).to.be.a('object')
      expect(result.mesh.type).to.be.a('string').that.equal('Petrol')
      expect(result.mesh.internalRadius).to.be.equal(24)
      expect(result.mesh.externalRadius).to.be.equal(569)
      expect(result.mesh.iLength).to.be.a('object')
      expect(result.mesh.jLength).to.be.a('object')
      expect(result.mesh.kLength).to.be.a('object')
      expect(result.mesh.top).to.be.a('object')
      expect(result.mesh.iPermeability).to.be.a('object')
      expect(result.mesh.jPermeability).to.be.a('object')
      expect(result.mesh.kPermeability).to.be.a('object')
      expect(result.mesh.porosity).to.be.a('object')
      expect(result.mesh.activeBlock).to.be.a('object')
      expect(result.mesh.flowUnit).to.be.a('object')
      expect(result.poreCompressibility).to.be.equal(0.0000000000000001)
      expect(result.referencePressure).to.be.equal(0.005)
      expect(result.matrixDensity).to.be.equal(0.0012)
      done()
    })
  })
})
