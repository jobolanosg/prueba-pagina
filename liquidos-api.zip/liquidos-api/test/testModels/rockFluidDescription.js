const path = require('path')
const chai = require('chai')

const sinon = require('sinon')
require('sinon-mongoose')
const rockFluidDescription = require(path.resolve('./test', '../models/rockFluidDescription'))

const expect = chai.expect

describe('Rock Fluid Description Model Unit Tests', () => {
  it('Should return a "rockFluidDescription" object', (done) => {
    let rockFluidDescriptionMock = sinon.mock(rockFluidDescription)
    let expected = {
      simulation_id: 'pANhkLcVwVgapAAaCXB56eDx',
      rockFluidDescriptionByFlowUnit: [
        {
          gasOilRockFluid: {
            gasSaturation: [
              484, 4
            ],
            gasRelativePermeability: [
              446, 54
            ],
            oilRelativePermeability: [
              46, 54
            ],
            gasOilCapillaryPressure: [878, 415]
          },
          waterOilRockFluid: {
            waterSaturation: [
              12, 45
            ],
            waterRelativePermeability: [
              15, 48
            ],
            oilRelativePermeability: [
              87, 12
            ],
            oilWaterCapillaryPressure: [87, 54]
          }
        }
      ]
    }
    rockFluidDescriptionMock.expects('find').yields(null, expected)
    rockFluidDescription.find((err, result) => {
      rockFluidDescriptionMock.verify()
      rockFluidDescriptionMock.restore()
      expect(err).to.be.null
      expect(result.simulation_id).to.be.not.undefined
      expect(result.rockFluidDescriptionByFlowUnit).to.be.a('array')
      result.rockFluidDescriptionByFlowUnit.every((rockFluidDescriptionByFlowUnitObject) => {
        expect(rockFluidDescriptionByFlowUnitObject.gasOilRockFluid).to.be.a('object')
        expect(rockFluidDescriptionByFlowUnitObject.gasOilRockFluid).to.have.property('gasSaturation' && 'gasRelativePermeability' && 'oilRelativePermeability' && 'gasOilCapillaryPressure')
        expect(rockFluidDescriptionByFlowUnitObject.waterOilRockFluid).to.be.a('object')
        expect(rockFluidDescriptionByFlowUnitObject.waterOilRockFluid).to.have.property('waterSaturation' && 'waterRelativePermeability' && 'oilRelativePermeability' && 'oilWaterCapillaryPressure')
        return true
      })
      done()
    })
  })
})
