const path = require('path')
const chai = require('chai')
const chaiHttp = require('chai-http')
const server = require(path.resolve('./test', '../bin/www2'))
const expect = chai.expect

chai.use(chaiHttp)

let loginInfo = {
  'email': 'test@test.com',
  'password': '1234567890'
}
let saved = JSON.stringify({ name: 'John', age: 30, city: 'New York' })

describe('Temporary Routes', function () {
  describe('Saved', function () {
    it('Should return "200" status', function (done) {
      chai.request(server).post('/api/user/login').send(loginInfo).end(function (err, res) {
        expect(err).to.be.null
        expect(res.body.success).to.be.true
        expect(res.body.token).to.be.not.undefined
        expect(res).to.have.status(200)
        let token = res.body.token
        chai.request(server).post('/api/temporary/save').send({ simulation_id: '5bc1148ebee04615c4a13ebf', saved, token }).end(function (err, res) {
          expect(err).to.be.null
          expect(res.body.success).to.be.true
          expect(res).to.have.status(200)
          chai.request(server).post('/api/user/logout').send({ token: token }).end(function (err, res) {
            expect(err).to.be.null
            expect(res.body.success).to.be.true
            expect(res).to.have.status(200)
            done()
          })
        })
      })
    })
  })
  describe('Get and Delete', function () {
    it('Should return "200" status', function (done) {
      chai.request(server).post('/api/user/login').send(loginInfo).end(function (err, res) {
        expect(err).to.be.null
        expect(res.body.success).to.be.true
        expect(res.body.token).to.be.not.undefined
        expect(res).to.have.status(200)
        let token = res.body.token
        chai.request(server).post('/api/temporary/get').send({ simulation_id: '5bc1148ebee04615c4a13ebf', token }).end(function (err, res) {
          expect(err).to.be.null
          expect(res.body.success).to.be.true
          expect(res.body.temporary.simulation_id).to.be.equal('5bc1148ebee04615c4a13ebf')
          expect(res.body.temporary.saved).to.be.not.undefined
          expect(res).to.have.status(200)
          chai.request(server).post('/api/user/logout').send({ token: token }).end(function (err, res) {
            expect(err).to.be.null
            expect(res.body.success).to.be.true
            expect(res).to.have.status(200)
            done()
          })
        })
      })
    })
  })
})
