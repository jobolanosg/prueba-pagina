const path = require('path')
const chai = require('chai')
const chaiHttp = require('chai-http')
const server = require(path.resolve('./test', '../bin/www2'))
const expect = chai.expect

chai.use(chaiHttp)

let loginInfo = {
  'email': 'test@test.com',
  'password': '1234567890'
}

describe('Component Routes', function () {
  describe('Component Routes Login, See Components, Edit Component, Delete Component and Logout', function () {
    it('Should return "200" status', function (done) {
      chai.request(server).post('/api/user/login').send(loginInfo).end(function (err, res) {
        expect(err).to.be.null
        expect(res.body.success).to.be.true
        expect(res.body.token).to.be.not.undefined
        expect(res).to.have.status(200)
        let token = res.body.token
        let newComponentInfo = {
          'name': 'testComponent',
          'token': token
        }
        chai.request(server).post('/api/component/new').send(newComponentInfo).end(function (err, res) {
          expect(err).to.be.null
          expect(res.body.success).to.be.true
          expect(res.body.component).to.be.a('object')
          let Componentid = res.body.component._id
          expect(res).to.have.status(200)
          chai.request(server).post(`/api/component/${Componentid}`).send({ token: token }).end(function (err, res) {
            expect(err).to.be.null
            expect(res.body.success).to.be.true
            expect(res.body.component).to.be.a('object')
            expect(res.body.component.name).to.be.equal(newComponentInfo.name)
            expect(res).to.have.status(200)
            let editComponentInfo = {
              'name': 'testComponentEdit',
              'token': token
            }
            chai.request(server).put(`/api/component/${Componentid}`).send(editComponentInfo).end(function (err, res) {
              expect(err).to.be.null
              expect(res.body.success).to.be.true
              expect(res.body.component).to.be.a('object')
              expect(res.body.component.name).to.be.equal(editComponentInfo.name)
              expect(res).to.have.status(200)
              chai.request(server).delete(`/api/component/${Componentid}`).send({ token: token }).end(function (err, res) {
                expect(err).to.be.null
                expect(res.body.success).to.be.true
                expect(res).to.have.status(200)
                chai.request(server).post('/api/user/logout').send({ token: token }).end(function (err, res) {
                  expect(err).to.be.null
                  expect(res.body.success).to.be.true
                  expect(res).to.have.status(200)
                  done()
                })
              })
            })
          })
        })
      })
    })
  })
})
