const path = require('path')
const bcrypt = require('bcryptjs')

const config = {
  ENV: process.env.NODE_ENV || 'development',
  PORT: process.env.PORT || '3000',
  DATABASE: {
    NAME: 'mongodb://localhost:27017/ceor-webtool',
    OPTIONS: { useNewUrlParser: true, useFindAndModify: false, useCreateIndex: true, promiseLibrary: require('bluebird') }
  },
  LOG: {
    ENV: ':date[clf] :method :url :status :res[content-length] - :response-time ms',
    OPTIONS: {
      FILE: {
        level: 'info',
        filename: path.resolve(__dirname, './logs/app.log'),
        handleExceptions: false,
        json: true,
        maxsize: 5242880,
        maxFiles: 5
      },
      FILEERRORS: {
        level: 'error',
        filename: path.resolve(__dirname, './logs/error.log'),
        handleExceptions: true,
        json: true,
        maxsize: 5242880,
        maxFiles: 5
      },
      CONSOLE: {
        level: 'info',
        handleExceptions: true,
        json: false
      }
    }
  },
  JWT: {
    SECRET: `${bcrypt.hashSync('Secret', 10)}`
  }
}

module.exports = config
