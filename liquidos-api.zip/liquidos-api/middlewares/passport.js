const JwtStrategy = require('passport-jwt').Strategy
const ExtractJwt = require('passport-jwt').ExtractJwt

const User = require('../models/user')
const config = require('../config')

module.exports = function (passport) {
  passport.use(new JwtStrategy({
    jwtFromRequest: ExtractJwt.fromBodyField('token'),
    secretOrKey: config.JWT.SECRET
  }, function (jwtPayload, done) {
    User.findOne({
      id: jwtPayload.id
    }, function (err, user) {
      if (err) {
        return done(err, false)
      }
      if (user) {
        done(null, user)
      } else {
        done(null, false)
      }
    })
  }))
}
