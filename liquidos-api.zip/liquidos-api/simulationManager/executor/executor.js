const exec = require('child_process').exec
const execSync = require('child_process').execSync
const path = require('path')
const fs = require('fs')

async function deleteEntity(route, entityName, recursive = false, force = false) {
  try {
    await execSync(`cd ${path.resolve(__dirname, `${route}`)} && rm -${recursive ? 'r' : ''}${force ? 'f' : ''} ${entityName}`)
  } catch (e) {
    throw 'Error deleting -> ' + e
  }
}

function checkExistence(pathToCheck) {
  return fs.existsSync(path.resolve(__dirname, `${pathToCheck}`))
}

function create(simulationId, simulationInfo, simulationData) {
  try {
    execSync(`cd ${path.resolve(__dirname, '../simulation')} && mkdir -p ${simulationId}/Data/Input && cd ${simulationId}/Data && mkdir -p Results/VTKOutput`)
    console.log('Simulation folder created')
    execSync(`cp ${path.resolve(__dirname, '../control/base/DFTFlowSolver.exe')} ${path.resolve(__dirname, `../simulation/${simulationId}/${simulationId}.exe`)}`)
    console.log('Solver copied')
    fs.writeFileSync(`${path.resolve(__dirname, `../simulation/${simulationId}/simulation.json`)}`, JSON.stringify(simulationInfo), 'utf8', (err) => {
      if (err) throw `Error creating simulation.json -> ${err}`
    })

    fs.writeFileSync(`${path.resolve(__dirname, `../simulation/${simulationId}/Data/Input/Solver.json`)}`, JSON.stringify(simulationData), 'utf8', (err) => {
      if (err) throw `Error creating data.json -> ${err}`
    })
    console.log('Solver.json created')
  } catch (err) {
    throw 'Error -> ' + err
  }
}

async function createFolder(id, info, data) {
  if (checkExistence(`../simulation/${id}`)) {
    await deleteEntity('../simulation/', id, true, false)
  }
  await create(id, info, data)
}

async function verify() {
  try {
    let simulationQueue = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../queue/queue.json'), 'utf8'))
    if (simulationQueue.simulationQueue.length > 0) {
      let currentSimulation = simulationQueue.simulationQueue.shift()
      fs.writeFileSync(path.resolve(__dirname, '../queue/queue.json'), JSON.stringify(simulationQueue), 'utf8', (err) => {
        if (err) throw `Error updating the simulation queue -> ${err}`
      })

      let simulationProcessingQueue = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../queue/processing.json'), 'utf8'))
      simulationProcessingQueue.simulationProcessing.push(currentSimulation)
      fs.writeFileSync(path.resolve(__dirname, '../queue/processing.json'), JSON.stringify(simulationProcessingQueue), 'utf8', (err) => {
        if (err) throw `Error updating the processed queue -> ${err}`
      })

      await createFolder(currentSimulation.id, currentSimulation.info, currentSimulation.data)
      await execute(currentSimulation.id)
    }
  } catch (e) {
    console.error(e)
  }
}

function execute(simulationToExecute) {
  exec(`cd ${path.resolve(__dirname, `../simulation/${simulationToExecute}`)} && ./${simulationToExecute}.exe -sub_pc_factor_levels 1 -sub_pc_factor_fill 2 -sub_pc_factor_shift_type INBLOCKS`, {
    maxBuffer: 1024 * 1024 * 50
  }, (error, stdout, stderr) => {
    if (error) {
      let simulationProcessingQueue = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../../simulationManager/queue/processing.json'), 'utf8')).simulationProcessing
      let simulationProcessedIncompleted = simulationProcessingQueue.filter((value) => {
        return value.id !== simulationToExecute
      })

      fs.writeFileSync(path.resolve(__dirname, '../../simulationManager/queue/processing.json'), JSON.stringify({
        simulationProcessing: simulationProcessedIncompleted
      }), 'utf8', (err) => {
        if (err) throw err
      })
      console.log(`exec error: ${error}`)
    }
  })
  console.log('reached the execute command', simulationToExecute)
}

function checkComplete(simulationToCheck) {
  if (fs.existsSync(`${path.resolve(__dirname, `../simulation/${simulationToCheck}`)}`)) {
    if (fs.existsSync(`${path.resolve(__dirname, `../simulation/${simulationToCheck}`)}/Data/Results/wells.json`)) {
      return true
    } else {
      return false
    }
  } else {
    return false
  }
}

function watcher() {
  try {
    let simulationProcessingQueue = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../queue/processing.json'), 'utf8')).simulationProcessing

    let simulationProcessedCompleted = simulationProcessingQueue.filter((value) => {
      return checkComplete(value.id)
    })

    let simulationProcessedIncompleted = simulationProcessingQueue.filter((value) => {
      return !checkComplete(value.id)
    })

    fs.writeFileSync(path.resolve(__dirname, '../queue/processing.json'), JSON.stringify({
      simulationProcessing: simulationProcessedIncompleted
    }), 'utf8', (err) => {
      if (err) throw `Error updating the processed queue -> ${err}`
    })

    // let simulationCompletedQueue = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../queue/completed.json'), 'utf8')).simulationCompleted

    // fs.writeFileSync(path.resolve(__dirname, '../queue/completed.json'), JSON.stringify({
    //   simulationCompleted: [...simulationCompletedQueue, ...simulationProcessedCompleted]
    // }), 'utf8', (err) => {
    //   if (err) throw `Error updating the completed queue -> ${err}`
    // })
  } catch (e) {
    console.error(e)
  }
}

setInterval(verify, 1500)
setInterval(watcher, 3000)
