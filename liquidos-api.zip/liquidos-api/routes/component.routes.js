const express = require('express')
const component = express.Router()
const componentController = require('../controllers/component.controller')
const authMiddleware = require('../middlewares/auth')
const passport = require('passport')

require('../middlewares/passport')(passport)

component.post('/component/', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, componentController.getComponents)

component.post('/component/new', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsAdmin, componentController.newComponent)

component.post('/component/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, componentController.seeComponent)

component.put('/component/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsAdmin, componentController.editComponent)

component.delete('/component/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsAdmin, componentController.deleteComponent)

module.exports = component
