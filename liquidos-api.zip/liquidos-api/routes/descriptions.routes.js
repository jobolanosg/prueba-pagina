const express = require('express')
const description = express.Router()
const descriptionController = require('../controllers/description.controller')
const authMiddleware = require('../middlewares/auth')
const passport = require('passport')

require('../middlewares/passport')(passport)

description.post('/description/new', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, descriptionController.newDescription)

description.post('/description/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, descriptionController.seeDescription)

description.put('/description/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, descriptionController.editDescription)

module.exports = description
