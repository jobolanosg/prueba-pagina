const mongoose = require('mongoose')

let reservoirDescriptionSchema = mongoose.Schema({
  simulation_id: {
    ref: 'Simulation',
    required: true,
    unique: true,
    $type: mongoose.Schema.Types.ObjectId
  },
  mesh: {
    type: String,
    iLength: {
      type: String,
      values: [Number]
    },
    internalRadius: Number,
    externalRadius: Number,
    jLength: {
      type: String,
      values: [Number]
    },
    kLength: {
      type: String,
      values: [Number]
    },
    top: {
      type: String,
      values: [Number]
    },
    iPermeability: {
      type: String,
      values: [Number]
    },
    jPermeability: {
      type: String,
      values: [Number]
    },
    kPermeability: {
      type: String,
      values: [Number]
    },
    porosity: {
      type: String,
      values: [Number]
    },
    activeBlock: {
      type: String,
      values: [Number]
    },
    flowUnit: {
      type: String,
      values: [Number]
    }
  },
  poreCompressibility: Number,
  referencePressure: Number,
  matrixDensity: Number
}, { typeKey: '$type', timestamps: true })

module.exports = mongoose.model('ReservoirDescription', reservoirDescriptionSchema)
