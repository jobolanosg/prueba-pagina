const mongoose = require('mongoose')

let wellsAndTimeDescriptionSchema = mongoose.Schema({
  simulation_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Simulation',
    required: true,
    unique: true
  },
  times: [Number],
  timesWithChange: [Number],
  schedule: [
    {
      time: Number,
      wellIndex: Number,
      typeOfWell: {
        type: String,
        enum: ['Producer', 'Injector']
      },
      injectedFluid: String,
      wellRadius: Number,
      skin: Number,
      operativeConditionType: String,
      operativeConditionValue: Number,
      scheduleType: String,
      numberOfPerforations: Number,
      perforations: [
        {
          iIndex: Number,
          jIndex: Number,
          kIndex: Number
        }
      ]
    }
  ]
}, { timestamps: true })

module.exports = mongoose.model('WellsAndTimeDescription', wellsAndTimeDescriptionSchema)
