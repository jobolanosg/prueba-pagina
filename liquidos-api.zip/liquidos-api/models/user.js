const mongoose = require('mongoose')
const bcrypt = require('bcryptjs')

let userSchema = mongoose.Schema({
  name: {
    type: String
  },
  lastname: String,
  role: {
    type: String,
    enum: [
      'system_admin', 'user'
    ],
    default: 'user'
  },
  email: {
    type: String,
    unique: true,
    required: true
  },
  password: {
    type: String,
    required: true
  }
}, { timestamps: true })

userSchema.pre('save', async function (next) {
  this.password = await bcrypt.hashSync(this.password, 10)
  next()
})

userSchema.methods.comparePassword = function (passw) {
  return bcrypt.compareSync(passw, this.password)
}

module.exports = mongoose.model('User', userSchema)
