const mongoose = require('mongoose')

let initialConditionsDescriptionSchema = mongoose.Schema({
  simulation_id: {
    $type: mongoose.Schema.Types.ObjectId,
    ref: 'Simulation',
    required: true,
    unique: true
  },
  type: {
    $type: String,
    enum: ['Properties array', 'Gravity-Capillary Equilibrium']
  },
  gravcapequDataByFlowUnit: [
    {
      referencePressure: Number,
      referenceDepth: Number,
      gasOilContactDepth: Number,
      oilWaterContactDepth: Number,
      oilResidualSaturationAtGasZone: Boolean,
      oilResidualSaturationAtWaterzone: Boolean
    }
  ],
  pressure:
    {
      type: String,
      values: [Number]
    },
  waterSaturation:
    {
      type: String,
      values: [Number]
    },
  gasSaturation:
    {
      type: String,
      values: [Number]
    },
  globalComposition:
    {
      type: String,
      values: [Number]
    },
  gravcapequCompDepthDataByFlowUnit: [
    {
      referencePressure: Number,
      referenceDepth: Number,
      thermalGradient: Number,
      referenceTemperature: Number,
      oilResidualSaturationAtGasZone: Boolean,
      oilResidualSaturationAtWaterzone: Boolean
    }
  ]
}, { typeKey: '$type', timestamps: true })

module.exports = mongoose.model('InitialConditionsDescription', initialConditionsDescriptionSchema)
