const mongoose = require('mongoose')

let numericalControlDescriptionSchema = mongoose.Schema({
  simulation_id: {
    $type: mongoose.Schema.Types.ObjectId,
    ref: 'Simulation',
    required: true,
    unique: true
  },
  maxTimeStep: Number,
  minTimeStep: Number,
  initialTimeStep: Number,
  maxAllowedPressureChange: Number,
  maxAllowedSaturationChange: Number,
  maxAllowedMolChange: Number,
  accelerationFactor: Number,
  minIterations: Number,
  maxIterations: Number,
  maxNumberOfCuts: Number,
  toleranceType: String,
  pressureTolerance: {
    value: Number,
    type: String
  },
  molTolerance: {
    value: Number,
    type: String
  },
  saturationTolerance: {
    value: Number,
    type: String
  }
}, { typeKey: '$type', timestamps: true })

module.exports = mongoose.model('NumericalControlDescription', numericalControlDescriptionSchema)
