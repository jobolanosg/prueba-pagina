const mongoose = require('mongoose')

let fluidsDescriptionSchema = mongoose.Schema({
  simulation_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Simulation',
    required: true,
    unique: true
  },
  fluidsDescriptionByFlowUnit: [
    {
      pvtTable: {
        pressure: [Number],
        solutionGas: [Number],
        volatilizedOil: [Number],
        oilVolumetricFactor: [Number],
        gasVolumetricFactor: [Number],
        oilViscosity: [Number],
        gasViscosity: [Number]
      },
      waterProperties: {
        referencePressure: Number,
        volumetricFactor: Number,
        viscosity: Number,
        compressibility: Number,
        viscosityDependencePressure: Number
      },
      gasDensity: Number,
      oilDensity: Number,
      waterDensity: Number,
      equationOfState: {
        type: String,
        enum: ['Peng-Robinson'],
        default: 'Peng-Robinson'
      },
      componentsProperties: {
        name: [String],
        acentricFactor: [Number],
        criticalPressure: [Number],
        criticalTemperature: [Number],
        criticalVolume: [Number],
        molecularWeight: [Number]
      },
      binaryInteractionCoefficients: [Number],
      waterPropertiesCompositional: {
        referencePressure: Number,
        volumetricFactor: Number,
        viscosity: Number,
        viscosityDependencePressure: Number,
        density: Number,
        acentricFactor: Number,
        criticalPressure: Number,
        criticalTemperature: Number,
        criticalVolume: Number,
        molecularWeight: Number
      }
    }
  ]
}, { timestamps: true })

module.exports = mongoose.model('FluidsDescription', fluidsDescriptionSchema)
