const mongoose = require('mongoose')

let temporarySchema = new mongoose.Schema({
  simulation_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Simulation',
    required: true,
    unique: true
  },
  saved: String
}, { timestamps: true })

module.exports = mongoose.model('Temporary', temporarySchema, 'temporary')
