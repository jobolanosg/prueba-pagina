const logger = require('./logger')

const Simulation = require('../models/simulation')
const ReservoirDescription = require('../models/reservoirDescription')
const FluidsDescription = require('../models/fluidsDescription')
const RockFluidDescription = require('../models/rockFluidDescription')
const InitialConditionsDescription = require('../models/initialConditionsDescription')
const NumericalControlDescription = require('../models/numericalControlDescription')
const WellsAndTimeDescription = require('../models/wellsAndTimeDescription')
const SettingsDescription = require('../models/settingsDescription')

async function SearchSimulationAndDelete (SimulationId) {
  logger.log('info', 'msg : Deleting Simulation')
  await ReservoirDescription.remove({ simulation_id: SimulationId }, (err) => { err ? logger.warn('info', 'msg : ReservoirDescription not found') : logger.log('info', 'msg : ReservoirDescription deleted') })
  await FluidsDescription.remove({ simulation_id: SimulationId }, (err) => { err ? logger.warn('info', 'msg : FluidsDescription not found') : logger.log('info', 'msg : FluidsDescription deleted') })
  await RockFluidDescription.remove({ simulation_id: SimulationId }, (err) => { err ? logger.warn('info', 'msg : RockFluidDescription not found') : logger.log('info', 'msg : RockFluidDescription deleted') })
  await InitialConditionsDescription.remove({ simulation_id: SimulationId }, (err) => { err ? logger.warn('info', 'msg : InitialConditionsDescription not found') : logger.log('info', 'msg : InitialConditionsDescription deleted') })
  await NumericalControlDescription.remove({ simulation_id: SimulationId }, (err) => { err ? logger.warn('info', 'msg : NumericalControlDescription not found') : logger.log('info', 'msg : NumericalControlDescription deleted') })
  await WellsAndTimeDescription.remove({ simulation_id: SimulationId }, (err) => { err ? logger.warn('info', 'msg : WellsAndTimeDescription not found') : logger.log('info', 'msg : WellsAndTimeDescription deleted') })
  await SettingsDescription.remove({ simulation_id: SimulationId }, (err) => { err ? logger.warn('info', 'msg : SettingsDescription not found') : logger.log('info', 'msg : SettingsDescription deleted') })
}

let deleteSimulationCascade = {
  deletingWithProjectId: async function (projectId) {
    let SimulationToDelete = await Simulation.find({
      project_id: projectId
    }, null, null).exec()
    SimulationToDelete.forEach(function (SimulationToDeleteActual) {
      SearchSimulationAndDelete(SimulationToDeleteActual._id)
    })
  },
  deleteWithSimulationId: async function (SimulationId) {
    await SearchSimulationAndDelete(SimulationId)
  }
}

module.exports = deleteSimulationCascade
