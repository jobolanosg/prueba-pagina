const mongoose = require('mongoose')
const config = require('../config')
const logger = require('../helpers/logger')
const User = require('../models/user')

mongoose.connect(config.DATABASE.NAME, config.DATABASE.OPTIONS)
  .then(() => logger.log('info', `Connection successful with MongoDB,
                               888
                               888
                               888
  .d8888b  .d88b.  .d88b.  .d88888
  88K     d8P  Y8bd8P  Y8bd88" 888
  "Y8888b.8888888888888888888  888
      X88Y8b.    Y8b.    Y88b  888
  88888P' "Y8888  "Y8888  "Y88888
  `))
  .catch((err) => logger.error(`${err.status || 500} - ${err.message}`))

User.create({
  name: 'admin',
  lastname: 'icito',
  role: 'system_admin',
  email: 'admin@exergy-ma.co',
  password: 'optiplex7010'
}, (err, result) => {
  if (err) {
    logger.error('error', err)
  }
})
User.create({
  name: 'test',
  lastname: 'test',
  role: 'system_admin',
  email: 'test@test.com',
  password: '1234567890'
}, (err, result) => {
  if (err) {
    logger.error('error', err)
  }
  process.exit()
})
