const mongoose = require('mongoose')

let rockFluidDescriptionSchema = mongoose.Schema({
  simulation_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Simulation',
    required: true,
    unique: true
  },
  rockFluidDescriptionByFlowUnit: [
    {
      gasOilRockFluid: {
        gasSaturation: [Number],
        gasRelativePermeability: [Number],
        oilRelativePermeability: [Number],
        gasOilCapillaryPressure: [Number]
      },
      waterOilRockFluid: {
        waterSaturation: [Number],
        waterRelativePermeability: [Number],
        oilRelativePermeability: [Number],
        oilWaterCapillaryPressure: [Number]
      }
    }
  ]
}, { timestamps: true })

module.exports = mongoose.model('RockFluidDescription', rockFluidDescriptionSchema)
