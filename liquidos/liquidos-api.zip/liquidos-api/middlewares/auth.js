const logger = require('../helpers/logger')
const config = require('../config')
const passport = require('passport')
require('./passport')(passport)
const jwt = require('jsonwebtoken')
const User = require('../models/user')

let authMiddleware = {
  createToken: function (user) {
    let token = jwt.sign(user.toJSON(), config.JWT.SECRET, {
      expiresIn: 86400,
      algorithm: 'HS512'
    })
    return token
  },
  isAuthenticatedAsAdmin: function (err, req, res, next) {
    if (err) {
      logger.error('error', err)
      throw err
    }
    User.findOne({
      email: req.body.email
    }, function (err, user) {
      if (err) {
        logger.error('error', err)
        throw err
      }
      if (user.role === 'system_admin') {
        logger.log('info', `success : true, msg : Admin logged In.`)
        next()
      } else {
        logger.log('info', 'success : false, msg : Requires administrator permissions.')
        res.status(401).send({ success: false })
      }
    })
  },
  isAuthenticatedAsUser: function (err, req, res, next) {
    if (err) {
      logger.error('error', err)
      throw err
    }
    User.findOne({
      email: req.body.email
    }, function (err, user) {
      if (err) {
        logger.error('error', err)
        throw err
      }
      if (user.role === 'user') {
        logger.log('info', `success : true, msg : User logged In.`)
        next()
      }
    })
  }
}
module.exports = authMiddleware
