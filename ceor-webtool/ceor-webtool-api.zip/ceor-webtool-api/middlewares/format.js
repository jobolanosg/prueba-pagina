const logger = require('../helpers/logger')

const getter = {
  cleanNulls: function (arrayToClean) {
    return arrayToClean.filter(current => current !== null).filter(current => current !== '').map(current => Number(current)).filter(current => !isNaN(current))
  },
  settingsSwitch: function (settingsSwitch) {
    if (settingsSwitch) {
      switch (settingsSwitch) {
        case 'Compositional':
          return 'CMP'
        case 'Extended Black Oil':
          return 'BOM'
        default:
          logger.log('info', 'Settings fluid model dont match')
          return ''
      }
    } else {
      logger.log('info', 'Settings fluid model inexistent')
      return ''
    }
  },
  getHeatCapacityCoefficient: function (waterObject) {
    return getter.cleanNulls([waterObject.heatCapacityCoefficient1, waterObject.heatCapacityCoefficient2, waterObject.heatCapacityCoefficient3, waterObject.heatCapacityCoefficient4, waterObject.heatCapacityCoefficient5])
  },
  reservoirMeshType: function (meshType) {
    if (meshType) {
      switch (meshType) {
        case 'Cartesian - Reservoir':
          return 'CART'
        case 'Cartesian - Core':
          return 'CORE'
        case 'Radial':
          return 'RADIAL'
        case 'Corner Point':
          return 'CORNERPOINT'
        default:
          logger.log('info', 'Mesh type dont match')
          return ''
      }
    } else {
      logger.log('info', 'Mesh type inexistent')
      return ''
    }
  },
  directionType: function (dirType) {
    if (dirType) {
      switch (dirType) {
        case 'Constant for all blocks':
          return 'CONS'
        case 'Varying in I direction':
          return 'IVAR'
        case 'Varying in J direction':
          return 'JVAR'
        case 'Varying in K direction':
          return 'KVAR'
        case 'Specified for all blocks':
          return 'ALL'
        case 'Constant for all blocks':
          return 'CONS'
        case 'Direct Assigment':
          return 'PROPARRAY'
        case 'Gravitational and Capillary Equilibrium':
          return 'GRAVCAPEQU'
        case 'Gravitational and Capillary Equilibrium - Composition With Depth':
          return 'GRAVCAPEQU_COMPDEPTH'
        default:
          logger.log('info', 'direction Type dont match')
          return ''
      }
    } else {
      logger.log('info', 'direction Type inexistent')
      return ''
    }
  },
  fluidFlowUnitsObject: function (body) {
    let flowUnits = {}
    if (getter.isCompositional(body)) {
      for (let i = 0; i < body.settingsData.flowUnitsSelect.length; i++) {
        Object.defineProperty(flowUnits, String(i + 1), {
          value: {
            gasoilcomp: {
              comp: body.fluidsData.components.componentList,
              wc: getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`accentricFactor${i}`])),
              pc_psi: getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`criticalPressure${i}`])),
              tc_r: getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`criticalTemperature${i}`])),
              mw: getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`molecularWeight${i}`])),
              vc: getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`criticalVolume${i}`])),
              vc2: getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`criticalVolume${i}`])),
              ZRA: getter.isThermal(body) ? getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`zRA${i}`])) : Array(body.fluidsData.components.componentList.length).fill(0),
              S0: getter.isThermal(body) ? getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`s0${i}`])) : Array(body.fluidsData.components.componentList.length).fill(0),
              S1: getter.isThermal(body) ? getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`s1${i}`])) : Array(body.fluidsData.components.componentList.length).fill(0),
              teb: getter.isThermal(body) ? getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`boilingPoint${i}`])) : Array(body.fluidsData.components.componentList.length).fill(0),
              CP1: getter.isThermal(body) ? getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`cP1${i}`])) : Array(body.fluidsData.components.componentList.length).fill(0),
              CP2: getter.isThermal(body) ? getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`cP2${i}`])) : Array(body.fluidsData.components.componentList.length).fill(0),
              CP3: getter.isThermal(body) ? getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`cP3${i}`])) : Array(body.fluidsData.components.componentList.length).fill(0),
              CP4: getter.isThermal(body) ? getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`cP4${i}`])) : Array(body.fluidsData.components.componentList.length).fill(0),
              CP5: getter.isThermal(body) ? getter.cleanNulls(body.fluidsData.fluidComponents[i].dataComponentsProperties.map(current => current[`cP5${i}`])) : Array(body.fluidsData.components.componentList.length).fill(0)
            },
            interaction_coef: body.fluidsData.fluidComponents[i].binaryInteractionCoefficients.map(current => Object.values(current).reverse()),
            watprop: {
              rpw: Number(body.fluidsData.waterProperties[i].referencePressure),
              bwo: Number(body.fluidsData.waterProperties[i].volumetricFactor),
              vwo: Number(body.fluidsData.waterProperties[i].viscosity),
              cbw: Number(body.fluidsData.waterProperties[i].compressibility),
              cvw: Number(body.fluidsData.waterProperties[i].dependeceOfViscosityWithPressure),
              denwat: Number(body.fluidsData.waterProperties[i].density),
              wc: Number(body.fluidsData.waterProperties[i].acentricFactor),
              pc: Number(body.fluidsData.waterProperties[i].criticalPressure),
              tc: Number(body.fluidsData.waterProperties[i].criticalTemperature),
              mww: Number(body.fluidsData.waterProperties[i].molecularWeigth),
              vc: Number(body.fluidsData.waterProperties[i].criticalVolume),
              BIP: getter.isThermal(body) ? body.fluidsData.fluidComponents[i].includeWaterBinaryInteractionCoefficientsChecked ? getter.cleanNulls(Object.values(body.fluidsData.fluidComponents[i].includeWaterBinaryInteractionCoefficients[0])) : Array(body.fluidsData.components.componentList.length).fill(0) : Array(body.fluidsData.components.componentList.length).fill(0),
              CP: getter.isThermal(body) ? getter.getHeatCapacityCoefficient(body.fluidsData.waterProperties[i]) : Array(5).fill(0),
              shift: getter.isThermal(body) ? Array(Number(body.fluidsData.waterProperties[i].volumeShift), Number(body.fluidsData.waterProperties[i].volumeShiftCoefficient)) : Array(2).fill(0)
            },
            ppoints: 20,
            maxpress: 5000
          },
          writable: true,
          enumerable: true,
          configurable: true
        })
      }
    } else {
      for (let i = 0; i < body.settingsData.flowUnitsSelect.length; i++) {
        Object.defineProperty(flowUnits, String(i + 1), {
          value: {
            type: 'CONDGAS',
            pvttable: {
              pr: getter.cleanNulls(body.fluidsData.properties[i].PVTProperties.map(current => current[`pressure${i}`])),
              rs: getter.cleanNulls(body.fluidsData.properties[i].PVTProperties.map(current => current[`solutionGas${i}`])),
              bo: getter.cleanNulls(body.fluidsData.properties[i].PVTProperties.map(current => current[`oilVolumetricFactor${i}`])),
              bg: getter.cleanNulls(body.fluidsData.properties[i].PVTProperties.map(current => current[`gasVolumetricFactor${i}`])),
              uo: getter.cleanNulls(body.fluidsData.properties[i].PVTProperties.map(current => current[`oilViscosity${i}`])),
              ug: getter.cleanNulls(body.fluidsData.properties[i].PVTProperties.map(current => current[`gasViscosity${i}`])),
              rv: getter.cleanNulls(body.fluidsData.properties[i].PVTProperties.map(current => current[`volatilizedOil${i}`]))
            },
            watprop: {
              rpw: Number(body.fluidsData.properties[i].waterProperties.referencePressure),
              bwo: Number(body.fluidsData.properties[i].waterProperties.volumetricFactor),
              vwo: Number(body.fluidsData.properties[i].waterProperties.viscosity),
              cbw: Number(body.fluidsData.properties[i].waterProperties.compressibility),
              cvw: Number(body.fluidsData.properties[i].waterProperties.dependenceOfViscosityWithPressure)
            },
            dengas: Number(body.fluidsData.properties[i].densityStandartConditions.Gas),
            denoil: Number(body.fluidsData.properties[i].densityStandartConditions.Oil),
            denwat: Number(body.fluidsData.properties[i].densityStandartConditions.Water)
          },
          writable: true,
          enumerable: true,
          configurable: true
        })
      }
    }
    return flowUnits
  },
  rockFluidFlowUnitsObject: function (body) {
    let flowUnits = {}
    for (let i = 0; i < body.settingsData.flowUnitsSelect.length; i++) {
      Object.defineProperty(flowUnits, String(i + 1), {
        value: {
          ogtable: {
            sg: getter.cleanNulls(body.rockFluidData[i].gasOilRelativePermeability.map(current => current[`gasSaturationGasOilGasOil${i}`])),
            krg: getter.cleanNulls(body.rockFluidData[i].gasOilRelativePermeability.map(current => current[`gasRelativePermeabilityGasOilGasOil${i}`])),
            kro: getter.cleanNulls(body.rockFluidData[i].gasOilRelativePermeability.map(current => current[`oilRelativePermeabilityGasOilGasOil${i}`])),
            pcgo: getter.cleanNulls(body.rockFluidData[i].gasOilRelativePermeability.map(current => current[`oilGasCapillaryPressureGasOilGasOil${i}`]))
          },
          owtable: {
            sw: getter.cleanNulls(body.rockFluidData[i].oilWaterRelativePermeability.map(current => current[`waterSaturationOilWaterOilWater${i}`])),
            krw: getter.cleanNulls(body.rockFluidData[i].oilWaterRelativePermeability.map(current => current[`waterRelativePermeabilityOilWaterOilWater${i}`])),
            kro: getter.cleanNulls(body.rockFluidData[i].oilWaterRelativePermeability.map(current => current[`oilRelativePermeabilityOilWaterOilWater${i}`])),
            pcow: getter.cleanNulls(body.rockFluidData[i].oilWaterRelativePermeability.map(current => current[`waterOilCapillaryPressureOilWaterOilWater${i}`]))
          }
        },
        writable: true,
        enumerable: true,
        configurable: true
      })
    }
    return flowUnits
  },
  thermalFlowUnitsObject: function (body) {
    let flowUnits = {}
    for (let i = 0; i < body.settingsData.flowUnitsSelect.length; i++) {
      Object.defineProperty(flowUnits, String(i + 1), {
        value: {
          thermal_properties: {
            conduct_o: getter.isThermal(body) ? Number(body.thermalData.properties.data[i].oilConductivity) : 0,
            conduct_g: getter.isThermal(body) ? Number(body.thermalData.properties.data[i].gasConductivity) : 0,
            conduct_w: getter.isThermal(body) ? Number(body.thermalData.properties.data[i].waterConductivity) : 0,
            conduct_r: getter.isThermal(body) ? Number(body.thermalData.properties.data[i].rockConductivity) : 0,
            heat_cap_r: getter.isThermal(body) ? Number(body.thermalData.properties.data[i].rockHeatCapacity) : 0,
          },
          thermal_expansion: {
            bpor: getter.isThermal(body) ? Number(body.thermalData.properties.data[i].porosityChangeThermalCoefficient) : 0,
            trpor: getter.isThermal(body) ? Number(body.thermalData.properties.data[i].referenceTemperature) : 0
          }
        },
        writable: true,
        enumerable: true,
        configurable: true
      })
    }
    return flowUnits
  },
  initialConditionsFlowUnitsObject: function (body) {
    let flowUnits = {}
    for (let i = 0; i < body.settingsData.flowUnitsSelect.length; i++) {
      Object.defineProperty(flowUnits, String(i + 1), {
        value: {
          zi: {
            type: 'CONS',
            value: getter.cleanNulls(body.initialConditionsData.flowUnit[i].globalComposition.map(current => Object.values(current)).flat().reverse())
          },
          refp: Number(body.initialConditionsData.flowUnit[i].referencePressure),
          refd: Number(body.initialConditionsData.flowUnit[i].referenceDepth),
          dgoc: Number(body.initialConditionsData.flowUnit[i].gasOil),
          dwoc: Number(body.initialConditionsData.flowUnit[i].oilWater),
          tgrd: Number(body.initialConditionsData.flowUnit[i].thermalGradient),
          reft: Number(body.initialConditionsData.flowUnit[i].referenceTemperature),
          gzso: body.initialConditionsData.flowUnit[i].ResidualGasZone
            ? 'YES'
            : 'NOT',
          wzso: body.initialConditionsData.flowUnit[i].ResidualWaterZone
            ? 'YES'
            : 'NOT'
        },
        writable: true,
        enumerable: true,
        configurable: true
      })
    }
    return flowUnits
  },
  scheduleSwitch: function (inputSwitched) {
    if (inputSwitched) {
      switch (inputSwitched) {
        case 'Gas':
          return 'GAS'
        case 'Water':
          return 'WAT'
        case 'Oil':
          return 'OIL'
        case 'Bottom Hole Pressure':
          return 'BHFP'
        case 'Shut in':
          return 'SHUT'
        case 'Constant':
          return 'CON'
        case 'Interpolated':
          return 'INT'
        default:
          logger.log('info', 'schedule dont match')
          return ''
      }
    } else {
      logger.log('info', 'schedule inexistent')
      return ''
    }
  },
  constraintTypeSwitch: function (constraintType) {
    if (constraintType) {
      switch (constraintType) {
        case 'Gas':
          return 'QGSC'
        case 'Water':
          return 'QWSC'
        case 'Oil':
          return 'QOSC'
        default:
          logger.log('info', 'constraint Type dont match')
          return ''
      }
    } else {
      logger.log('info', 'constraint Type inexistent')
      return ''
    }
  },
  perforations: function (body, date, wellindex) {
    let perforationsSchema = []
    let perforationsCurrent = body.wellsScheduleData.perforations[wellindex].tableData.filter(current => current[`datePerforations${wellindex}`] === date)[0]
    if (perforationsCurrent) {
      for (let index = 1; index < Object.keys(perforationsCurrent).length; index++) {
        perforationsSchema[index] = {
          i: perforationsCurrent[`perforation${wellindex}-${index}`] ? Number(perforationsCurrent[`perforation${wellindex}-${index}`].split(/[\s,]+/)[0]) : 0,
          j: perforationsCurrent[`perforation${wellindex}-${index}`] ? Number(perforationsCurrent[`perforation${wellindex}-${index}`].split(/[\s,]+/)[1]) : 0,
          k: perforationsCurrent[`perforation${wellindex}-${index}`] ? Number(perforationsCurrent[`perforation${wellindex}-${index}`].split(/[\s,]+/)[2]) : 0
        }
      }
    } else {
      perforationsSchema.push({
        i: 0,
        j: 0,
        k: 0
      })
    }

    return perforationsSchema
  },
  injections: function (body, type, date, name) {
    if (type === 'INJECTOR') {
      let injectionsObject = body.wellsScheduleData.injections.filter((current) => current.name === name);
      let injectionsData = injectionsObject.map((current) => current.tableData).flat().filter((current) => current[`datePerforations${injectionsObject[0].id}`] === date)[0]
      if (injectionsData) {
        if (Object.values(injectionsData).some(current => current === null)) {
          return []
        } else {
          return getter.cleanNulls(Object.values(injectionsData).slice(1))
        }
      } else {
        return []
      }
    }
  },
  schedule: function (body) {
    let scheduleSchema = []
    let scheduleCurrent = []

    for (let scheduleIndex = 0; scheduleIndex < body.wellsScheduleData.schedule.length; scheduleIndex++) {
      for (let rowIndex = 0; rowIndex < body.wellsScheduleData.schedule[scheduleIndex].tableData.length; rowIndex++) {
        scheduleCurrent.push({
          id: body.wellsScheduleData.schedule[scheduleIndex].id,
          ...getter.wellInformation(body, body.wellsScheduleData.schedule[scheduleIndex].name),
          ...body.wellsScheduleData.schedule[scheduleIndex].tableData[rowIndex]
        })
      }
    }

    scheduleCurrent = scheduleCurrent.filter(current => current[`date${current.id}`] !== null || current[`date${current.id}`] !== '')

    for (let scheduleCurrentIndex = 0; scheduleCurrentIndex < scheduleCurrent.length; scheduleCurrentIndex++) {
      let currentId = scheduleCurrent[scheduleCurrentIndex].id
      scheduleSchema[scheduleCurrentIndex] = {
        time: scheduleCurrent[scheduleCurrentIndex][`date${currentId}`] ? Number(scheduleCurrent[scheduleCurrentIndex][`date${currentId}`].slice(scheduleCurrent[scheduleCurrentIndex][`date${currentId}`].indexOf('(') + 1, (scheduleCurrent[scheduleCurrentIndex][`date${currentId}`].indexOf(')')))) : 0,
        well: Number(scheduleCurrent[scheduleCurrentIndex].index) + 1,
        type: scheduleCurrent[scheduleCurrentIndex].type.toUpperCase(),
        injf: getter.scheduleSwitch(scheduleCurrent[scheduleCurrentIndex][`referenceFluid${currentId}`]),
        radw: Number(scheduleCurrent[scheduleCurrentIndex].radius),
        skin: Number(scheduleCurrent[scheduleCurrentIndex][`skin${currentId}`]),
        wsop: scheduleCurrent[scheduleCurrentIndex][`constraintType${currentId}`] !== 'Flow Rate at Standart Conditions' ? getter.scheduleSwitch(scheduleCurrent[scheduleCurrentIndex][`constraintType${currentId}`]) : getter.constraintTypeSwitch(scheduleCurrent[scheduleCurrentIndex][`referenceFluid${currentId}`]),
        // qlty: Number(scheduleCurrent[scheduleCurrentIndex][`quality${currentId}`]),
        // injt: Number(scheduleCurrent[scheduleCurrentIndex][`temperature${currentId}`]),
        sche: getter.scheduleSwitch(scheduleCurrent[scheduleCurrentIndex][`scheduleType${currentId}`]),
        vlsp: Number(scheduleCurrent[scheduleCurrentIndex][`constraintValue${currentId}`]),
        numperf: Number(scheduleCurrent[scheduleCurrentIndex][`numberOfPerforations${currentId}`]),
        perf: getter.perforations(body, scheduleCurrent[scheduleCurrentIndex][`date${currentId}`], currentId).filter(current => current !== null),
        indexcomp: getter.isCompositional(body) ? Array(body.fluidsData.components.componentList.length + 1).fill(1).map((current, index) => current + index) : [],
        vifc: getter.isCompositional(body) ? scheduleCurrent[scheduleCurrentIndex][`date${currentId}`] ? getter.injections(body, scheduleCurrent[scheduleCurrentIndex].type.toUpperCase(), scheduleCurrent[scheduleCurrentIndex][`date${currentId}`], scheduleCurrent[scheduleCurrentIndex].name) : [] : [],
      }
    }

    scheduleSchema.sort((a, b) => a.time - b.time)
    return scheduleSchema.filter(current => current.numperf)
  },
  wellInformation: function (body, wellName) {
    let index = body.wellsScheduleData.wells.map(current => current.name).indexOf(wellName)
    return { index: index, type: body.wellsScheduleData.wells[index].type, radius: body.wellsScheduleData.wells[index].radius, name: body.wellsScheduleData.wells[index].name }
  },
  isCompositional: function (body) {
    return body.settingsData.selectedFluidsModel === 'Compositional'
  },
  isThermal: function (body) {
    return body.simulation.type === 'Thermal CEOR'
  },
  isCeor: function (body) {
    return body.simulation.type === 'Chemical EOR'
  },
  isGasCeor: function (body) {
    return body.simulation.type === 'Chemical Gas EOR'
  },
  speciesNanoparticleTransfer: function (body) {
    if (body.componentsData.nanoparticle.kinetics.retention.model === 'Double Site') {
      return [{
        phenomenom: 'INTERCEPTATION',
        model: 'KINCOEF',
        type: 'CONS',
        origin_phase: 2,
        destiny_phase: 3,
        ks: [Number(body.componentsData.surfactant.kinetics.interception.GasWater)]
      },
      {
        model: 'SITE1',
        origin_phase: 3,
        destiny_phase: 5,
        kir: Number(body.componentsData.surfactant.kinetics.retention.coefficientOfPluggingRate),
        s1max: Number(body.componentsData.surfactant.kinetics.retention.maxRetentionSite1)
      },
      {
        model: 'SITE2',
        origin_phase: 3,
        destiny_phase: 6,
        kra: Number(body.componentsData.surfactant.kinetics.retention.coefficientOfDeposition),
        krd: Number(body.componentsData.surfactant.kinetics.retention.coefficientOfReleaseRate),
        s2max: Number(body.componentsData.surfactant.kinetics.retention.coefficientOfPluggingRate)
      }]
    }
  },
  getSpecies: function (body) {
    if (getter.isThermal(body)) {
      return {
        config: {
          numspe: 1,
          names: ['NANOPARTICLE'],
          ref_phase: ['WAT'],
          phases: [
            ['OIL', 'GAS', 'WAT', 'ROCK', 'SITE1', 'SITE2'],
            ['EQ', 'NEQ', 'NEQ', '0.0', 'NEQ', 'NEQ']
          ]
        },
        properties: {
          1: {
            spec_g: Number(body.componentsData.nanoparticle.properties.specificGravity),
            molecular_weight: Number(body.componentsData.nanoparticle.properties.molecularWeight),
            diameter: Number(body.componentsData.nanoparticle.properties.diameter),
            density: Number(body.componentsData.nanoparticle.properties.density),
            beta: Number(body.componentsData.nanoparticle.properties.surfaceAreaCoefficient),
          }
        },
        output: {
          1: {
            reservoir: ['XWAT', 'XOIL', 'XGAS', 'XSITE1', 'XSITE2'],
            well: ['QWAT', 'QOIL', 'QGAS', 'QWATAC', 'QOILAC', 'QGASAC', 'PPMWAT', 'PPMWATAC', 'PPMOIL', 'PPMOILAC', 'PPMGAS', 'PPMGASAC']
          }
        },
        transfer: {
          1: getter.speciesNanoparticleTransfer(body)
        },
        modifiers: {
          1: getter.nanoparticleModifiers(body)
        },
        numcont: {
          1: {
            type: 'RXTOL',
            value: 1e-4
          }
        },
        wellcons: {
          schedule: getter.wellcons(body, ['nanoparticle'])
        }
      }
    } if (getter.isCeor(body)) {
      return {
        config: {
          numspe: 1,
          names: ['POLYMER', 'NANOPARTICLE', 'SURFACTANT'],
          ref_phase: ['WAT', 'WAT', 'WAT'],
          phases: [
            ['OIL', 'GAS', 'WAT', 'ROCK', 'SITE1', 'SITE2', 'DEG'],
            ['0.0', '0.0', 'NEQ', 'NEQ', '0.0', '0.0', 'NEQ'],
            ['0.0', '0.0', 'NEQ', '0.0', 'NEQ', 'NEQ', '0.0']
          ]
        },
        properties: {
          1: {
            density: Number(body.componentsData.polymer.properties.density),
            molecular_weight: Number(body.componentsData.polymer.properties.molecularWeight),
            specific_gravity: Number(body.componentsData.polymer.properties.specificGravity),
            RRF: Number(body.componentsData.polymer.properties.rrf),
            IPV: Number(body.componentsData.polymer.properties.ipv),
          },
          2: {
            spec_g: Number(body.componentsData.nanoparticle.properties.specificGravity),
            molecular_weight: Number(body.componentsData.nanoparticle.properties.molecularWeight),
            diameter: Number(body.componentsData.nanoparticle.properties.diameter),
            density: Number(body.componentsData.nanoparticle.properties.density),
            beta: Number(body.componentsData.nanoparticle.properties.surfaceAreaCoefficient),
          }
        },
        output: {
          1: {
            reservoir: ['XPW', 'XPM'],
            well: ['QPW', 'QPWAC']
          },
          2: {
            reservoir: ['XWAT', 'XSITE1', 'XSITE2'],
            well: ['PPMWAT', 'PPMWATAC']
          }
        },
        transfer: {
          1: [{
            model: 'ADS_2PARAM',
            origin_phase: 3,
            destiny_phase: 4,
            xs: getter.cleanNulls(body.componentsData.polymer.kinetics.adsorption.adsorptionTable.map(current => current.adsorbedPolymer)),
            xsmeq: getter.cleanNulls(body.componentsData.polymer.kinetics.adsorption.adsorptionTable.map(current => current.equilibriumAdsorbedPolymer)),
            kpA: Number(body.componentsData.polymer.kinetics.adsorption.adjustParameter),
            kpB: Number(body.componentsData.polymer.kinetics.adsorption.equilibriumRateConstant)
          },
          {
            model: 'ADS_2PARAM',
            origin_phase: 4,
            destiny_phase: 3,
            xs: getter.cleanNulls(body.componentsData.polymer.kinetics.adsorption.adsorptionTable.map(current => current.equilibriumAdsorbedPolymer)),
            xsmeq: getter.cleanNulls(body.componentsData.polymer.kinetics.adsorption.adsorptionTable.map(current => current.adsorbedPolymer)),
            kpA: Number(body.componentsData.polymer.kinetics.adsorption.equilibriumRateConstant),
            kpB: Number(body.componentsData.polymer.kinetics.adsorption.adjustParameter)
          },
          {
            model: 'DEG',
            origin_phase: 3,
            destiny_phase: 7,
            xpdeg: getter.cleanNulls(body.componentsData.polymer.kinetics.degradation.degradationTable.map(current => current.concentration)),
            tdeg: getter.cleanNulls(body.componentsData.polymer.kinetics.degradation.degradationTable.map(current => current.degradationTemperature)),
            ea: getter.cleanNulls(body.componentsData.polymer.kinetics.degradation.degradationTable.map(current => current.activationEnergy)),
            kp_quim: Number(body.componentsData.polymer.kinetics.degradation.quemicalDegradationConstant),
            kp_mec: Number(body.componentsData.polymer.kinetics.degradation.mechanicalDegradationConstant),
            Alpha_mec: Number(body.componentsData.polymer.kinetics.degradation.mechanicalDegradationExponent),
          },
          {
            model: 'DEG',
            origin_phase: 7,
            destiny_phase: 3,
            xpdeg: getter.cleanNulls(body.componentsData.polymer.kinetics.degradation.degradationTable.map(current => current.concentration)),
            tdeg: getter.cleanNulls(body.componentsData.polymer.kinetics.degradation.degradationTable.map(current => current.degradationTemperature)),
            ea: getter.cleanNulls(body.componentsData.polymer.kinetics.degradation.degradationTable.map(current => current.activationEnergy)),
            kp_quim: Number(body.componentsData.polymer.kinetics.degradation.quemicalDegradationConstant),
            kp_mec: Number(body.componentsData.polymer.kinetics.degradation.mechanicalDegradationConstant),
            Alpha_mec: Number(body.componentsData.polymer.kinetics.degradation.mechanicalDegradationExponent)
          }],
          2: getter.speciesNanoparticleTransfer(body)
        },
        modifiers: {
          1: getter.polymerModifiers(body),
          2: getter.nanoparticleModifiers(body),
        },
        numcont: {
          1: {
            type: 'RXTOL',
            value: 1e-4
          },
          2: {
            type: 'RXTOL',
            value: 1e-4
          }
        },
        wellcons: {
          schedule: getter.wellcons(body, ['polymer', 'nanoparticle'])
        }
      }
    } else if (body.settingsData.surfactantSelect) {
      return {
        config: {
          numspe: 1,
          names: ['SURFACTANT'],
          ref_phase: ['GAS'],
          phases: [
            ["OIL", "GAS", "WAT", "ROCK"],
            ["NEQ", "0.0", "NEQ", "NEQ"]
          ]
        },
        properties: {
          1: {
            molecular_weight: Number(body.componentsData.surfactant.properties.molecularWeight),
            specific_gravity: Number(body.componentsData.surfactant.properties.specificGravity)
          }
        },
        output: {
          1: {
            reservoir: ['XOIL', 'XWAT', 'XGAS', 'XROCK'],
            well: ['QOIL', 'QWAT', 'QGAS', 'QOILAC', 'QWATAC', 'QGASAC', 'PPMWAT', 'PPMGAS', 'PPMOIL', 'PPMWATAC', 'PPMGASAC', 'PPMOILAC']
          }
        },
        transfer: {
          1: [{
            phenomenom: 'INTERCEPTATION',
            model: 'KINCOEF',
            type: 'CONS',
            origin_phase: 2,
            destiny_phase: 1,
            ks: [Number(body.componentsData.surfactant.kinetics.interception.GasOil)]
          },
          {
            phenomenom: 'INTERCEPTATION',
            model: 'KINCOEF',
            type: 'CONS',
            origin_phase: 2,
            destiny_phase: 3,
            ks: [Number(body.componentsData.surfactant.kinetics.interception.GasWater)]
          },
          {
            phenomenom: 'DISOLUTION',
            model: 'FIRST_ORDER',
            origin_phase: 1,
            destiny_phase: 3,
            xs: getter.cleanNulls(body.componentsData.surfactant.kinetics.dissolution.map(current => current.chemicalConcentration)),
            xsmeq: getter.cleanNulls(body.componentsData.surfactant.kinetics.dissolution.map(current => current.dilutedChemicalAtEquilibriumConcentration)),
            ks: getter.cleanNulls(body.componentsData.surfactant.kinetics.dissolution.map(current => current.kineticParameter)),
          },
          {
            phenomenom: 'DISOLUTION',
            model: 'FIRST_ORDER',
            origin_phase: 3,
            destiny_phase: 1,
            xs: getter.cleanNulls(body.componentsData.surfactant.kinetics.dissolution.map(current => current.dilutedChemicalAtEquilibriumConcentration)),
            xsmeq: getter.cleanNulls(body.componentsData.surfactant.kinetics.dissolution.map(current => current.chemicalConcentration)),
            ks: getter.cleanNulls(body.componentsData.surfactant.kinetics.dissolution.map(current => current.kineticParameter)),
          },
          {
            phenomenom: 'SORPTION',
            model: 'FIRST_ORDER',
            origin_phase: 1,
            destiny_phase: 4,
            xs: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.chemicalConcentration)),
            xsmeq: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.adsorbedChemicalAtEquilibriumConcentration)),
            ks: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.kineticParameter)),
          },
          {
            phenomenom: 'SORPTION',
            model: 'FIRST_ORDER',
            origin_phase: 4,
            destiny_phase: 1,
            xs: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.adsorbedChemicalAtEquilibriumConcentration)),
            xsmeq: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.chemicalConcentration)),
            ks: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.kineticParameter)),
          },
          {
            phenomenom: 'SORPTION',
            model: 'FIRST_ORDER',
            origin_phase: 3,
            destiny_phase: 4,
            xs: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.chemicalConcentration)),
            xsmeq: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.adsorbedChemicalAtEquilibriumConcentration)),
            ks: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.kineticParameter)),
          },
          {
            phenomenom: 'SORPTION',
            model: 'FIRST_ORDER',
            origin_phase: 4,
            destiny_phase: 3,
            xs: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.adsorbedChemicalAtEquilibriumConcentration)),
            xsmeq: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.chemicalConcentration)),
            ks: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.kineticParameter)),
          }]
        },
        modifiers: {
          1: getter.surfactantModifiers(body)
        },
        numcont: {
          1: {
            type: body.componentsData.surfactant.numericalSettings.toleranceType,
            value: body.componentsData.surfactant.numericalSettings.tolerance,
            sequential: body.componentsData.surfactant.numericalSettings.sequential
          }
        },
        wellcons: {
          schedule: getter.wellcons(body, ['surfactant'])
        }
      }
    } else if (body.settingsData.nanoparticleSelect) {
      return {
        config: {
          numspe: 1,
          names: ['NANOPARTICLE'],
          ref_phase: ['GAS'],
          phases: [
            ['OIL', 'GAS', 'WAT', 'ROCK', 'SITE1', 'SITE2'],
            ['NEQ', 'NEQ', 'NEQ', '0.0', 'NEQ', 'NEQ']
          ]
        },
        properties: {
          1: {
            spec_g: Number(body.componentsData.nanoparticle.properties.specificGravity),
            molecular_weight: Number(body.componentsData.nanoparticle.properties.molecularWeight),
            diameter: Number(body.componentsData.nanoparticle.properties.diameter),
            density: Number(body.componentsData.nanoparticle.properties.density),
            beta: Number(body.componentsData.nanoparticle.properties.surfaceAreaCoefficient),
          }
        },
        output: {
          1: {
            reservoir: ['XWAT', 'XOIL', 'XGAS', 'XSITE1', 'XSITE2'],
            well: ['QWAT', 'QOIL', 'QGAS', 'QOILAC', 'QWATAC', 'QGASAC', 'PPMGAS', 'PPMWAT', 'PPMOIL', 'PPMGASAC', 'PPMWATAC', 'PPMOILAC']
          }
        },
        transfer: {
          1: getter.speciesNanoparticleTransfer(body)
        },
        modifiers: {
          1: getter.nanoparticleModifiers(body),
        },
        numcont: {
          1: {
            type: body.componentsData.nanoparticle.numericalSettings.toleranceType,
            value: body.componentsData.nanoparticle.numericalSettings.tolerance,
            sequential: body.componentsData.nanoparticle.numericalSettings.sequential
          }
        },
        wellcons: {
          schedule: getter.wellcons(body, ['nanoparticle'])
        }
      }
    } else {
      return {
        config: {
          numspe: 2,
          names: ['FOAMER', 'NANOPARTICLE'],
          ref_phase: ['OIL', 'OIL'],
          phases: [
            ['OIL', 'GAS', 'WAT', 'ROCK', 'SITE1', 'SITE2'],
            ['NEQ', 'NEQ', 'NEQ', 'NEQ', '0.0', '0.0'],
            ['NEQ', 'NEQ', 'NEQ', '0.0', 'NEQ', 'NEQ']
          ]
        },
        properties: {
          1: {
            molecular_weight: Number(body.componentsData.surfactant.properties.molecularWeight),
            specific_gravity: Number(body.componentsData.surfactant.properties.specificGravity)
          },
          2: {
            spec_g: Number(body.componentsData.nanoparticle.properties.specificGravity),
            molecular_weight: Number(body.componentsData.nanoparticle.properties.molecularWeight),
            diameter: Number(body.componentsData.nanoparticle.properties.diameter),
            density: Number(body.componentsData.nanoparticle.properties.density),
            beta: Number(body.componentsData.nanoparticle.properties.surfaceAreaCoefficient),
          }
        },
        output: {
          1: {
            reservoir: ['XOIL', 'XWAT', 'XGAS', 'XROCK'],
            well: ['QOIL', 'QWAT', 'QGAS', 'QOILAC', 'QWATAC', 'QGASAC']
          },
          2: {
            reservoir: ['XWAT', 'XOIL', 'XGAS', 'XSITE1', 'XSITE2'],
            well: ["QWAT", "QOIL", "QGAS", "QOILAC", "QWATAC", "QGASAC"]
          }
        },
        transfer: {
          1: [{
            phenomenom: 'INTERCEPTATION',
            model: 'KINCOEF',
            type: 'CONS',
            origin_phase: 2,
            destiny_phase: 1,
            ks: [Number(body.componentsData.surfactant.kinetics.interception.GasOil)]
          },
          {
            phenomenom: 'INTERCEPTATION',
            model: 'KINCOEF',
            type: 'CONS',
            origin_phase: 2,
            destiny_phase: 3,
            ks: [Number(body.componentsData.surfactant.kinetics.interception.GasWater)]
          },
          {
            phenomenom: 'DISOLUTION',
            model: 'FIRST_ORDER',
            origin_phase: 1,
            destiny_phase: 3,
            xs: getter.cleanNulls(body.componentsData.surfactant.kinetics.dissolution.map(current => current.chemicalConcentration)),
            xsmeq: getter.cleanNulls(body.componentsData.surfactant.kinetics.dissolution.map(current => current.dilutedChemicalAtEquilibriumConcentration)),
            ks: getter.cleanNulls(body.componentsData.surfactant.kinetics.dissolution.map(current => current.kineticParameter)),
          },
          {
            phenomenom: 'DISOLUTION',
            model: 'FIRST_ORDER',
            origin_phase: 1,
            destiny_phase: 3,
            xs: getter.cleanNulls(body.componentsData.surfactant.kinetics.dissolution.map(current => current.dilutedChemicalAtEquilibriumConcentration)),
            xsmeq: getter.cleanNulls(body.componentsData.surfactant.kinetics.dissolution.map(current => current.chemicalConcentration)),
            ks: getter.cleanNulls(body.componentsData.surfactant.kinetics.dissolution.map(current => current.kineticParameter)),
          },
          {
            phenomenom: 'SORPTION',
            model: 'FIRST_ORDER',
            origin_phase: 1,
            destiny_phase: 4,
            xs: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.chemicalConcentration)),
            xsmeq: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.dilutedChemicalAtEquilibriumConcentration)),
            ks: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.kineticParameter)),
          },
          {
            phenomenom: 'SORPTION',
            model: 'FIRST_ORDER',
            origin_phase: 1,
            destiny_phase: 4,
            xs: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.dilutedChemicalAtEquilibriumConcentration)),
            xsmeq: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.chemicalConcentration)),
            ks: getter.cleanNulls(body.componentsData.surfactant.kinetics.sorption.map(current => current.kineticParameter)),
          }],
          2: getter.speciesNanoparticleTransfer(body)
        },
        modifiers: {
          1: getter.surfactantModifiers(body),
          2: getter.nanoparticleModifiers(body),
        },
        numcont: {
          1: {
            type: 'RXTOL',
            value: 1e-4
          },
          2: {
            type: 'RXTOL',
            value: 1e-4
          }
        },
        wellcons: {
          schedule: getter.wellcons(body, ['surfactant', 'nanoparticle'])
        }
      }
    }
  },
  nanoparticleModifiers: function (body) {
    let modifiers = [];

    if (body.componentsData.nanoparticle.modifiers.porosity) {
      modifiers.push({
        property: 'POROSITY'
      })
    }

    if (body.componentsData.nanoparticle.modifiers.permeability) {
      modifiers.push({
        property: 'PERMEABILITY'
      })
    }

    if (body.componentsData.nanoparticle.modifiers.relativePermeability) {
      modifiers.push({
        property: 'RELATIVE_PERMEABILITY',
        max_ref_conc: Number(body.componentsData.nanoparticle.modifiers.optimalConcentration),
        rockfluid: {
          type: 'TAB',
          flowunits: getter.rockFluidNanoparticlesObject(body)
        }
      })
    }

    // if (body.componentsData.nanoparticle.viscosity.viscositySelect) {
    //   modifiers.push({
    //     property: 'VISCOSITY',
    //     temperature_val: getter.cleanNulls(body.componentsData.nanoparticle.viscosity.temperatureViscosity.map((current, index) => current[`temperatureViscosity${index}`])),
    //     ads_conc: getter.cleanNulls(body.componentsData.nanoparticle.viscosity.temperatureViscosity[0].data0.map(current => current[`AdsorptionOfAsphaltenesOnNanoparticles0`])),
    //     visco_reduction: body.componentsData.nanoparticle.viscosity.temperatureViscosity.map((current, index) => getter.cleanNulls(current[`data${index}`].map(actual => actual[`viscosityReduction${index}`])))
    //   })
    // }

    // if (body.componentsData.nanoparticle.upgrading.reactionsSelect) {
    //   modifiers.push({
    //     property: 'UPGRADING',
    //     reactions_number: body.componentsData.nanoparticle.upgrading.reactions.length,
    //     reactions: getter.reactionsObject(body)
    //   })
    // }

    return modifiers;
  },
  polymerModifiers: function (body) {
    let modifiers = [];

    if (body.componentsData.polymer.rheology.model === 'Herschel') {
      modifiers.push({
        property: 'VISCOSITY',
        model: 'HERSCHEL',
        kp: Number(body.componentsData.polymer.rheology.consistencyIndex),
        np: Number(body.componentsData.polymer.rheology.flowIndex),
        uinf: Number(body.componentsData.polymer.rheology.infinityViscosity),
        shear_rate_constant: Number(body.componentsData.polymer.rheology.apparentShearRateParameter)
      })
    }

    if (body.componentsData.polymer.rheology.model === 'Carreau') {
      let objectToPush = {
        property: 'VISCOSITY',
        model: 'CARREAU',
        np: Number(body.componentsData.polymer.rheology.flowIndex),
        uinf: Number(body.componentsData.polymer.rheology.infinityViscosity),
        shear_rate_constant: Number(body.componentsData.polymer.rheology.apparentShearRateParameter)
      }
      if (body.componentsData.polymer.rheology.consistencyIndexChecked) {
        Object.defineProperty(objectToPush, 'kp', {
          value: Number(body.componentsData.polymer.rheology.consistencyIndex),
          writable: true,
          enumerable: true,
          configurable: true
        })
      }
      if (body.componentsData.polymer.rheology.relaxionTimeChecked) {
        Object.defineProperty(objectToPush, 'lambdaC', {
          value: Number(body.componentsData.polymer.rheology.relaxionTime),
          writable: true,
          enumerable: true,
          configurable: true
        })
      }
      if (body.componentsData.polymer.rheology.viscosityAtRate0Checked) {
        Object.defineProperty(objectToPush, 'u0', {
          value: Number(body.componentsData.polymer.rheology.viscosityAtRate0),
          writable: true,
          enumerable: true,
          configurable: true
        })
      }
      if (body.componentsData.polymer.rheology.salinityConstantChecked) {
        Object.defineProperties(objectToPush, {
          A1: {
            value: Number(body.componentsData.polymer.rheology.salinityConstant1),
            writable: true,
            enumerable: true,
            configurable: true
          },
          A2: {
            value: Number(body.componentsData.polymer.rheology.salinityConstant2),
            writable: true,
            enumerable: true,
            configurable: true
          },
          A3: {
            value: Number(body.componentsData.polymer.rheology.salinityConstant3),
            writable: true,
            enumerable: true,
            configurable: true
          }
        })
      }

      modifiers.push(objectToPush)
    }

    if (body.componentsData.polymer.rheology.model === 'HB-MPR') {
      modifiers.push({
        property: 'VISCOSITY',
        model: 'HERSCHEL_MOD',
        kp: Number(body.componentsData.polymer.rheology.consistencyIndex),
        np: Number(body.componentsData.polymer.rheology.flowIndex),
        uinf: Number(body.componentsData.polymer.rheology.infinityViscosity),
        k_sol: Number(body.componentsData.polymer.rheology.solvationConstant),
        n_dis: Number(body.componentsData.polymer.rheology.dispersionIndex),
        v_form: Number(body.componentsData.polymer.rheology.shapeFactor),
        shear_rate_constant: Number(body.componentsData.polymer.rheology.apparentShearRateParameter)
      })
    }

    return modifiers;
  },
  surfactantModifiers: function (body) {
    let modifiers = [];
    modifiers.push({
      property: 'RELATIVE_PERMEABILITY',
      max_ref_conc: Number(body.componentsData.surfactant.properties.optimalConcentration),
      rockfluid: {
        type: 'TAB',
        flowunits: getter.rockFluidSurfactantObject(body)
      }
    })

    return modifiers;
  },
  rockFluidSurfactantObject: function (body) {
    let flowUnits = {}
    for (let i = 0; i < body.settingsData.flowUnitsSelect.length; i++) {
      Object.defineProperty(flowUnits, String(i + 1), {
        value: {
          ogtable: {
            sg: getter.cleanNulls(body.componentsData.surfactant.flowAlteration[i].gasOilData.map(current => current[`gasSaturation${i}`])),
            krg: getter.cleanNulls(body.componentsData.surfactant.flowAlteration[i].gasOilData.map(current => current[`gasRelativePermeability${i}`])),
            kro: getter.cleanNulls(body.componentsData.surfactant.flowAlteration[i].gasOilData.map(current => current[`oilRelativePermeabilityr${i}`])),
            pcgo: getter.cleanNulls(body.componentsData.surfactant.flowAlteration[i].gasOilData.map(current => current[`oilGasCapillaryPressure${i}`]))
          },
          owtable: {
            sw: getter.cleanNulls(body.componentsData.surfactant.flowAlteration[i].oilWaterData.map(current => current[`waterSaturation${i}`])),
            krw: getter.cleanNulls(body.componentsData.surfactant.flowAlteration[i].oilWaterData.map(current => current[`waterRelativePermeability${i}`])),
            kro: getter.cleanNulls(body.componentsData.surfactant.flowAlteration[i].oilWaterData.map(current => current[`oilWaterRelativePermeabilityr${i}`])),
            pcow: getter.cleanNulls(body.componentsData.surfactant.flowAlteration[i].oilWaterData.map(current => current[`oilwaterCapillaryPressure${i}`]))
          }
        },
        writable: true,
        enumerable: true,
        configurable: true
      })
    }
    return flowUnits
  },
  rockFluidNanoparticlesObject: function (body) {
    let flowUnits = {}
    for (let i = 0; i < body.settingsData.flowUnitsSelect.length; i++) {
      Object.defineProperty(flowUnits, String(i + 1), {
        value: {
          ogtable: {
            sg: getter.cleanNulls(body.componentsData.nanoparticle.flowAlteration[i].gasOilData.map(current => current[`gasSaturation${i}`])),
            krg: getter.cleanNulls(body.componentsData.nanoparticle.flowAlteration[i].gasOilData.map(current => current[`gasRelativePermeability${i}`])),
            kro: getter.cleanNulls(body.componentsData.nanoparticle.flowAlteration[i].gasOilData.map(current => current[`oilRelativePermeabilityr${i}`])),
            pcgo: getter.cleanNulls(body.componentsData.nanoparticle.flowAlteration[i].gasOilData.map(current => current[`oilGasCapillaryPressure${i}`]))
          },
          owtable: {
            sw: getter.cleanNulls(body.componentsData.nanoparticle.flowAlteration[i].oilWaterData.map(current => current[`waterSaturation${i}`])),
            krw: getter.cleanNulls(body.componentsData.nanoparticle.flowAlteration[i].oilWaterData.map(current => current[`waterRelativePermeability${i}`])),
            kro: getter.cleanNulls(body.componentsData.nanoparticle.flowAlteration[i].oilWaterData.map(current => current[`oilWaterRelativePermeability${i}`])),
            pcow: getter.cleanNulls(body.componentsData.nanoparticle.flowAlteration[i].oilWaterData.map(current => current[`oilwaterCapillaryPressure${i}`]))
          }
        },
        writable: true,
        enumerable: true,
        configurable: true
      })
    }
    return flowUnits
  },
  reactionsObject: function (body) {
    let reactions = {}
    for (let i = 0; i < body.componentsData.nanoparticle.upgrading.reactions.length; i++) {
      Object.defineProperty(reactions, String(i + 1), {
        value: {
          name: body.componentsData.nanoparticle.upgrading.reactions[i].name,
          ref_phase: body.componentsData.nanoparticle.upgrading.reactions[i].reactionPhase,
          reactants: getter.isCompositional(body) ? Array(body.fluidsData.components.componentList.length + 1).fill(1).map((current, index) => current + index) : [],
          products: getter.isCompositional(body) ? Array(body.fluidsData.components.componentList.length + 1).fill(1).map((current, index) => current + index) : [],
          stoich_coef_reac: getter.cleanNulls(Object.values(body.componentsData.nanoparticle.upgrading.reactions[i].stoichiometry[0])),
          stoich_coef_prod: getter.cleanNulls(Object.values(body.componentsData.nanoparticle.upgrading.reactions[i].stoichiometry[1])),
          reaction_order: Number(body.componentsData.nanoparticle.upgrading.reactions[i].reactionOrder),
          preexpfactor: Number(body.componentsData.nanoparticle.upgrading.reactions[i].preExponentialFactor),
          activation_e: Number(body.componentsData.nanoparticle.upgrading.reactions[i].activationEnergy),
          enthalpy: Number(body.componentsData.nanoparticle.upgrading.reactions[i].enthalpyOfReaction),
          adsorption: {
            type: body.componentsData.nanoparticle.upgrading.reactions[i].adsorptionIsothermForTheReactant === 'Langmuir' ? 'langmuir' : '',
            ref_temp: getter.cleanNulls(body.componentsData.nanoparticle.viscosity.temperatureReaction.map((current, index) => current[`temperature${index}`])),
            ref_conc: getter.cleanNulls(body.componentsData.nanoparticle.viscosity.temperatureViscosity[`0`].data0.map(current => current[`nanoparticlesConcentration0`])),
            adsorbed: body.componentsData.nanoparticle.viscosity.temperatureViscosity.map((current, index) => getter.cleanNulls(current[`data${index}`].map(actual => actual[`adsorptionConcentration${index}`])))
          }
        },
        writable: true,
        enumerable: true,
        configurable: true
      })
    }
    return reactions
  },
  wellcons: function (body, properties = ['nanoparticle']) {
    let wellCons = body.componentsData.wellSchedule.map((current, highIndex) => { return { wellname: body.wellsScheduleData.wells[highIndex].name, data: current.data.filter((current) => current[`date${highIndex}`]) } })
    let wellConsCurrent = []
    let wellConsSorted = []
    for (let i = 0; i < wellCons.length; i++) {
      for (let j = 0; j < wellCons[i].data.length; j++) {
        wellConsCurrent.push({
          wellname: wellCons[i].wellname,
          time: Number(wellCons[i].data[j][`date${i}`].slice(wellCons[i].data[j][`date${i}`].indexOf('(') + 1, (wellCons[i].data[j][`date${i}`].indexOf(')')))),
          well: i,
          ...wellCons[i].data[j]
        })
      }
    }
    wellConsSorted = wellConsCurrent.sort((a, b) => a.time - b.time)
    wellCons = []
    for (let index = 0; index < wellConsSorted.length; index++) {
      let wellConsCurrentObject = {
        time: wellConsSorted[index].time,
        well: wellConsSorted[index].well + 1
      }
      if (properties.includes('nanoparticle')) {
        Object.defineProperty(wellConsCurrentObject, String(1), {
          value: {
            type: body.componentsData.wellSchedule[wellConsSorted[index].well].type.nanoparticle === 'bbl/day' ? 'RATE' : 'CONC',
            vlxs: Number(wellConsSorted[index][`${properties[0]}${wellConsSorted[index].well}`])
          },
          writable: true,
          enumerable: true,
          configurable: true
        })
      }

      if (properties.includes('surfactant')) {
        Object.defineProperty(wellConsCurrentObject, String(1), {
          value: {
            type: body.componentsData.wellSchedule[wellConsSorted[index].well].type.surfactant === 'bbl/day' ? 'RATE' : 'CONC',
            vlxs: Number(wellConsSorted[index][`${properties[0]}${wellConsSorted[index].well}`])
          },
          writable: true,
          enumerable: true,
          configurable: true
        })
      }

      if (properties.includes('polymer')) {
        Object.defineProperty(wellConsCurrentObject, String(2), {
          value: {
            type: body.componentsData.wellSchedule[wellConsSorted[index].well].type.polymer === 'bbl/day' ? 'RATE' : 'CONC',
            vlxs: Number(wellConsSorted[index][`${properties[2]}${wellConsSorted[index].well}`])
          },
          writable: true,
          enumerable: true,
          configurable: true
        })
      }
      wellCons.push(wellConsCurrentObject)
    }
    return wellCons;
  },
  noFluidPhases: function (body) {
    if (body.surfactantSelect) {
      return ["ROCK"]
    } else if (body.nanoparticleSelect) {
      return ["ROCK", "SITE1", "SITE2"]
    }
  }
}

let formatMiddleware = {
  descriptionFormat: function (body) {
    try {
      let newBody = {
        id: body.simulation.id,
        info: body.simulation.info,
        data: {
          initialset: {
            flowmodel: getter.settingsSwitch(body.settingsData.selectedFluidsModel),
            simulation: 'SINGLE',
            workunits: body.settingsData.selectedWorkUnits.toUpperCase(),
            restart: 'NOT',
            matprint: 'NOT',
            consoleprint: 'NOT',
            fluid_phases: ['OIL', 'GAS', 'WAT'],
            no_fluid_phases: getter.noFluidPhases(body.settingsData),
            outres: [
              'PRES', 'SAT', 'MOLARFRAC', 'MOLES', 'TEMP', 'DENS', 'MOLW', 'VISC', 'TENTH', 'PHENTH', 'VISC'
            ],
            outwell: ['BHFP', 'PHSCRATE', 'PHSCAC', 'CMRATE', 'CMAC', 'CMPHRATE', 'GLOBALZ', 'API', 'VISC']
          },
          reservoir: {
            mesh: {
              type: getter.reservoirMeshType(body.reservoirData.selectedGridType),
              i: Number(body.reservoirData.numberBlock.IDirection),
              j: Number(body.reservoirData.numberBlock.JDirection),
              k: Number(body.reservoirData.numberBlock.KDirection),
              print_location: './Data/Results/VTKOutput/',
              vtkfile: body.simulation.name.toUpperCase(),
              ri: Number(body.reservoirData.blockWidths.InternalRadius),
              re: Number(body.reservoirData.blockWidths.ExternalRadius),
              radialmodel: 'LOG',
              dj: {
                type: getter.directionType(body.reservoirData.blockWidths.JDirection.select),
                value: body.reservoirData.blockWidths.JDirection.value.split(/[ ,]+/).map(current => Number(current))
              },
              dk: {
                type: getter.directionType(body.reservoirData.blockWidths.KDirection.select),
                value: body.reservoirData.blockWidths.KDirection.value.split(/[ ,]+/).map(current => Number(current))
              },
              di: {
                type: getter.directionType(body.reservoirData.blockWidths.IDirection.select),
                value: body.reservoirData.blockWidths.IDirection.value.split(/[ ,]+/).map(current => Number(current))
              },
              dtop: {
                type: getter.directionType(body.reservoirData.blockPropertiesData.firstLayerTop.select),
                value: body.reservoirData.blockPropertiesData.firstLayerTop.text.split(/[ ,]+/).map(current => Number(current))
              },
              permi: {
                type: getter.directionType(body.reservoirData.blockPropertiesData.permeability.IDirection.select),
                value: body.reservoirData.blockPropertiesData.permeability.IDirection.text.split(/[ ,]+/).map(current => Number(current))
              },
              permj: {
                type: getter.directionType(body.reservoirData.blockPropertiesData.permeability.JDirection.select),
                value: body.reservoirData.blockPropertiesData.permeability.JDirection.text.split(/[ ,]+/).map(current => Number(current))
              },
              permk: {
                type: getter.directionType(body.reservoirData.blockPropertiesData.permeability.KDirection.select),
                value: body.reservoirData.blockPropertiesData.permeability.KDirection.text.split(/[ ,]+/).map(current => Number(current))
              },
              por: {
                type: getter.directionType(body.reservoirData.blockPropertiesData.porosity.select),
                value: body.reservoirData.blockPropertiesData.porosity.text.split(/[ ,]+/).map(current => Number(current))
              },
              actblocks: {
                type: getter.directionType(body.reservoirData.blockPropertiesData.activeBlocks.select),
                value: body.reservoirData.blockPropertiesData.activeBlocks.text.split(/[ ,]+/).map(current => Number(current))
              },
              flowunits: {
                type: getter.directionType(body.reservoirData.blockPropertiesData.flowUnit.select),
                value: body.reservoirData.blockPropertiesData.flowUnit.text.split(/[ ,]+/).map(current => Number(current))
              }
            },
            cpor: Number(body.reservoirData.blockPropertiesData.poreCompressibility),
            prpor: Number(body.reservoirData.blockPropertiesData.referencePressure),
            denmat: Number(body.reservoirData.blockPropertiesData.matrixDensity),
            mwrock: 60.08
          },
          pvtmodel: {
            eosmodel: 'PENGROBINSON',
            eosversion: '2',
            includewater: false,
            flowunits: getter.fluidFlowUnitsObject(body),
            viscosity: {
              hydrocarbonmodel: {
                type: body.fluidsData.viscosity.model,
                coefficients: Object.values(body.fluidsData.viscosity).slice(1).map(current => Number(current))
              },
              watermodel: {
                type: 'P'
              }
            }
          },
          rockfluid: {
            type: 'TAB',
            flowunits: getter.rockFluidFlowUnitsObject(body)
          },
          // thermal: {
          //   model_form: getter.isThermal(body) ? body.thermalData.properties.thermalModel : '',
          //   overburden_heat_loss: {
          //     heat_cap_ob: getter.isThermal(body) ? Number(body.thermalData.heatLoss.heatCapacityOverburden) : 0,
          //     conduct_ob: getter.isThermal(body) ? Number(body.thermalData.heatLoss.conductivityOverburden) : 0,
          //     heat_cap_ub: getter.isThermal(body) ? Number(body.thermalData.heatLoss.heatCapacityUnderburden) : 0,
          //     conduct_ub: getter.isThermal(body) ? Number(body.thermalData.heatLoss.conductivityUnderburden) : 0,
          //     temp_ob: getter.isThermal(body) ? Number(body.thermalData.heatLoss.temperatureOverburden) : 0,
          //     grad_ob: getter.isThermal(body) ? Number(body.thermalData.heatLoss.gradientOverburden) : 0
          //   },
          //   flowunits: getter.thermalFlowUnitsObject(body),
          // },
          initcond: {
            type: getter.directionType(body.initialConditionsData.selectedType),
            po: {
              type: getter.directionType(body.initialConditionsData.pressure.select),
              value: getter.cleanNulls(body.initialConditionsData.pressure.text.split(' '))
            },
            sw: {
              type: getter.directionType(body.initialConditionsData.waterSaturation.select),
              value: getter.cleanNulls(body.initialConditionsData.waterSaturation.text.split(' '))
            },
            sg: {
              type: getter.directionType(body.initialConditionsData.gasSaturation.select),
              value: getter.cleanNulls(body.initialConditionsData.gasSaturation.text.split(' '))
            },
            zi: {
              type: getter.directionType(body.initialConditionsData.globalComposition.select),
              value: getter.isCompositional(body) ? getter.cleanNulls(body.initialConditionsData.globalComposition.data.map(current => Object.values(current)).flat()) : []
            },
            temp: {
              type: getter.directionType(body.initialConditionsData.temperature.select),
              value: getter.cleanNulls(body.initialConditionsData.temperature.text.split(' '))
            },
            flowunits: getter.initialConditionsFlowUnitsObject(body)
          },
          numcont: {
            dtmax: Number(body.numericalSettingsData.maxTimeChange),
            dtmin: Number(body.numericalSettingsData.minTimeChange),
            dtstart: Number(body.numericalSettingsData.initialTimeChange),
            maxpre: Number(body.numericalSettingsData.maxPressureChange),
            maxsat: Number(body.numericalSettingsData.maxSaturationChange),
            maxmol: Number(body.numericalSettingsData.maxMolarChange),
            maxtem: Number(body.numericalSettingsData.maxTemperatureChange),
            fdt: Number(body.numericalSettingsData.accelerationFactor),
            itmax: Number(body.numericalSettingsData.maxIterations),
            itmin: Number(body.numericalSettingsData.minIterations),
            ncuts: Number(body.numericalSettingsData.maxNumberOfCutsInNewtonMethod),
            linear_solver: {
              abstol: 1E-30,
              zerotol: 1E-40
            },
            potol: {
              type: body.numericalSettingsData.pressure.toleranceType,
              value: Number(body.numericalSettingsData.pressure.tolerance)
            },
            moltol: {
              type: body.numericalSettingsData.mol.toleranceType,
              value: Number(body.numericalSettingsData.mol.tolerance)
            }
            // htmtol: {
            //   type: getter.isThermal(body) ? body.numericalSettingsData.thermalProperty.toleranceType : '',
            //   value: getter.isThermal(body) ? Number(body.numericalSettingsData.thermalProperty.tolerance) : 0
            // }
          },
          wellcons: {
            timeimp: body.wellsScheduleData.simulationDates.map(current => current.days),
            wellindex: Array(body.wellsScheduleData.wells.length).fill(1).map((current, index) => current + index),
            timechange: getter.cleanNulls([...new Set(body.wellsScheduleData.scheduleDates.flat().map(current => current.slice(current.indexOf('(') + 1, (current.indexOf(')')))))]),
            schedule: getter.schedule(body)
          },
          species: getter.getSpecies(body)
        }
      }
      if (getter.isGasCeor(body)) {
        if (body.componentsData.surfactant.addFoamer) {
          if (body.componentsData.surfactant.foamerModel === 'Kovscek') {
            Object.defineProperty(newBody, 'com', {
              value: {
                foamer: {
                  initialset: {
                    outres: ['FTEXT', 'XTRAP', 'XFLOW', 'UF', 'KRF'],
                    outwell: ['QFTEXT', 'QFTEXTAC']
                  },
                  parameters: {
                    model: 'KOV',
                    kg_k: Number(body.componentsData.surfactant.kg_k),
                    kc_k: Number(body.componentsData.surfactant.kc_k),
                    alpha_k: Number(body.componentsData.surfactant.alpha_k),
                    xt_max: Number(body.componentsData.surfactant.xt_max),
                    beta_k: Number(body.componentsData.surfactant.beta_k),
                    pccr_max: Number(body.componentsData.surfactant.pccr_max),
                    ref_foamer: Number(body.componentsData.surfactant.ref_foamer),
                    foam_corey: Number(body.componentsData.surfactant.foam_corey),
                    surten: Number(body.componentsData.surfactant.surten)
                  }
                }
              },
              writable: true,
              enumerable: true,
              configurable: true
            })
          } else {
            Object.defineProperty(newBody, 'com', {
              value: {
                foamer: {
                  initialset: {
                    outres: ['FTEXT', 'XTRAP', 'XFLOW', 'UF', 'KRF'],
                    outwell: ['QFTEXT', 'QFTEXTAC']
                  },
                  parameters: {
                    model: 'KAM',
                    kg_k: Number(body.componentsData.surfactant.kg_k),
                    kc_k: Number(body.componentsData.surfactant.kc_k),
                    alpha_k: Number(body.componentsData.surfactant.alpha_k),
                    xt_max: Number(body.componentsData.surfactant.xt_max),
                    beta_k: Number(body.componentsData.surfactant.beta_k),
                    pccr_max: Number(body.componentsData.surfactant.pccr_max),
                    ref_foamer: Number(body.componentsData.surfactant.ref_foamer),
                    foam_corey: Number(body.componentsData.surfactant.foam_corey),
                    surten: Number(body.componentsData.surfactant.surten),
                    swc_k: Number(body.componentsData.surfactant.swc_k),
                    gradpo: Number(body.componentsData.surfactant.gradpo),
                  }
                }
              },
              writable: true,
              enumerable: true,
              configurable: true
            })
          }
        }
      }
      return newBody
    } catch (error) {
      console.log(error)
      logger.log('error', error)
    }
  }
}
module.exports = formatMiddleware