const mongoose = require('mongoose')

let projectSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  description: String,
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  collaborators: [
    {
      user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
      },
      permission: {
        type: String,
        enum: [
          'r', 'rw'
        ],
        default: 'r'
      }
    }
  ],
  simulations: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Simulation'
    }
  ]
}, { timestamps: true })

module.exports = mongoose.model('Project', projectSchema)
