const mongoose = require('mongoose')

let simulationSchema = new mongoose.Schema({
  name: {
    $type: String,
    required: true
  },
  description: String,
  project_id: {
    $type: mongoose.Schema.Types.ObjectId,
    ref: 'Project',
    required: true
  },
  collaborators: [
    {
      user_id: {
        $type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
      },
      permission: {
        $type: String,
        enum: [
          'r', 'rw'
        ],
        default: 'r'
      }
    }],
  type: {
    $type: String,
    enum: ['Chemical Gas EOR', 'Thermal CEOR', 'Chemical EOR']
  }
}, { typeKey: '$type', timestamps: true })

module.exports = mongoose.model('Simulation', simulationSchema)
