const path = require('path')
const chai = require('chai')
const chaiHttp = require('chai-http')
const server = require(path.resolve('./test', '../bin/www2'))
const expect = chai.expect

chai.use(chaiHttp)

let loginInfo = {
  'email': 'test@test.com',
  'password': '1234567890'
}

describe('User Routes', function () {
  describe('Login', function () {
    it('Should return "200" status and a Token Login then logout', function (done) {
      chai.request(server).post('/api/user/login').send(loginInfo).end(function (err, res) {
        expect(err).to.be.null
        expect(res.body.success).to.be.true
        expect(res.body.token).to.be.not.undefined
        expect(res).to.have.status(200)
        chai.request(server).post('/api/user/logout').send({ token: res.body.token }).end(function (err, res) {
          expect(err).to.be.null
          expect(res.body.success).to.be.true
          expect(res).to.have.status(200)
          done()
        })
      })
    })
  })
  describe('Get users', function () {
    it('Should return "200" status and a Token Login then get users and logout', function (done) {
      chai.request(server).post('/api/user/login').send(loginInfo).end(function (err, res) {
        expect(err).to.be.null
        expect(res.body.success).to.be.true
        expect(res.body.token).to.be.not.undefined
        let token = res.body.token
        expect(res).to.have.status(200)
        chai.request(server).post('/api/user').send({ token: token }).end(function (err, res) {
          expect(err).to.be.null
          expect(res.body.success).to.be.true
          expect(res.body.users).to.be.a('array')
          expect(res).to.have.status(200)
          chai.request(server).post('/api/user/logout').send({ token: token }).end(function (err, res) {
            expect(err).to.be.null
            expect(res.body.success).to.be.true
            expect(res).to.have.status(200)
            done()
          })
        })
      })
    })
  })
  describe('New user', function () {
    it('Should return "200" status and a Token Login then create a user, see it, edit it and delete it then logout', function (done) {
      chai.request(server).post('/api/user/login').send(loginInfo).end(function (err, res) {
        expect(err).to.be.null
        expect(res.body.success).to.be.true
        expect(res.body.token).to.be.not.undefined
        expect(res).to.have.status(200)
        let token = res.body.token
        let newUserInfo = {
          'name': 'testName',
          'lastname': 'testLastname',
          'role': 'system_admin',
          'email': 'testEmail@test.com',
          'password': '1234567890',
          'token': token
        }
        chai.request(server).post('/api/user/new').send(newUserInfo).end(function (err, res) {
          expect(err).to.be.null
          expect(res.body.success).to.be.true
          expect(res.body.user).to.be.a('object')
          let Userid = res.body.user._id
          expect(res).to.have.status(200)
          chai.request(server).post(`/api/user/${Userid}`).send({ token: token }).end(function (err, res) {
            expect(err).to.be.null
            expect(res.body.success).to.be.true
            expect(res.body.user).to.be.a('object')
            expect(res.body.user.name).to.be.equal(newUserInfo.name)
            expect(res.body.user.lastname).to.be.equal(newUserInfo.lastname)
            expect(res.body.user.role).to.be.equal(newUserInfo.role)
            expect(res.body.user.email).to.be.equal(newUserInfo.email)
            expect(res.body.user.password).to.be.not.undefined
            expect(res).to.have.status(200)
            let editUserInfo = {
              'name': 'testNameEdit',
              'lastname': 'testLastnameEdit',
              'role': 'system_admin',
              'email': 'testEmailEdit@testEdit.com',
              'password': '1234567890',
              'token': token
            }
            chai.request(server).put(`/api/user/${Userid}`).send(editUserInfo).end(function (err, res) {
              expect(err).to.be.null
              expect(res.body.success).to.be.true
              expect(res.body.user).to.be.a('object')
              expect(res.body.user.name).to.be.equal(editUserInfo.name)
              expect(res.body.user.lastname).to.be.equal(editUserInfo.lastname)
              expect(res.body.user.role).to.be.equal(editUserInfo.role)
              expect(res.body.user.email).to.be.equal(editUserInfo.email)
              expect(res.body.user.password).to.be.not.undefined
              expect(res).to.have.status(200)
              chai.request(server).delete(`/api/user/${Userid}`).send({ token: token }).end(function (err, res) {
                expect(err).to.be.null
                expect(res.body.success).to.be.true
                expect(res).to.have.status(200)
                chai.request(server).post('/api/user/logout').send({ token: token }).end(function (err, res) {
                  expect(err).to.be.null
                  expect(res.body.success).to.be.true
                  expect(res).to.have.status(200)
                  done()
                })
              })
            })
          })
        })
      })
    })
  })
})
