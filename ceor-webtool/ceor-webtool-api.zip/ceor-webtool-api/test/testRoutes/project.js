const path = require('path')
const chai = require('chai')
const chaiHttp = require('chai-http')
const server = require(path.resolve('./test', '../bin/www2'))
const expect = chai.expect

chai.use(chaiHttp)

let loginInfo = {
  'email': 'test@test.com',
  'password': '1234567890'
}

describe('Project Routes', function () {
  describe('Project Routes Login, See Projects, Edit Project, Delete Project and Logout', function () {
    it('Should return "200" status', function (done) {
      chai.request(server).post('/api/user/login').send(loginInfo).end(function (err, res) {
        expect(err).to.be.null
        expect(res.body.success).to.be.true
        expect(res.body.token).to.be.not.undefined
        expect(res).to.have.status(200)
        let token = res.body.token
        let newProjectInfo = {
          name: 'testProject',
          description: 'This is a project description',
          owner: '5bbbccf63da81a40dc32d898',
          collaborators: [
            {
              user_id: '5bbbccf63da81a40dc32d898',
              permission: Math.random() % 2 === 0 ? 'r' : 'rw'
            },
            {
              user_id: '5bbbccf63da81a40dc32d897',
              permission: Math.random() % 2 === 0 ? 'r' : 'rw'
            }
          ],
          'token': token
        }
        chai.request(server).post('/api/project/new').send(newProjectInfo).end(function (err, res) {
          expect(err).to.be.null
          expect(res.body.success).to.be.true
          expect(res.body.project).to.be.a('object')
          let Projectid = res.body.project._id
          expect(res).to.have.status(200)
          chai.request(server).post(`/api/project/${Projectid}`).send({ token: token }).end(function (err, res) {
            expect(err).to.be.null
            expect(res.body.success).to.be.true
            expect(res.body.project).to.be.a('object')
            expect(res.body.project.name).to.be.equal(newProjectInfo.name)
            expect(res.body.project.description).to.be.equal(newProjectInfo.description)
            expect(res.body.project.owner).to.be.not.undefined
            expect(res.body.project.collaborators).to.be.a('array')
            expect(res).to.have.status(200)
            let editProjectInfo = {
              name: 'testProjectEdit',
              description: 'This is a project description edited',
              owner: '5bbbccf63da81a40dc32d898',
              collaborators: [
                {
                  user_id: '5bbbccf63da81a40dc32d898',
                  permission: Math.random() % 2 === 0 ? 'r' : 'rw'
                },
                {
                  user_id: '5bbbccf63da81a40dc32d897',
                  permission: Math.random() % 2 === 0 ? 'r' : 'rw'
                }
              ],
              'token': token
            }
            chai.request(server).put(`/api/project/${Projectid}`).send(editProjectInfo).end(function (err, res) {
              expect(err).to.be.null
              expect(res.body.success).to.be.true
              expect(res.body.project).to.be.a('object')
              expect(res.body.project.name).to.be.equal(editProjectInfo.name)
              expect(res.body.project.description).to.be.equal(editProjectInfo.description)
              expect(res.body.project.owner).to.be.not.undefined
              expect(res.body.project.collaborators).to.be.a('array')
              expect(res).to.have.status(200)
              chai.request(server).delete(`/api/project/${Projectid}`).send({ ...loginInfo, token: token }).end(function (err, res) {
                expect(err).to.be.null
                expect(res.body.success).to.be.true
                expect(res).to.have.status(200)
                chai.request(server).post('/api/user/logout').send({ token: token }).end(function (err, res) {
                  expect(err).to.be.null
                  expect(res.body.success).to.be.true
                  expect(res).to.have.status(200)
                  done()
                })
              })
            })
          })
        })
      })
    })
  })
})
