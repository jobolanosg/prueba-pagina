const path = require('path')
const chai = require('chai')

const sinon = require('sinon')
require('sinon-mongoose')
const initialConditionsDescription = require(path.resolve('./test', '../models/initialConditionsDescription'))

const expect = chai.expect

describe('Initial Conditions Description', () => {
  it('Should return a "initialConditionsDescription" object', (done) => {
    let initialConditionsDescriptionMock = sinon.mock(initialConditionsDescription)
    let expected = {
      simulation_id: 'aEMfJ9thrCTF6FwT5d9RByaf',
      type: Math.random() % 2 === 0
        ? 'Properties array'
        : 'Gravity-Capillary Equilibrium',
      gravcapequDataByFlowUnit: [
        {
          referencePressure: 48,
          referenceDepth: 78,
          gasOilContactDepth: 15200,
          oilWaterContactDepth: 84782,
          oilResidualSaturationAtGasZone: true,
          oilResidualSaturationAtWaterzone: false
        }
      ],
      pressure: {
        type: 'scuare_meter',
        values: [12, 45, 545]
      },
      waterSaturation: {
        type: 'scuare_meter',
        values: [184, 68461, 586845]
      },
      gasSaturation: {
        type: 'scuare_meter',
        values: [44, 798, 46]
      },
      globalComposition: {
        type: 'scuare_meter',
        values: [587, 84, 254]
      },
      gravcapequCompDepthDataByFlowUnit: [
        {
          referencePressure: 48,
          referenceDepth: 78,
          thermalGradient: 15200,
          referenceTemperature: 84782,
          oilResidualSaturationAtGasZone: true,
          oilResidualSaturationAtWaterzone: false
        }
      ]
    }
    initialConditionsDescriptionMock.expects('find').yields(null, expected)
    initialConditionsDescription.find((err, result) => {
      initialConditionsDescriptionMock.verify()
      initialConditionsDescriptionMock.restore()
      expect(err).to.be.null
      expect(result.simulation_id).to.be.not.undefined
      expect(result.type).to.satisfy((val) => {
        return val === 'Properties array' || val === 'Gravity-Capillary Equilibrium'
      })
      expect(result.gravcapequDataByFlowUnit).to.be.a('array')
      result.gravcapequDataByFlowUnit.every((gravcapequDataByFlowUnitObject) => {
        return expect(gravcapequDataByFlowUnitObject).to.be.a('object') && expect(gravcapequDataByFlowUnitObject).to.have.property('referencePressure' && 'referenceDepth' && 'gasOilContactDepth' && 'oilWaterContactDepth' && 'oilResidualSaturationAtGasZone' && 'oilResidualSaturationAtWaterzone')
      })
      result.gravcapequDataByFlowUnit.every((gravcapequCompDepthDataByFlowUnit) => {
        return expect(gravcapequCompDepthDataByFlowUnit).to.be.a('object') && expect(gravcapequCompDepthDataByFlowUnit).to.have.property('referencePressure' && 'referenceDepth' && 'thermalGradient' && 'referenceTemperature' && 'oilResidualSaturationAtGasZone' && 'oilResidualSaturationAtWaterzone')
      })
      expect(result.pressure).to.be.a('object')
      expect(result.waterSaturation).to.be.a('object')
      expect(result.gasSaturation).to.be.a('object')
      expect(result.globalComposition).to.be.a('object')
      done()
    })
  })
})
