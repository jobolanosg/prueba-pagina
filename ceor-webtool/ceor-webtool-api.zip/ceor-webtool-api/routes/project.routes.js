const express = require('express')
const project = express.Router()
const projectController = require('../controllers/project.controller')
const authMiddleware = require('../middlewares/auth')
const passport = require('passport')

require('../middlewares/passport')(passport)

project.post('/project/', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsAdmin, projectController.getProjects)

project.post('/project/new', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, projectController.newProject)

project.post('/project/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, projectController.seeProject)

project.put('/project/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, projectController.editProject)

project.delete('/project/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, projectController.deleteProject)

module.exports = project
