const express = require('express')
const user = express.Router()
const userController = require('../controllers/user.controller')
const authMiddleware = require('../middlewares/auth')
const passport = require('passport')

require('../middlewares/passport')(passport)

user.post('/user/login', userController.LoginUser)

user.post('/user/logout', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsAdmin, userController.LogoutUser)

user.post('/user/', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsAdmin, userController.getUsers)

user.post('/user/new', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsAdmin, userController.newUser)

user.post('/user/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsAdmin, userController.seeUser)

user.put('/user/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsAdmin, userController.editUser)

user.delete('/user/:id', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsAdmin, userController.deleteUser)

user.post('/user/:id/simulation', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, userController.UserSimulation)

user.post('/user/:id/project', passport.authenticate('jwt', { session: false }), authMiddleware.isAuthenticatedAsUser, userController.UserProject)

module.exports = user
