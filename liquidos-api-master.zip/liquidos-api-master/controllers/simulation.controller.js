const logger = require('../helpers/logger')
const deleteSimulation = require('../helpers/deleteSimulation')
const format = require('../middlewares/format')
const Simulation = require('../models/simulation')
const User = require('../models/user')
const validator = require('validator')
const mongoose = require('mongoose')
const mongodb = require('mongodb')
const {
  exec,
  execSync
} = require('child_process')
const fs = require('fs')
const path = require('path')

async function download(bucket, id, value) {
  try {
    await bucket.openDownloadStreamByName(value)
      .pipe(fs.createWriteStream(`${path.resolve(__dirname, `../simulationManager/cache/${id}/Data/${value}`)}`))
      .on('error', function (error) {
        console.log(error)
      })
      .on('end', function () {
        console.log('done!')
      })
    return true
  } catch (error) {
    console.log(error)
  }
}

let simulationController = {
  getSimulation: function (req, res) {
    Simulation.find((err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : An error has occurred.')
        return res.json({
          success: false,
          msg: 'An error has occurred.'
        })
      }
      logger.log('info', 'success : true, msg : Simulation found.')
      return res.json({
        success: true,
        simulations: result
      })
    })
  },
  newSimulation: function (req, res) {
    let collaborators = []
    if (req.body.collaborators && req.body.collaborators[0] && Object.keys(req.body.collaborators[0]).length > 0) {
      let collaboratorsLength = req.body.collaborators.length
      for (let i = 0; i < collaboratorsLength; i++) {
        collaborators[i] = {
          user_id: new mongoose.mongo.ObjectId(validator.trim(validator.escape(req.body.collaborators[i].user_id))),
          permission: validator.trim(validator.escape(req.body.collaborators[i].permission))
        }
      }
    }
    Simulation.create({
      name: validator.trim(validator.escape(req.body.name)),
      description: validator.trim(validator.escape(req.body.description)),
      project_id: new mongoose.mongo.ObjectId(validator.trim(validator.escape(req.body.project_id))),
      collaborators: collaborators,
      type: validator.trim(validator.escape(req.body.type))
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : The simulation could not be created.')
        return res.json({
          success: false,
          msg: 'The simulation could not be created.'
        })
      }
      logger.log('info', 'success : true, msg : The simulation has been created correctly.')
      return res.json({
        success: true,
        simulations: result
      })
    })
  },
  seeSimulation: function (req, res) {
    Simulation.findById(validator.trim(validator.escape(req.params.id)), (err, result) => {
      if (err) {
        logger.log('info', 'success : false, msg : The simulation does not exist.')
        return res.json({
          success: false,
          msg: 'The simulation does not exist.'
        })
      }
      logger.log('info', 'success : true, msg : The simulation was found.')
      return res.json({
        success: true,
        simulations: result
      })
    })
  },
  editSimulation: function (req, res) {
    let collaborators = []
    if (req.body.collaborators && req.body.collaborators[0] && Object.keys(req.body.collaborators[0]).length > 0) {
      let collaboratorsLength = req.body.collaborators.length
      for (let i = 0; i < collaboratorsLength; i++) {
        collaborators[i] = {
          user_id: new mongoose.mongo.ObjectId(validator.trim(validator.escape(req.body.collaborators[i].user_id))),
          permission: validator.trim(validator.escape(req.body.collaborators[i].permission))
        }
      }
    }
    Simulation.findByIdAndUpdate(validator.trim(validator.escape(req.params.id)), {
      name: validator.trim(validator.escape(req.body.name)),
      description: validator.trim(validator.escape(req.body.description)),
      project_id: new mongoose.mongo.ObjectId(validator.trim(validator.escape(req.body.project_id))),
      collaborators: collaborators,
      type: validator.trim(validator.escape(req.body.type))
    }, {
      new: true,
      upsert: true
    }, (err, result) => {
      if (err) {
        logger.log('info', 'success : true, msg : The simulation was not found and was created correctly.')
        return res.json({
          success: true
        })
      }
      logger.log('info', 'success : true, msg : The simulation was found and updated correctly.')
      return res.json({
        success: true,
        simulations: result
      })
    })
  },
  deleteSimulation: function (req, res) {
    User.findOne({
      email: validator.trim(validator.escape(req.body.email))
    }, function (err, user) {
      if (err) {
        logger.error('Error', err)
        throw err
      }
      if (!user) {
        logger.log('info', 'success : false, msg : Confirmation failed. User not found.')
        res.status(401).send({
          success: false,
          msg: 'Confirmation failed. User not found.'
        })
      } else {
        if (user.comparePassword(validator.trim(validator.escape(req.body.password)))) {
          logger.log('info', 'success : true, msg : Confirmation Successful')
          deleteSimulation.deleteWithSimulationId(validator.trim(validator.escape(req.params.id)))
          Simulation.findByIdAndRemove(validator.trim(validator.escape(req.params.id)), (err, result) => {
            if (err) {
              logger.log('info', 'success : false, msg : The simulation was not found.')
              return res.json({
                success: false,
                msg: 'The simulation was not found.'
              })
            }
            logger.log('info', 'success : true, msg : The simulation was deleted correctly.')
            return res.json({
              success: true
            })
          })
        } else {
          logger.log('info', 'success : false, msg : Confirmation failed. Wrong password.')
          res.status(401).send({
            success: false,
            msg: 'Confirmation failed. Wrong password.'
          })
        }
      }
    })
  },
  executeSimulation: async function (req, res) {
    try {
      let simulationSchema = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../simulationManager/queue/queue.json'), 'utf8'))
      let simulationSchemaProcessing = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../simulationManager/queue/processing.json'), 'utf8'))
      if (simulationSchema.simulationQueue.find(function (element) { return element.id === req.body.simulation.id }) !== undefined || simulationSchemaProcessing.simulationProcessing.find(function (element) { return element.id === req.body.simulation.id }) !== undefined) {
        logger.log('info', 'An error has occurred')
        return res.json({
          success: false,
          msg: `Simulation already in queue`
        })
      } else {
        logger.log('info', 'execute Simulation')
        const newBody = await format.descriptionFormat(req.body)
        simulationSchema.simulationQueue.push({
          id: newBody.id,
          info: newBody.info,
          data: newBody.data
        })
        if (fs.writeFileSync(path.resolve(__dirname, '../simulationManager/queue/queue.json'), JSON.stringify(simulationSchema), 'utf8') === undefined) {
          logger.log('info', `added to the queue correctly`)
          return res.json({
            success: true,
            msg: `added to the queue correctly`,
            json: newBody.data
          })
        } else {
          logger.log('info', 'An error has occurred')
          return res.json({
            success: false,
            msg: `An error has occurred`
          })
        }
      }
    } catch (error) {
      console.log(error)
    }
  },
  fulminateSimulation: async function (req, res) {
    logger.log('info', 'fulminate Simulation')
    exec(`ps ax | grep ${validator.trim(validator.escape(req.body.id))}.exe`, (error, stdout) => {
      if (error) {
        console.error(`exec error: ${error}`)
        return res.json({
          success: false,
          msg: `exec error: ${error}`
        })
      }
      let elementToShow = stdout.trim().split('\n').filter(el => {
        return el.search('./') > 0
      })
      if (elementToShow.length === 0) {
        logger.log('info', 'The simulation is not being processed at this time')
        return res.json({
          success: true,
          msg: `The simulation is not being processed at this time`
        })
      } else {
        execSync(`kill ${elementToShow[0].split(' ')[0]}`)
        // execSync(`kill ${elementToShow[1].split(' ')[0]}`)
        try {
          let simulationProcessingQueue = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../simulationManager/queue/processing.json'), 'utf8')).simulationProcessing

          execSync(`cd ${path.resolve(__dirname, '../simulationManager/simulation')} && rm -rf ${validator.trim(validator.escape(req.body.id))}`)

          let simulationProcessedIncompleted = simulationProcessingQueue.filter((value) => {
            return value.id !== validator.trim(validator.escape(req.body.id))
          })

          fs.writeFileSync(path.resolve(__dirname, '../simulationManager/queue/processing.json'), JSON.stringify({
            simulationProcessing: simulationProcessedIncompleted
          }), 'utf8', (err) => {
            if (err) throw err
          })

          return res.json({
            success: true,
            msg: `Simulation fulminated`
          })
        } catch (e) {
          return res.json({
            success: false,
            msg: `${e}`
          })
        }
      }
    })
  },
  removeSimulation: async function (req, res) {
    try {
      let simulationProcessingQueue = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../simulationManager/queue/processing.json'), 'utf8')).simulationProcessing

      execSync(`cd ${path.resolve(__dirname, '../simulationManager/simulation')} && rm -rf ${validator.trim(validator.escape(req.params.id))}`)

      let simulationProcessedIncompleted = simulationProcessingQueue.filter((value) => {
        return value.id !== validator.trim(validator.escape(req.params.id))
      })

      fs.writeFileSync(path.resolve(__dirname, '../simulationManager/queue/processing.json'), JSON.stringify({
        simulationProcessing: simulationProcessedIncompleted
      }), 'utf8', (err) => {
        if (err) throw err
      })

      return res.json({
        success: true,
        msg: `Simulation removes`
      })
    } catch (e) {
      return res.json({
        success: false,
        msg: `${e}`
      })
    }
  },
  downloadSimulation: function (req, res) {
    execSync(`zip -r data *`, {
      cwd: `${path.resolve(__dirname, `../simulationManager/simulation/${req.body.id}`)}/Data/Results/VTKOutput`
    })
    // zip archive of your folder is ready to download
    res.download(`${path.resolve(__dirname, `../simulationManager/simulation/${req.body.id}`)}/Data/Results/VTKOutput` + '/data.zip')
    // const client = new mongodb.MongoClient('mongodb://127.0.0.1:27017/SimulationResult', {
    //   useNewUrlParser: true
    // })
    // client.connect(function (err) {
    //   if (err) {
    //     console.log('Error -> ', err)
    //   }
    //   const db = client.db('SimulationResult')
    //   let bucket = new mongodb.GridFSBucket(db, {
    //     bucketName: 'simulation',
    //     chunkSizeBytes: 1048576
    //   })
    //   bucket.find({
    //     'filename': new RegExp(`^${validator.trim(validator.escape(req.body.id))}`)
    //   }).toArray(async function (err, docs) {
    //     if (err) {
    //       console.log('Error -> ', err)
    //     }
    //     if (docs.length === 0) {
    //       client.close()
    //       res.json({
    //         success: false,
    //         msg: `No results found`
    //       })
    //     } else {
    //       try {
    //         let docsNameToDownload = docs.map(value => value.filename)
    //         if (fs.existsSync(`${path.resolve(__dirname, `../simulationManager/cache/${req.body.id}`)}`)) {
    //           execSync(`cd ${path.resolve(__dirname, '../simulationManager/cache/')} && rm -rf ${req.body.id}`)
    //         }
    //         execSync(`cd ${path.resolve(__dirname, '../simulationManager/cache/')} && mkdir -p ${req.body.id}/Data`)

    //         let results = await docsNameToDownload.map(async (value) => {
    //           return download(bucket, req.body.id, value)
    //         })
    //         Promise.all(results).then(function (completed) {
    //           if (completed.every(currentValue => currentValue)) {
    //             exec(`cd ${path.resolve(__dirname, `../simulationManager/cache/${req.body.id}`)} && sleep 2 && zip -r ${req.body.id}.zip Data && rm -r Data`, (error, stdout, stderr) => {
    //               if (error) {
    //                 console.error(`exec error: ${error}`)
    //                 return
    //               }
    //               res.download(`${path.resolve(__dirname, `../simulationManager/cache/${req.body.id}/${req.body.id}`)}.zip`)
    //             })
    //           } else {
    //             res.json({
    //               success: false,
    //               msg: `Error with files`
    //             })
    //           }
    //         }).catch(error => {
    //           console.log(error)
    //         })
    //       } catch (err) {
    //         console.log(err)
    //       }
    //     }
    //   })
    // })
  },
  checkSimulation: function (req, res) {
    if (fs.existsSync(`${path.resolve(__dirname, `../simulationManager/simulation/${req.body.id}`)}/Data/Results/wells.json`)) {
      res.json({
        success: true,
        msg: `files ready for download`
      })
    } else {
      res.json({
        success: false,
        msg: `No results found`
      })
    }
    // const client = new mongodb.MongoClient('mongodb://localhost:27017/SimulationResult', {
    //   useNewUrlParser: true
    // })
    // client.connect(function (err) {
    //   if (err) {
    //     console.log('Error -> ', err)
    //   }
    //   const db = client.db('SimulationResult')
    //   let bucket = new mongodb.GridFSBucket(db, {
    //     bucketName: 'simulation',
    //     chunkSizeBytes: 1048576
    //   })
    //   bucket.find({
    //     'filename': new RegExp(`^${validator.trim(validator.escape(req.body.id))}`)
    //   }).toArray(async function (err, docs) {
    //     if (err) {
    //       console.log('Error -> ', err)
    //     }
    //     if (docs.length === 0) {
    //       client.close()
    //       res.json({
    //         success: false,
    //         msg: `No results found`
    //       })
    //     } else {
    //       client.close()
    //       res.json({
    //         success: true,
    //         msg: `files ready for download`
    //       })
    //     }
    //   })
    // })
  },
  progressSimulation: function (req, res) {
    let simulationSchema = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../simulationManager/queue/queue.json'), 'utf8'))
    if (simulationSchema.simulationQueue.find(function (element) { return element.id === req.params.id }) !== undefined) {
      logger.log('info', 'Simulation waiting')
      return res.json({
        success: true,
        status: `Waiting`
      })
    } else {
      fs.readFile(`${path.resolve(__dirname, `../simulationManager/simulation/${req.params.id}`)}/Data/Results/error.log`, 'latin1', function (err, errorText) {
        if (err) {
          fs.readFile(`${path.resolve(__dirname, `../simulationManager/simulation/${req.params.id}`)}/Data/Results/Percentage.dat`, 'latin1', function (err, status) {
            if (err) {
              console.log(err)
              return res.json({
                success: false,
                status: 'No status available'
              })
            } else {
              if (status.trim() === '100') {
                if (fs.existsSync(`${path.resolve(__dirname, `../simulationManager/simulation/${req.params.id}`)}/Data/Results/wells.json`)) {
                  logger.log('info', 'Simulation reunning')
                  return res.json({
                    success: true,
                    status: 'Completed'
                  })
                } else {
                  logger.log('info', 'Simulation completed')
                  return res.json({
                    success: true,
                    status: status + ' %'
                  })
                }
              } else {
                logger.log('info', 'Simulation running')
                return res.json({
                  success: true,
                  status: status + ' %'
                })
              }
            }
          })
        } else {
          // if (errorText === '') {
          return res.json({
            success: true,
            status: 'Error'
          })
          // } else {

          // }
        }
      })
    }
  },
  logSimulation: function (req, res) {
    let simulationSchema = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../simulationManager/queue/queue.json'), 'utf8'))
    if (simulationSchema.simulationQueue.find(function (element) { return element.id === req.params.id }) !== undefined) {
      logger.log('info', 'Simulation waiting')
      return res.json({
        success: true,
        log: `Waiting`
      })
    } else {
      fs.readFile(`${path.resolve(__dirname, `../simulationManager/simulation/${req.params.id}`)}/Data/Results/Solver.log`, 'latin1', function (err, log) {
        if (err) {
          console.log(err)
          return res.json({
            success: false,
            log: 'No log available'
          })
        } else {
          return res.json({
            success: true,
            log: log
          })
        }
      })
    }
  },
  errorSimulation: function (req, res) {
    let simulationSchema = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../simulationManager/queue/queue.json'), 'utf8'))
    if (simulationSchema.simulationQueue.find(function (element) { return element.id === req.params.id }) !== undefined) {
      logger.log('info', 'Simulation waiting')
      return res.json({
        success: true,
        log: `Waiting`
      })
    } else {
      fs.readFile(`${path.resolve(__dirname, `../simulationManager/simulation/${req.params.id}`)}/Data/Results/error.log`, 'latin1', function (err, errorText) {
        if (err) {
          console.log(err)
          return res.json({
            success: false,
            error: 'No error available'
          })
        } else {
          return res.json({
            success: true,
            error: errorText
          })
        }
      })
    }
  },
  getDataFromWells: function (req, res) {
    fs.readFile(`${path.resolve(__dirname, `../simulationManager/simulation/${req.body.id}`)}/Data/Results/wells.json`, 'latin1', function (err, wells) {
      if (err) {
        console.log(err)
        return res.json({
          success: false,
          log: 'No results available'
        })
      } else {
        logger.log('info', 'Simulation wells')
        wells = JSON.parse(wells)
        let type = 'Nano';
        (Object.keys(wells[0]).includes('QSURFACTANT_WAT')) ? type = 'Sur' : type = 'Nano'
        let dummy = []
        if (type === 'Sur') {
          wells.forEach((well, i) => {
            dummy.push({
              data: [
                {
                  x: well.TIME,
                  y: well.BHFP,
                  type: 'scatter',
                  name: 'Bottom Hole Pressure [psi]',
                  yaxis: 'y',
                  visible: true
                },
                {
                  x: well.TIME,
                  y: well.phscrate.OIL,
                  type: 'scatter',
                  name: 'Oil Rate [STB/D]',
                  visible: 'legendonly',
                  yaxis: 'y2'
                },
                {
                  x: well.TIME,
                  y: well.phscrate.GAS,
                  type: 'scatter',
                  name: 'Gas Rate [SCF/D]',
                  visible: 'legendonly',
                  yaxis: 'y3'
                },
                {
                  x: well.TIME,
                  y: well.phscrate.WAT,
                  type: 'scatter',
                  name: 'Water Rate [STD/D]',
                  visible: 'legendonly',
                  yaxis: 'y2'
                },
                {
                  x: well.TIME,
                  y: well.phscac.OIL,
                  type: 'scatter',
                  name: 'Cumulative Oil [STD]',
                  visible: 'legendonly',
                  yaxis: 'y5'
                },
                {
                  x: well.TIME,
                  y: well.phscac.GAS,
                  type: 'scatter',
                  name: 'Cumulative Gas [SCF]',
                  visible: 'legendonly',
                  yaxis: 'y6'
                },
                {
                  x: well.TIME,
                  y: well.phscac.WAT,
                  type: 'scatter',
                  name: 'Cumulative Water [STD]',
                  visible: 'legendonly',
                  yaxis: 'y5'
                },
                {
                  x: well.TIME,
                  y: well.QSURFACTANT_WAT,
                  type: 'scatter',
                  name: 'Active component in Water [kg/D]',
                  visible: 'legendonly',
                  yaxis: 'y7'
                },
                {
                  x: well.TIME,
                  y: well.QSURFACTANT_GAS,
                  type: 'scatter',
                  name: 'Active component in Gas [kg/D]',
                  visible: 'legendonly',
                  yaxis: 'y7'
                }
              ],
              layout: {
                width: 1200,
                height: 500,
                title: `Well ${i}`,
                yaxis: {
                  tickformat: 'r',
                  title: 'Pressure [psi]'
                },
                yaxis2: {
                  tickformat: 'e',
                  title: 'Rate [STB/D]',
                  anchor: 'free',
                  overlaying: 'y',
                  side: 'left',
                  position: 0,
                  visible: false
                },
                yaxis3: {
                  tickformat: 'e',
                  title: 'Gas Rate [SCF/D]',
                  anchor: 'x',
                  overlaying: 'y',
                  side: 'right',
                  visible: false
                },
                yaxis4: {
                  tickformat: 'e',
                  title: 'Active Component [kg/D]',
                  anchor: 'free',
                  overlaying: 'y',
                  side: 'right',
                  position: 1.0,
                  visible: false
                },
                yaxis5: {
                  tickformat: 'e',
                  title: 'Cumulative Liquid [STB]',
                  anchor: 'free',
                  overlaying: 'y',
                  side: 'right',
                  position: 0.9,
                  visible: false
                },
                yaxis6: {
                  tickformat: 'e',
                  title: 'Cumulative Gas [SCF]',
                  anchor: 'free',
                  overlaying: 'y',
                  side: 'right',
                  position: 0.8,
                  visible: false
                },
                yaxis7: {
                  tickformat: '.4e',
                  title: 'Rate Active Component [kg/D]',
                  anchor: 'free',
                  overlaying: 'y',
                  side: 'left',
                  position: 0.1,
                  visible: false
                },
                xaxis: {
                  title: 'Day',
                  domain: [0.2, 0.7]
                }
              }
            })
          })
        } else {
          wells.forEach((well, i) => {
            dummy.push({
              data: [
                {
                  x: well.TIME,
                  y: well.BHFP,
                  type: 'scatter',
                  name: 'Bottom Hole Pressure [psi]',
                  yaxis: 'y',
                  visible: true
                },
                {
                  x: well.TIME,
                  y: well.phscrate.OIL,
                  type: 'scatter',
                  name: 'Oil Rate [STB/D]',
                  visible: 'legendonly',
                  yaxis: 'y2'
                },
                {
                  x: well.TIME,
                  y: well.phscrate.GAS,
                  type: 'scatter',
                  name: 'Gas Rate [SCF/D]',
                  visible: 'legendonly',
                  yaxis: 'y3'
                },
                {
                  x: well.TIME,
                  y: well.phscrate.WAT,
                  type: 'scatter',
                  name: 'Water Rate [STD/D]',
                  visible: 'legendonly',
                  yaxis: 'y2'
                },
                {
                  x: well.TIME,
                  y: well.phscac.OIL,
                  type: 'scatter',
                  name: 'Cumulative Oil [STD]',
                  visible: 'legendonly',
                  yaxis: 'y5'
                },
                {
                  x: well.TIME,
                  y: well.phscac.GAS,
                  type: 'scatter',
                  name: 'Cumulative Gas [SCF]',
                  visible: 'legendonly',
                  yaxis: 'y6'
                },
                {
                  x: well.TIME,
                  y: well.phscac.WAT,
                  type: 'scatter',
                  name: 'Cumulative Water [STD]',
                  visible: 'legendonly',
                  yaxis: 'y5'
                },
                {
                  x: well.TIME,
                  y: well.QNANOPARTICLE_WAT,
                  type: 'scatter',
                  name: 'Nanoparticle in Water [kg/D]',
                  visible: 'legendonly',
                  yaxis: 'y7'
                },
                {
                  x: well.TIME,
                  y: well.QNANOPARTICLE_GAS,
                  type: 'scatter',
                  name: 'Nanoparticle in Gas [kg/D]',
                  visible: 'legendonly',
                  yaxis: 'y7'
                }
              ],
              layout: {
                width: 1200,
                height: 500,
                title: `Well ${i}`,
                yaxis: {
                  tickformat: 'r',
                  title: 'Pressure [psi]'
                },
                yaxis2: {
                  tickformat: 'e',
                  title: 'Rate [STB/D]',
                  anchor: 'free',
                  overlaying: 'y',
                  side: 'left',
                  position: 0,
                  visible: false
                },
                yaxis3: {
                  tickformat: 'e',
                  title: 'Gas Rate [SCF/D]',
                  anchor: 'x',
                  overlaying: 'y',
                  side: 'right',
                  visible: false
                },
                yaxis4: {
                  tickformat: 'e',
                  title: 'Nanoparticle [kg/D]',
                  anchor: 'free',
                  overlaying: 'y',
                  side: 'right',
                  position: 1.0,
                  visible: false
                },
                yaxis5: {
                  tickformat: 'e',
                  title: 'Cumulative Liquid [STB]',
                  anchor: 'free',
                  overlaying: 'y',
                  side: 'right',
                  position: 0.9,
                  visible: false
                },
                yaxis6: {
                  tickformat: 'e',
                  title: 'Cumulative Gas [SCF]',
                  anchor: 'free',
                  overlaying: 'y',
                  side: 'right',
                  position: 0.8,
                  visible: false
                },
                yaxis7: {
                  tickformat: '.4e',
                  title: 'Rate Nanoparticle [kg/D]',
                  anchor: 'free',
                  overlaying: 'y',
                  side: 'left',
                  position: 0.1,
                  visible: false
                },
                xaxis: {
                  title: 'Day',
                  domain: [0.2, 0.7]
                }
              }
            })
          })
        }
        return res.json({
          success: true,
          wells: dummy
        })
      }
    })
  }
}

module.exports = simulationController
