const path = require('path')
const chai = require('chai')
const chaiHttp = require('chai-http')
const server = require(path.resolve('./test', '../bin/www2'))
const expect = chai.expect

chai.use(chaiHttp)

let loginInfo = {
  'email': 'test@test.com',
  'password': '1234567890'
}

describe('Simulation Routes', function () {
  describe('Simulation Routes Login, See Simulations, Edit Simulation, Delete Simulation and Logout', function () {
    it('Should return "200" status', function (done) {
      chai.request(server).post('/api/user/login').send(loginInfo).end(function (err, res) {
        expect(err).to.be.null
        expect(res.body.success).to.be.true
        expect(res.body.token).to.be.not.undefined
        expect(res).to.have.status(200)
        let token = res.body.token
        let newSimulationInfo = {
          name: 'testSimulation',
          description: 'This is a simulations description',
          project_id: '5bbf7c980932772b80889c61',
          type: 'Chemical EOR',
          collaborators: [
            {
              user_id: '5bbbccf63da81a40dc32d898',
              permission: Math.random() % 2 === 0 ? 'r' : 'rw'
            },
            {
              user_id: '5bbbccf63da81a40dc32d897',
              permission: Math.random() % 2 === 0 ? 'r' : 'rw'
            }
          ],
          'token': token
        }
        chai.request(server).post('/api/simulation/new').send(newSimulationInfo).end(function (err, res) {
          expect(err).to.be.null
          expect(res.body.success).to.be.true
          expect(res.body.simulations).to.be.a('object')
          let Simulationid = res.body.simulations._id
          expect(res).to.have.status(200)
          chai.request(server).post(`/api/simulation/${Simulationid}`).send({ token: token }).end(function (err, res) {
            expect(err).to.be.null
            expect(res.body.success).to.be.true
            expect(res.body.simulations).to.be.a('object')
            expect(res.body.simulations.name).to.be.equal(newSimulationInfo.name)
            expect(res.body.simulations.description).to.be.equal(newSimulationInfo.description)
            expect(res.body.simulations.type).to.be.equal(newSimulationInfo.type)
            expect(res.body.simulations.project_id).to.be.not.undefined
            expect(res.body.simulations.collaborators).to.be.a('array')
            expect(res).to.have.status(200)
            let editSimulationInfo = {
              name: 'testSimulationEdit',
              description: 'This is a simulations description edited',
              project_id: '5bbf7c980932772b80889c61',
              type: 'Thermal CEOR',
              collaborators: [
                {
                  user_id: '5bbbccf63da81a40dc32d898',
                  permission: Math.random() % 2 === 0 ? 'r' : 'rw'
                },
                {
                  user_id: '5bbbccf63da81a40dc32d897',
                  permission: Math.random() % 2 === 0 ? 'r' : 'rw'
                }
              ],
              'token': token
            }
            chai.request(server).put(`/api/simulation/${Simulationid}`).send(editSimulationInfo).end(function (err, res) {
              expect(err).to.be.null
              expect(res.body.success).to.be.true
              expect(res.body.simulations).to.be.a('object')
              expect(res.body.simulations.name).to.be.equal(editSimulationInfo.name)
              expect(res.body.simulations.description).to.be.equal(editSimulationInfo.description)
              expect(res.body.simulations.type).to.be.equal(editSimulationInfo.type)
              expect(res.body.simulations.project_id).to.be.not.undefined
              expect(res.body.simulations.collaborators).to.be.a('array')
              expect(res).to.have.status(200)
              chai.request(server).delete(`/api/simulation/${Simulationid}`).send({ ...loginInfo, token: token }).end(function (err, res) {
                expect(err).to.be.null
                expect(res.body.success).to.be.true
                expect(res).to.have.status(200)
                chai.request(server).post('/api/user/logout').send({ token: token }).end(function (err, res) {
                  expect(err).to.be.null
                  expect(res.body.success).to.be.true
                  expect(res).to.have.status(200)
                  done()
                })
              })
            })
          })
        })
      })
    })
  })
})
