process.env.NODE_ENV = 'test'

require('./testModels/simulation')
require('./testModels/project')
require('./testModels/user')
require('./testModels/reservoirDescription')
require('./testModels/fluidsDescription')
require('./testModels/rockFluidDescription')
require('./testModels/initialConditionsDescription')
require('./testModels/numericalControlDescription')
require('./testModels/wellsAndTimeDescription')
require('./testModels/settingsDescription')
require('./testModels/component')

require('./testRoutes/user')
require('./testRoutes/component')
require('./testRoutes/project')
require('./testRoutes/simulation')
require('./testRoutes/temporary')
