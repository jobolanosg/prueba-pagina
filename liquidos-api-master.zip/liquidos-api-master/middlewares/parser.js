const bodyParser = require('body-parser')

let parseJson = bodyParser.json()
let parseUrlencoded = bodyParser.urlencoded({ extended: true })

const parser = {
  parseJson: parseJson,
  parseUrlencoded: parseUrlencoded,
  parseBody: [
    parseJson, parseUrlencoded
  ]
}

module.exports = parser
