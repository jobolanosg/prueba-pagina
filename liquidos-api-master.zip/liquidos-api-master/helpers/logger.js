const { createLogger, format, transports } = require('winston')
const config = require('../config')

const PreFormat = format.printf(info => {
  return `${info.timestamp} ${info.level}: ${info.message}`
})

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp({
      format: 'YYYY-MM-DD HH:mm:ss'
    }),
    PreFormat
  ),
  transports: [
    new (transports.Console)(config.LOG.OPTIONS.CONSOLE),
    new (transports.File)(config.LOG.OPTIONS.FILE),
    new (transports.File)(config.LOG.OPTIONS.FILEERRORS)
  ],
  exitOnError: false
})

logger.stream = {
  write: function (message, encoding) {
    message.replace('/n', '')
    logger.info(message)
  }
}

module.exports = logger
