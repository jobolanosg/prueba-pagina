import { NgModule } from '@angular/core';
import { LoginRoutes } from './login.routing';
import { LoginComponent } from './login.component';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';

import { DialogsModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';

import { MatProgressSpinnerModule, MatProgressBarModule } from '@angular/material';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    LoginRoutes,
    MatCardModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    DialogsModule,
    ButtonsModule,
    MatProgressSpinnerModule,
    MatProgressBarModule
  ],
  declarations: [
    LoginComponent
  ]
})

export class LoginModule { }
