import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../service/auth/auth.service';
import { Router, Event, NavigationStart, NavigationEnd } from '@angular/router';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})

export class LoginComponent implements OnInit {
  hidePassword = true;
  loginForm: FormGroup;
  email;
  password;
  public opened = false;
  btnContact = 'mail';
  disabled = false;
  showLoadingIndicator;

  constructor(private Auth: AuthService,
    private router: Router,
    private formBuilder: FormBuilder) {
    this.createForm();

    this.router.events.subscribe((routerEvent: Event) => {

      if (routerEvent instanceof NavigationStart) {
        this.showLoadingIndicator = true;
      }

      if (routerEvent instanceof NavigationEnd) {
        this.showLoadingIndicator = false;
      }
    });
  }

  createForm() {
    this.loginForm = this.formBuilder.group({
      'email': new FormControl(this.email, [Validators.required]),
      'password': new FormControl(this.password, [Validators.required])
    });
  }

  ngOnInit() {
  }

  onClickSubmit() {
    this.Auth.postLogin(this.loginForm.get('email').value, this.loginForm.get('password').value).subscribe(response => {
      if (!response) {
        response = { success: false };
      }
      if (response.success) {
        this.disabled = true;
        this.router.navigate(['/mysimulations']);
      } else {
        this.open();
      }
    }, (err) => {
      this.open();
    });
  }

  public open() {
    this.opened = true;
  }
  public close() {
    this.opened = false;
  }

  public contactHoverOn() {
    this.btnContact = 'drafts';
  }

  public contactHoverOff() {
    this.btnContact = 'mail';
  }


}
