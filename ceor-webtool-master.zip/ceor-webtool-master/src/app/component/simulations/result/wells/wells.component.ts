import { Component, OnInit, DoCheck, Input, ChangeDetectorRef } from '@angular/core';
import * as FusionCharts from 'fusioncharts';

@Component({
  selector: 'app-wells',
  templateUrl: './wells.component.html',
  styleUrls: ['./wells.component.scss']
})
export class WellsComponent {

  constructor(private changeDetectorRefs: ChangeDetectorRef) { }

  @Input() data: any[];
  @Input() layout: any;

  modifyAxes() {
    let activeTraces = this.data.filter(function(trace) {
      return trace.visible === true;
    });
    let activeAxis = [];
    activeTraces.forEach(trace => {
      activeAxis.push(trace.yaxis);
    });
    (activeAxis.includes('y')) ? this.layout.yaxis.visible = true : this.layout.yaxis.visible = false;
    (activeAxis.includes('y2')) ? this.layout.yaxis2.visible = true : this.layout.yaxis2.visible = false;
    (activeAxis.includes('y3')) ? this.layout.yaxis3.visible = true : this.layout.yaxis3.visible = false;
    (activeAxis.includes('y4')) ? this.layout.yaxis4.visible = true : this.layout.yaxis4.visible = false;
    (activeAxis.includes('y5')) ? this.layout.yaxis5.visible = true : this.layout.yaxis5.visible = false;
    (activeAxis.includes('y6')) ? this.layout.yaxis6.visible = true : this.layout.yaxis6.visible = false;
    (activeAxis.includes('y7')) ? this.layout.yaxis7.visible = true : this.layout.yaxis7.visible = false;
    this.changeDetectorRefs.detectChanges();
  }
}
