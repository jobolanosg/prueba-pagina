import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProjectListComponent } from './project-list.component';

import { TreeViewModule } from '@progress/kendo-angular-treeview';

@NgModule({
  imports: [
    CommonModule,
    TreeViewModule
  ],
  declarations: [
    ProjectListComponent
  ],
  exports: [
    ProjectListComponent
  ]
})
export class ProjectListModule { }
