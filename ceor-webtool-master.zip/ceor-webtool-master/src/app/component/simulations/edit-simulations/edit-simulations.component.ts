import { Component, OnInit, Input, DoCheck, ViewChild, ViewContainerRef } from '@angular/core';
import { NotificationService } from '@progress/kendo-angular-notification';
import { DescriptionService } from '../../../service/description/description.service';
import { SimulationsService } from '../../../service/simulations/simulations.service';
import { Store } from '@ngxs/store';
import { UserState } from '../../../store/state/user.state';
import { AddRunningSimulation, RemoveRunningSimulation } from '../../../store/actions/app.actions';

@Component({
  selector: 'app-edit-simulations',
  templateUrl: './edit-simulations.component.html',
  styleUrls: ['./edit-simulations.component.scss']
})
export class EditSimulationsComponent implements OnInit, DoCheck {
  @ViewChild('appendTo', { read: ViewContainerRef, static: true }) public appendTo: ViewContainerRef;
  simulationsData: any = { settingsData: {}, reservoirData: {}, initialConditionsData: {}, numericalSettingsData: {}, rockFluidData: [], wellsScheduleData: {}, fluidsData: {}, componentsData: {} };
  tabName = 'Settings';
  showLoadingIndicator = true;
  constructor(private notificationService: NotificationService, private store: Store, private descriptionService: DescriptionService, private simulationService: SimulationsService) {
    this.temporarilyGet();
  }

  ngOnInit() { }

  ngDoCheck() { }

  seeTabSelected(data) {
    this.tabName = data.tab.textLabel;
  }

  temporarilySave() {
    const simulationsId = this.store.selectSnapshot(UserState.getSimulationsId);
    console.log(simulationsId);
    this.descriptionService.temporalySave(simulationsId, this.simulationsData).subscribe((res) => {
      if (res.success) {
        this.notificate({ text: 'successfully saved', style: 'success', width: 152, height: 70 });
      } else {
        this.notificate({ text: 'Error saving', style: 'error', width: 152, height: 70 });
      }
    });
  }

  temporarilyGet() {
    const simulationsId = this.store.selectSnapshot(UserState.getSimulationsId);
    this.descriptionService.temporalyGet(simulationsId).subscribe((res) => {
      if (res.success) {
        this.notificate({ text: 'Successful', style: 'success', width: 152, height: 70 });
        this.simulationsData = JSON.parse(res.temporary.saved);
      } else {
        this.notificate({ text: 'Error downloading the information', style: 'error', width: 152, height: 70 });
        this.simulationsData = { settingsData: {}, reservoirData: {}, initialConditionsData: {}, numericalSettingsData: {}, rockFluidData: [], wellsScheduleData: {}, fluidsData: {}, componentsData: {} };
      }
      this.showLoadingIndicator = false;
    });
  }

  execute() {
    const body = {
      simulation: {
        id: this.store.selectSnapshot(UserState.getSimulationsId),
        info: this.store.selectSnapshot(UserState.getSimulationsDescription),
        name: this.store.selectSnapshot(UserState.getSimulations),
        type: this.store.selectSnapshot(UserState.getSimulationsType)
      },
      ...this.simulationsData,
      token: this.store.selectSnapshot(UserState.getToken)
    };
    this.simulationService.executeSimulations(body).subscribe((res: any) => {
      if (res.msg === 'Simulation already in queue') {
        this.notificate({ text: 'Simulation already in queue', style: 'error', width: 152, height: 70 });
      } else {
        this.store.dispatch(new AddRunningSimulation([{ simulation_id: this.store.selectSnapshot(UserState.getSimulationsId), name: this.store.selectSnapshot(UserState.getSimulations), status: 'Waiting'}]));
        this.notificate({ text: 'Simulation running', style: 'success', width: 152, height: 70 });
      }
    });
  }

  notificate(information) {
    if (!information) {
      information = {
        text: '',
        style: 'none',
        width: 152,
        height: 50
      };
    }
    this.notificationService.show({
      appendTo: this.appendTo,
      cssClass: 'notification',
      content: information.text,
      animation: { type: 'fade', duration: 400 },
      position: { horizontal: 'left', vertical: 'bottom' },
      type: { style: information.style, icon: true },
      width: information.width,
      height: information.height,
      hideAfter: 6000
    });
  }
}
