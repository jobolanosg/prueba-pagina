import {
  Component,
  OnInit,
  DoCheck,
  Input,
  EventEmitter,
  Output
} from '@angular/core';
import { Store } from '@ngxs/store';
import { UserState } from '../../../../../store/state/user.state';

@Component({
  selector: 'app-fluids-components',
  templateUrl: './fluids-components.component.html',
  styleUrls: ['./fluids-components.component.scss']
})
export class FluidsComponentsComponent implements OnInit, DoCheck {
  constructor(private store: Store) { }

  @Input() settingsConfiguration: any = {};
  @Input() fluidsConfiguration: any[];
  @Input() componentsData: any;
  @Output() componentsDataChange: EventEmitter<any> = new EventEmitter();
  @Input() fluidComponentsData: any[];
  @Output() fluidComponentsDataChange: EventEmitter<any[]> = new EventEmitter();

  fluidData: any[];
  panelOpenState = false;
  equationOfStateItems = ['Peng-Robinson'];
  componentList: any[];
  equationOfState: string;
  isThermal = false;
  settings = {
    rowHeaders: true,
    colHeaders: true,
    minRows: 1,
    minSpareRows: 0,
    startRows: 1,
    autoColumnSize: { syncLimit: '100%', useHeaders: true },
    height: 150,
    width: 750,
    contextMenu: ['row_above', 'row_below', 'remove_row']
  };
  settingsWells = {
    startCols: 0,
    rowHeaders: true,
    colHeaders: true,
    startRows: 0,
    minSpareCols: 0,
    minSpareRows: 0,
    minCols: 0,
    autoColumnSize: { syncLimit: '100%', useHeaders: true },
    height: 150,
    width: 750,
    contextMenu: ['row_above', 'row_below', 'remove_row']
  };
  settingsWater = {
    startCols: 0,
    rowHeaders: true,
    colHeaders: true,
    startRows: 0,
    minSpareCols: 0,
    minSpareRows: 0,
    minCols: 0,
    autoColumnSize: { syncLimit: '100%', useHeaders: true },
    height: 95,
    width: 750,
    contextMenu: ['row_above', 'row_below', 'remove_row']
  };

  // Units of Measurement
  unityPressure = '';
  unityCompressibility = '';
  unityVolumetricFactorOil = '';
  unityViscosity = '';
  unityDensity = '';
  unityTemperature = '';
  unityVolume = '';
  unityMolecular = '';

  ngDoCheck(): void {
    if (this.componentList.length) {
     for (let componentIndex = 0; componentIndex < this.componentList.length; componentIndex++) {
      if (this.componentList[componentIndex] === 'Water') {
        this.componentList.splice(componentIndex, 1);
      }
     }
    }
    for (let fluidIndex = 0; fluidIndex < this.fluidData.length; fluidIndex++) {
      this.fluidData[fluidIndex].dataComponentsProperties.fill(this.getPropertiesTable(fluidIndex), this.componentList.length);
      for (let componentIndex = 0; componentIndex < this.componentList.length; componentIndex++) {
        if (this.fluidData[fluidIndex].dataComponentsProperties[componentIndex]) {
          this.fluidData[fluidIndex].dataComponentsProperties[componentIndex].component = this.componentList[componentIndex];
        } else {
          this.fluidData[fluidIndex].dataComponentsProperties[componentIndex] = {};
          this.fluidData[fluidIndex].dataComponentsProperties[componentIndex].component = this.componentList[componentIndex];
        }
      }

      if (this.fluidData[fluidIndex].binaryInteractionCoefficients.length <= this.componentList.length) {
        for (let componentIndex = 0; componentIndex < this.componentList.length; componentIndex++) {
          if (this.fluidData[fluidIndex].binaryInteractionCoefficients[componentIndex]) {
            this.fluidData[fluidIndex].binaryInteractionCoefficients[componentIndex] = this.fluidComponentsData[fluidIndex].binaryInteractionCoefficients[componentIndex];
          } else {
            this.fluidData[fluidIndex].binaryInteractionCoefficients[componentIndex] = {};
          }
        }
      } else {
        this.fluidData[fluidIndex].binaryInteractionCoefficients.length = this.componentList.length;
      }
    }
  }

  ngOnInit() {
    this.isThermal = this.store.selectSnapshot(UserState.getSimulationsType) === 'Thermal CEOR';
    if (this.componentsData.equationOfState) {
      this.equationOfState = this.componentsData.equationOfState;
    }

    if (
      this.componentsData.componentList && this.componentsData.componentList.length > 1) {
      this.componentList = this.componentsData.componentList;
    } else {
      this.componentList = [];
    }
    if (this.fluidComponentsData && this.fluidComponentsData.length) {
      this.fluidData = this.fluidComponentsData;
    } else {
      if (this.settingsConfiguration.flowUnitsSelect) {
        this.fluidData = Array(this.settingsConfiguration.flowUnitsSelect.length);
        for (let i = 0; i < this.settingsConfiguration.flowUnitsSelect.length; i++) {
          const currentProperties = [];
          currentProperties.push(this.getPropertiesTable(i));
          this.fluidData[i] = {
            id: i,
            dataComponentsProperties: currentProperties,
            binaryInteractionCoefficients: [{}],
            includeWaterBinaryInteractionCoefficientsChecked: false,
            includeWaterBinaryInteractionCoefficients: [{}]
          };
        }
      }
    }
    this.unitsMeasurement();
  }

  getPropertiesTable(index: number): any {
    const tableObject = {};
    Object.defineProperty(tableObject, `component`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `accentricFactor${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `criticalPressure${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `criticalTemperature${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `criticalVolume${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `molecularWeight${index}`, {
      value: null,
      writable: true,
      enumerable: true,
      configurable: true
    });

    if (this.isThermal) {
      Object.defineProperty(tableObject, `boilingPoint${index}`, {
        value: null,
        writable: true,
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(tableObject, `cP1${index}`, {
        value: null,
        writable: true,
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(tableObject, `cP2${index}`, {
        value: null,
        writable: true,
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(tableObject, `cP3${index}`, {
        value: null,
        writable: true,
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(tableObject, `cP4${index}`, {
        value: null,
        writable: true,
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(tableObject, `cP5${index}`, {
        value: null,
        writable: true,
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(tableObject, `zRA${index}`, {
        value: null,
        writable: true,
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(tableObject, `s0${index}`, {
        value: null,
        writable: true,
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(tableObject, `s1${index}`, {
        value: null,
        writable: true,
        enumerable: true,
        configurable: true
      });
    }
    return tableObject;
  }

  trackFluidBy(index: number, fluid: any): number {
    return fluid.id;
  }

  valueChange(data) {
    this.componentsData.equationOfState = this.equationOfState;
    this.componentsData.componentList = this.componentList;
    this.fluidComponentsData = this.fluidData;
    this.fluidComponentsDataChange.emit(this.fluidComponentsData);
    this.componentsDataChange.emit(this.componentsData);
  }

  unitsMeasurement(): void {
    if (
      this.settingsConfiguration.selectedWorkUnits === 'Field' ||
      this.settingsConfiguration.selectedWorkUnits === 'Lab'
    ) {
      this.unityPressure = 'psi';
      this.unityVolumetricFactorOil = 'RB/STB';
      this.unityCompressibility = '1/psi';
      this.unityViscosity = 'cp/psi';

      if (this.settingsConfiguration.selectedWorkUnits === 'Field') {
        this.unityDensity = 'lbm/ft³';
        this.unityTemperature = '°R';
        this.unityVolume = 'ft³/lbm';
        this.unityMolecular = 'lbm/lbmol';
      } else if (this.settingsConfiguration.selectedWorkUnits === 'Lab') {
        this.unityDensity = 'g/cm³';
        this.unityTemperature = 'K';
        this.unityVolume = 'cm³/g';
        this.unityMolecular = 'g/mol';
      }
    } else if (this.settingsConfiguration.selectedWorkUnits === 'SI') {
      this.unityDensity = 'kg/m³';
      this.unityPressure = 'kpa';
      this.unityVolumetricFactorOil = 'm³/m³';
      this.unityCompressibility = '1/kpa';
      this.unityViscosity = 'cp/kpa';
      this.unityTemperature = 'K';
      this.unityVolume = 'm³/kg';
      this.unityMolecular = 'kg/mol';
    }
  }
}
