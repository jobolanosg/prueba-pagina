import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { PropertiesComponent } from './properties.component';
import { PanelBarModule } from '@progress/kendo-angular-layout';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatExpansionModule } from '@angular/material/expansion';

import { HotTableModule } from '@handsontable/angular';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    HotTableModule,
    PanelBarModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatExpansionModule,
    MatInputModule
  ],
  declarations: [
    PropertiesComponent
  ],
  exports: [
    PropertiesComponent
  ]
})
export class PropertiesModule { }
