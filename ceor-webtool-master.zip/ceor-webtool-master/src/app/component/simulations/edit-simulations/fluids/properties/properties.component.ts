import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-properties',
  templateUrl: './properties.component.html',
  styleUrls: ['./properties.component.scss']
})
export class PropertiesComponent implements OnInit {
  @Input() settingsConfiguration: any;
  @Input() propertiesData: any;
  @Output() propertiesDataChange: EventEmitter<any> = new EventEmitter();

  panelOpenState = false;

  // Units of Measurement
  unityDensity = '';
  unityPressure = '';
  unityVolumetricFactorOil = '';
  unityVolumetricFactorGas = '';
  unityVolatilizedOil = '';
  unityCompressibility = '';
  unityViscosity = '';

  settings = {
    data: [],
    rowHeaders: true,
    colHeaders: true,
    autoColumnSize: { syncLimit: '50%', useHeaders: true },
    height: 200,
    width: 900,
    minSpareRows: 1,
    contextMenu: ['row_above', 'row_below', 'remove_row'],
  };

  propertiesDataTable: any[];

  constructor() { }

  ngOnInit() {
    this.unitsMeasurement();
    if (this.propertiesData.length < 1) {
      if (this.settingsConfiguration.flowUnitsSelect && this.settingsConfiguration.flowUnitsSelect.length) {
        this.propertiesDataTable = Array(this.settingsConfiguration.flowUnitsSelect.length);
        for (let i = 0; i < this.settingsConfiguration.flowUnitsSelect.length; i++) {
          const currentProperties = {
            densityStandartConditions: {
              Oil: '',
              Gas: '',
              Water: ''
            },
            waterProperties: {
              referencePressure: '',
              volumetricFactor: '',
              viscosity: '',
              compressibility: '',
              dependenceOfViscosityWithPressure: ''
            },
            PVTProperties: []
          };
          currentProperties.PVTProperties.push(this.getPVTTable(i));
          this.propertiesDataTable[i] = currentProperties;
        }
      }
    } else {
      this.propertiesDataTable = this.propertiesData;
    }
  }

  valueChange(data) {
    this.propertiesData = this.propertiesDataTable;
    this.propertiesDataChange.emit(this.propertiesData);
  }

  getPVTTable(index: number): any {
    const tableObject = {};
    Object.defineProperty(tableObject, `pressure${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `oilVolumetricFactor${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `gasVolumetricFactor${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `oilViscosity${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `gasViscosity${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `solutionGas${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `volatilizedOil${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    return tableObject;
  }

  unitsMeasurement(): void {
    if (this.settingsConfiguration.selectedWorkUnits === 'Field' || this.settingsConfiguration.selectedWorkUnits === 'Lab') {
      this.unityPressure = 'psi';
      this.unityVolumetricFactorOil = 'RB/STB';
      this.unityVolumetricFactorGas = 'MSCF/STB';
      this.unityVolatilizedOil = 'RB/MSCF';
      this.unityCompressibility = '1/psi';
      this.unityViscosity = 'cp/psi';

      if (this.settingsConfiguration.selectedWorkUnits === 'Field') {
        this.unityDensity = 'lbm/ft³';
      } else if (this.settingsConfiguration.selectedWorkUnits === 'Lab') {
        this.unityDensity = 'g/cm³';
      }
    } else if (this.settingsConfiguration.selectedWorkUnits === 'SI') {
      this.unityDensity = 'kg/m³';
      this.unityPressure = 'kpa';
      this.unityVolumetricFactorOil = 'm³/m³';
      this.unityVolumetricFactorGas = 'm³/m³';
      this.unityVolatilizedOil = 'm³/m³';
      this.unityCompressibility = '1/kpa';
      this.unityViscosity = 'cp/kpa';
    }
  }

}
