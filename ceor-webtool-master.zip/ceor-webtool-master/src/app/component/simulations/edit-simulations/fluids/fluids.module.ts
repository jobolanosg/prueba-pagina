import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { FluidsComponent } from './fluids.component';
import { FluidsComponentsModule } from './fluids-components/fluids-components.module';
import { PropertiesModule } from './properties/properties.module';

import { DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { TabStripModule } from '@progress/kendo-angular-layout';
import { MatExpansionModule } from '@angular/material/expansion';
import { ViscosityComponent } from './viscosity/viscosity.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    FluidsComponentsModule,
    PropertiesModule,
    DropDownListModule,
    MatExpansionModule,
    TabStripModule
  ],
  declarations: [
    FluidsComponent,
    ViscosityComponent,
  ],
  exports: [
    FluidsComponent
  ]
})
export class FluidsModule { }
