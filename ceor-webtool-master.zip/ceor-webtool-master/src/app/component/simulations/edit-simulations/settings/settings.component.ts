import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { UserState } from '../../../../store/state/user.state';
import { Store } from '@ngxs/store';
import { ComponentService } from '../../../../service/component/component.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})

export class SettingsComponent implements OnInit {
  @Input() settingsData: any;
  @Output() settingsDataChange: EventEmitter<string[]> = new EventEmitter();
  optionSimulationsType = 'Field';
  workUnitsItems = ['Field'];
  fluidsModelItems = ['Extended Black Oil', 'Compositional'];
  selectedWorkUnits;
  selectedFluidsModel = 'Compositional';
  componentsItems;
  componentValue;
  flowUnitsSelected: Array<string> = [];
  nanoparticleSelect = false;
  surfactantSelect = true;
  polymerSelect = false;
  constructor(private componentService: ComponentService, private store: Store) { }

  ngOnInit() {
    this.optionSimulationsType = this.store.selectSnapshot(UserState.getSimulationsType);
    this.componentService.getComponents().subscribe(response => {
      this.componentsItems = response.components;
    });
    this.selectedWorkUnits = 'Field';
    this.selectedFluidsModel = this.settingsData.selectedFluidsModel;
    this.nanoparticleSelect = this.settingsData.nanoparticleSelect;
    this.surfactantSelect = this.settingsData.surfactantSelect;
    this.polymerSelect = this.settingsData.polymerSelect;
    this.componentValue = this.settingsData.componentSelect;
    this.flowUnitsSelected = this.settingsData.flowUnitsSelect;
  }
  chemicalChecked(chemical) {
    if (chemical === 'surfactant') {
      this.surfactantSelect = true;
      this.nanoparticleSelect = false;
    } else {
      this.surfactantSelect = false;
      this.nanoparticleSelect = true;
    }
    this.selectionChange('chemical');
  }
  selectionChange(data) {
    this.settingsData.selectedWorkUnits = this.selectedWorkUnits;
    this.settingsData.selectedFluidsModel = 'Compositional';
    this.settingsData.nanoparticleSelect = this.nanoparticleSelect;
    this.settingsData.surfactantSelect = this.surfactantSelect;
    this.settingsData.polymerSelect = this.polymerSelect;
    this.settingsData.componentSelect = this.componentValue;
    this.settingsData.flowUnitsSelect = this.flowUnitsSelected;
    this.settingsDataChange.emit(this.settingsData);
  }
  surfactantSelectChange(event) {
    this.surfactantSelect = event.checked;
    this.selectionChange(event);
  }
  nanoparticleSelectChange(event) {
    this.nanoparticleSelect = event.checked;
    this.selectionChange(event);
  }
  polymerSelectChange(event) {
    this.polymerSelect = event.checked;
    this.selectionChange(event);
  }
}
