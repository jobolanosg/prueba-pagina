import { Routes, RouterModule } from '@angular/router';

import { EditSimulationsComponent } from './edit-simulations.component';
import { AuthGuard } from '../../../guards/auth.guard';

const editSimulationsRouter: Routes = [
  {
    path: '',
    canActivate: [AuthGuard],
    component: EditSimulationsComponent
  }
];

export const EditSimulationsRouter = RouterModule.forChild(editSimulationsRouter);
