import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PerforationsTableComponent } from './perforations-table.component';

describe('PerforationsTableComponent', () => {
  let component: PerforationsTableComponent;
  let fixture: ComponentFixture<PerforationsTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PerforationsTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PerforationsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
