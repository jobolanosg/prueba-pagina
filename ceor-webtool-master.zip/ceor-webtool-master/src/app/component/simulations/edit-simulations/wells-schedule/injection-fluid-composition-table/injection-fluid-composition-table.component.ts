import { Component, OnInit, Input, OnDestroy, Output, EventEmitter, DoCheck } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-injection-fluid-composition-table',
  templateUrl: './injection-fluid-composition-table.component.html',
  styleUrls: ['./injection-fluid-composition-table.component.scss']
})

export class InjectionFluidCompositionTableComponent implements OnInit, OnDestroy, DoCheck {

  @Input() settingsConfiguration: any;
  @Input() wellsScheduleData: any;
  @Input() fluidsConfiguration: any;
  @Output() wellsScheduleDataChange: EventEmitter<any> = new EventEmitter();
  @Input() deleteWellEvent: Observable<number>;
  @Input() addWellEvent: Observable<number>;

  typeSelectedSetted;
  selectDate = [];
  private deleteWellSubscription: any;
  private addWellSubscription: any;
  injections: any[];
  componentList: any[] = [];
  settingsWells = {
    rowHeaders: true,
    colHeaders: true,
    minSpareRows: 1,
    autoWrapRow: false,
    autoWrapCol: false,
    startRows: 1,
    contextMenu: ['row_above', 'row_below', 'remove_row']
  };

  constructor() { }

  ngOnInit() {
    if (this.fluidsConfiguration.components && this.fluidsConfiguration.components.componentList.length > 0) {
      this.componentList = this.fluidsConfiguration.components.componentList;
      if (this.componentList.indexOf('Water') === -1) {
        this.componentList.push('Water');
      }
    } else {
      this.componentList = ['Water'];
    }

    if (this.wellsScheduleData.scheduleDates && this.wellsScheduleData.scheduleDates.length > 0) {
      this.selectDate = this.wellsScheduleData.scheduleDates;
    }

    if (this.wellsScheduleData && this.wellsScheduleData.injections && this.wellsScheduleData.injections.length > 0) {
      this.injections = this.wellsScheduleData.injections;
    } else {
      if (this.wellsScheduleData.wells && this.wellsScheduleData.wells.length) {
        const injectionFiltered = this.wellsScheduleData.wells.filter((current) => {
          return current.type === 'Injector';
        });
        const injectionsLength = injectionFiltered.length;
        this.injections = Array(injectionsLength);
        for (let i = 0; i < injectionFiltered.length; i++) {
          const currentProperties = {
            name: injectionFiltered[i].name,
            id: i,
            tableData: []
          };
          currentProperties.tableData.push(this.tableObject(i));
          this.injections[i] = currentProperties;
        }
      }
    }

    this.deleteWellSubscription = this.deleteWellEvent.subscribe((index) => {
      if (this.wellsScheduleData.wells[index].type === 'Injector') {
        this.injections.splice(index, 1);
      }
    });

    this.addWellSubscription = this.addWellEvent.subscribe((index) => {
      if (this.wellsScheduleData.wells[index].type === 'Injector') {
        this.injections.push({ name: this.wellsScheduleData.wells[index].name, id: index, tableData: Array(1).fill(this.tableObject(index)) });
      }
    });
  }

  valueChange(data) {
    this.wellsScheduleData.injections = this.injections;
    this.wellsScheduleDataChange.emit(this.wellsScheduleData);
  }

  ngDoCheck() {
    const wellsNames: string[] = this.wellsScheduleData.wells.map(current => current.name);
    const injectionsNames: string[] = this.injections.map(current => current.name);
    const injectionsIndex: number[] = [];
    const injectionsDates: Array<string[]> = [];
    for (let i = 0; i < injectionsNames.length; i++) {
      injectionsIndex[i] = wellsNames.indexOf(injectionsNames[i]);
    }
    for (let i = 0; i < injectionsIndex.length; i++) {
      injectionsDates[i] = this.wellsScheduleData.scheduleDates[injectionsIndex[i]];
    }
    this.selectDate = injectionsDates;
  }

  ngOnDestroy() {
    this.deleteWellSubscription.unsubscribe();
    this.addWellSubscription.unsubscribe();
    this.componentList.pop();
  }

  tableObject(index: number): any {
    const tableObject = {};
    Object.defineProperty(tableObject, `datePerforations${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    for (let i = 0; i < this.componentList.length; i++) {
      Object.defineProperty(tableObject, `component${index}-${i}`, {
        value: '',
        writable: true,
        enumerable: true,
        configurable: true
      });
    }

    return tableObject;
  }

}
