import { Component, OnInit, Input, OnDestroy, Output, EventEmitter, DoCheck } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngxs/store';
import { UserState } from '../../../../../store/state/user.state';

@Component({
  selector: 'app-schedule-table',
  templateUrl: './schedule-table.component.html',
  styleUrls: ['./schedule-table.component.scss']
})
export class ScheduleTableComponent implements OnInit, OnDestroy, DoCheck {

  @Input() wellsScheduleData: any;
  @Output() wellsScheduleDataChange: EventEmitter<any> = new EventEmitter();

  @Input() deleteWellEvent: Observable<number>;
  @Input() addWellEvent: Observable<number>;

  selectScheduleType = ['Constant', 'Interpolated'];
  private deleteWellSubscription: any;
  private addWellSubscription: any;
  selectInject = ['Gas', 'Oil', 'Water'];
  selectData;
  selectConstraintType = ['Flow Rate at Standart Conditions', 'Bottom Hole Pressure', 'Shut in'];
  scheduleDates: Array<string[]> = [];
  selectDate = [];
  typeSelectedSetted;
  isThermal = false;
  wellsSchedule: any[];
  settings = {
    rowHeaders: true,
    colHeaders: true,
    minSpareRows: 1,
    autoWrapRow: false,
    autoWrapCol: false,
    startRows: 1,
    contextMenu: ['row_above', 'row_below', 'remove_row'],
  };

  constructor(private store: Store) { }

  ngOnInit() {
    this.isThermal = this.store.selectSnapshot(UserState.getSimulationsType) === 'Thermal CEOR';
    if (this.wellsScheduleData.simulationDates && this.wellsScheduleData.simulationDates.length > 0) {
      this.selectDate = this.wellsScheduleData.simulationDates.map((current) => {
        return `${new Date(current.date).getDate()}/${new Date(current.date).getMonth() + 1}/${new Date(current.date).getFullYear()} (${current.days})`;
      });
    }
    if (this.wellsScheduleData && this.wellsScheduleData.schedule && this.wellsScheduleData.schedule.length > 0 && this.wellsScheduleData.schedule.length === this.wellsScheduleData.wells.length) {
      this.wellsSchedule = this.wellsScheduleData.schedule;
    } else {
      if (this.wellsScheduleData.wells && this.wellsScheduleData.wells.length) {
        this.wellsSchedule = Array(this.wellsScheduleData.wells.length);
        for (let i = 0; i < this.wellsScheduleData.wells.length; i++) {
          const currentProperties = {
            name: this.wellsScheduleData.wells[i].name,
            id: i,
            tableData: []
          };
          currentProperties.tableData.push(this.tableObject(i));
          this.wellsSchedule[i] = currentProperties;
        }
      }
    }

    this.deleteWellSubscription = this.deleteWellEvent.subscribe((index) => {
      this.wellsSchedule.splice(index, 1);
    });

    this.addWellSubscription = this.addWellEvent.subscribe((index) => {
      this.wellsSchedule.push({ name: this.wellsScheduleData.wells[index].name, id: index, tableData: Array(1).fill(this.tableObject(index)) });
    });
  }

  ngOnDestroy() {
    this.deleteWellSubscription.unsubscribe();
    this.addWellSubscription.unsubscribe();
  }

  ngDoCheck() {
    for (let wellsScheduleIndex = 0; wellsScheduleIndex < this.wellsSchedule.length; wellsScheduleIndex++) {
      this.scheduleDates[wellsScheduleIndex] = this.wellsSchedule[wellsScheduleIndex].tableData.map((current, index) => current[`date${wellsScheduleIndex}`]).filter(Boolean);
    }
    this.valueChange('dates');
    for (let wellNameIndex = 0; wellNameIndex < this.wellsScheduleData.wells.length; wellNameIndex++) {
      this.wellsSchedule[wellNameIndex].name = this.wellsScheduleData.wells[wellNameIndex].name;
    }

  }

  valueChange(data) {
    this.wellsScheduleData.schedule = this.wellsSchedule;
    this.wellsScheduleData.scheduleDates = this.scheduleDates;
    this.wellsScheduleDataChange.emit(this.wellsScheduleData);
  }

  tableObject(index: number): any {
    const tableObject = {};
    Object.defineProperty(tableObject, `date${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `referenceFluid${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `constraintType${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `constraintValue${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `scheduleType${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `skin${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(tableObject, `numberOfPerforations${index}`, {
      value: '',
      writable: true,
      enumerable: true,
      configurable: true
    });
    if (this.isThermal) {
      Object.defineProperty(tableObject, `quality${index}`, {
        value: '',
        writable: true,
        enumerable: true,
        configurable: true
      });
      Object.defineProperty(tableObject, `temperature${index}`, {
        value: '',
        writable: true,
        enumerable: true,
        configurable: true
      });
    }
    return tableObject;
  }

}
