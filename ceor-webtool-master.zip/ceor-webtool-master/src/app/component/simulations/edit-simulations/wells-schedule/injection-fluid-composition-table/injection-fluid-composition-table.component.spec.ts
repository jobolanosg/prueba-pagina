import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InjectionFluidCompositionTableComponent } from './injection-fluid-composition-table.component';

describe('InjectionFluidCompositionTableComponent', () => {
  let component: InjectionFluidCompositionTableComponent;
  let fixture: ComponentFixture<InjectionFluidCompositionTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InjectionFluidCompositionTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InjectionFluidCompositionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
