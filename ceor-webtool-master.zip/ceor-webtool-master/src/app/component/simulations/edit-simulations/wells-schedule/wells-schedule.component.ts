import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Component({
  selector: 'app-wells-schedule',
  templateUrl: './wells-schedule.component.html',
  styleUrls: ['./wells-schedule.component.scss']
})

export class WellsScheduleComponent implements OnInit {

  @Input() settingsConfiguration: any;
  @Input() fluidsConfiguration: any;
  @Input() wellsScheduleData: any;
  @Output() wellsScheduleDataChange: EventEmitter<any> = new EventEmitter();

  constructor() { }

  wellsCount: any[];
  namePreEdit = '';
  type = ['Producer', 'Injector'];
  typeSelectedSetted: string;
  unityMeasure = '';
  deleteWell: Subject<number> = new Subject();
  addWell: Subject<number> = new Subject();

  ngOnInit() {
    this.typeSelected();
    this.unitsMeasurement();
    if (this.wellsScheduleData.wells && this.wellsScheduleData.wells.length) {
      this.wellsCount = this.wellsScheduleData.wells;
    } else {
      this.wellsCount = [{
        name: '',
        radius: '',
        type: ''
      }];
    }
  }

  valueChange(data) {
    this.wellsScheduleData.wells = this.wellsCount;
    this.wellsScheduleDataChange.emit(this.wellsScheduleData);
  }

  newWell() {
    this.wellsCount.push({
      name: '',
      radius: '',
      type: ''
    });
    this.valueChange('add');
    this.emitAddWellToChild(this.wellsCount.length - 1);
  }

  editName(event: { target: { value: string; }; }, wellIndex: number) {
    if (event.target.value !== this.namePreEdit) {
      // const wellIndex = this.wellsScheduleData.wells.findIndex((element) => element.name === this.namePreEdit);
      // if (typeof wellIndex !== 'undefined') {
      this.wellsScheduleData.wells[wellIndex].name = event.target.value;
      this.wellsCount[wellIndex].name = event.target.value;
      // }
    }
  }

  setNamePreEdit(event: { target: { value: string; }; }) {
    this.namePreEdit = event.target.value;
  }

  emitDeleteWellToChild(index: number) {
    this.deleteWell.next(index);
  }

  emitAddWellToChild(index: number) {
    this.addWell.next(index);
  }

  removeWell(index: number) {
    this.wellsCount.splice(index, 1);
    this.valueChange('remove');
    this.emitDeleteWellToChild(index);
  }

  typeSelected() {
    if (this.settingsConfiguration.selectedFluidsModel === 'Compositional') {
      this.typeSelectedSetted = 'DirectCompositional';
    }
  }

  unitsMeasurement(): void {
    if (this.settingsConfiguration.selectedWorkUnits === 'Field') {
      this.unityMeasure = 'ft';
    } else if (this.settingsConfiguration.selectedWorkUnits === 'SI') {
      this.unityMeasure = 'm';
    } else if (this.settingsConfiguration.selectedWorkUnits === 'Lab') {
      this.unityMeasure = 'cm';
    }
  }

}
