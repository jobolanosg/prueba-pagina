import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SimulationsDatesComponent } from './simulations-dates.component';

describe('SimulationsDatesComponent', () => {
  let component: SimulationsDatesComponent;
  let fixture: ComponentFixture<SimulationsDatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SimulationsDatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SimulationsDatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
