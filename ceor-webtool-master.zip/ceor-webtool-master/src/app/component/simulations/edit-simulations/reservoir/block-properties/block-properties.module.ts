import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BlockPropertiesComponent } from './block-properties.component';

import { DropDownListModule } from '@progress/kendo-angular-dropdowns';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatExpansionModule } from '@angular/material/expansion';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DropDownListModule,
    MatFormFieldModule,
    MatInputModule,
    MatExpansionModule
  ],
  declarations: [
    BlockPropertiesComponent
  ],
  exports: [
    BlockPropertiesComponent
  ]
})
export class BlockPropertiesModule { }
