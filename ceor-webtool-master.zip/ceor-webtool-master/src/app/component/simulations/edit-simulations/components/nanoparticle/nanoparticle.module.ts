import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NanoparticleComponent } from './nanoparticle.component';

import { HotTableModule } from '@handsontable/angular';
import { PanelBarModule } from '@progress/kendo-angular-layout';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatExpansionModule } from '@angular/material/expansion';
import { DropDownListModule, MultiSelectModule } from '@progress/kendo-angular-dropdowns';
import { TabStripModule } from '@progress/kendo-angular-layout';
import { ButtonsModule, ButtonGroupModule } from '@progress/kendo-angular-buttons';
import { MatTabsModule } from '@angular/material/tabs';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { TextBoxModule } from '@progress/kendo-angular-inputs';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HotTableModule,
    PanelBarModule,
    MatFormFieldModule,
    MatExpansionModule,
    DropDownListModule,
    MultiSelectModule,
    TabStripModule,
    ButtonsModule,
    ButtonGroupModule,
    MatInputModule,
    WindowModule,
    TextBoxModule,
    MatTabsModule
  ],
  declarations: [
    NanoparticleComponent
  ],
  exports: [
    NanoparticleComponent
  ]
})
export class NanoparticleModule { }
