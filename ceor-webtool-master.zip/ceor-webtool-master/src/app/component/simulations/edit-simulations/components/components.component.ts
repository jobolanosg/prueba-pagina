import { Component, OnInit, Input, Output, EventEmitter, DoCheck } from '@angular/core';

@Component({
  selector: 'app-components',
  templateUrl: './components.component.html',
  styleUrls: ['./components.component.scss']
})
export class ComponentsComponent implements OnInit, DoCheck {

  @Input() settingsConfiguration: any;
  @Input() wellsScheduleConfiguration: any;
  @Input() fluidsConfiguration: any;
  @Input() componentsData: any;
  @Output() componentsDataChange: EventEmitter<any> = new EventEmitter();

  workUnitsType;
  disabled = true;
  constructor() { }

  settings = {
    rowHeaders: true,
    colHeaders: true,
    minRows: 1,
    minSpareRows: 1,
    startRows: 1,
    autoColumnSize: { syncLimit: '100%', useHeaders: true },
    height: 200,
    width: 740,
    contextMenu: ['row_above', 'row_below', 'remove_row'],
  };

  ngOnInit() { }

  ngDoCheck() {
    if (this.settingsConfiguration.selectedWorkUnits) {
      this.disabled = false;
    }
  }

}
