import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GasOilRelativePermeabilityTableComponent } from './gas-oil-relative-permeability-table.component';

describe('GasOilRelativePermeabilityTableComponent', () => {
  let component: GasOilRelativePermeabilityTableComponent;
  let fixture: ComponentFixture<GasOilRelativePermeabilityTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GasOilRelativePermeabilityTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GasOilRelativePermeabilityTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
