import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import * as Handsontable from 'handsontable';

@Component({
  selector: 'app-gas-oil-relative-permeability-table',
  templateUrl: './gas-oil-relative-permeability-table.component.html',
  styleUrls: ['./gas-oil-relative-permeability-table.component.scss']
})
export class GasOilRelativePermeabilityTableComponent implements OnInit {

  constructor() { }

  @Input() settingsConfiguration: any;
  @Input() hotId: string;
  @Input() tableData: any[];
  @Output() tableDataChange: EventEmitter<any[]> = new EventEmitter();

  id: string;
  dataset: any[];
  settings: Handsontable.GridSettings = {
    minRows: 1,
    minSpareRows: 1,
    startRows: 0,
    startCols: 5,
    colHeaders: true,
    debug: true,
    height: 150,
    contextMenu: ['row_above', 'row_below', 'remove_row']
  };
  unityPressure = '';

  ngOnInit() {
    this.id = this.hotId;
    this.dataset = this.tableData;
    this.unitsMeasurement();
  }

  sendData() {
    this.tableData = this.dataset;
    this.tableDataChange.emit(this.tableData);
  }

 unitsMeasurement(): void {
    if (this.settingsConfiguration.selectedWorkUnits === 'Field') {
      this.unityPressure = 'psi';
    } else if (this.settingsConfiguration.selectedWorkUnits === 'SI') {
      this.unityPressure = 'kpa';
    } else if (this.settingsConfiguration.selectedWorkUnits === 'Lab') {
      this.unityPressure = 'psi';
    }
  }

}
