import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { RockFluidComponent } from './rock-fluid.component';

import { HotTableModule } from '@handsontable/angular';

import { MatExpansionModule } from '@angular/material/expansion';
import { GasOilRelativePermeabilityTableComponent } from './gas-oil-relative-permeability-table/gas-oil-relative-permeability-table.component';
import { OilWaterRelativePermeabilityTableComponent } from './oil-water-relative-permeability-table/oil-water-relative-permeability-table.component';
import { PanelBarModule } from '@progress/kendo-angular-layout';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HotTableModule,
    MatExpansionModule,
    PanelBarModule
  ],
  declarations: [
    RockFluidComponent,
    GasOilRelativePermeabilityTableComponent,
    OilWaterRelativePermeabilityTableComponent
  ],
  exports: [
    RockFluidComponent
  ]
})
export class RockFluidModule { }
