import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { InitialConditionsComponent } from './initial-conditions.component';

import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { TextBoxModule } from '@progress/kendo-angular-inputs';
import { RippleModule } from '@progress/kendo-angular-ripple';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatExpansionModule } from '@angular/material/expansion';

import { HotTableModule } from '@handsontable/angular';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DropDownsModule,
    TextBoxModule,
    RippleModule,
    MatFormFieldModule,
    MatExpansionModule,
    MatInputModule,
    HotTableModule
  ],
  declarations: [
    InitialConditionsComponent
  ],
  exports: [
    InitialConditionsComponent
  ]
})
export class InitialConditionsModule { }
