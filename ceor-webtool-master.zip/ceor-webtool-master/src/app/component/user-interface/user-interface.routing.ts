import { Routes, RouterModule } from '@angular/router';

import { UserInterfaceComponent } from './user-interface.component';
import { AuthGuard } from '../../guards/auth.guard';

const UserInterface: Routes = [
  {
    path: '',
    pathMatch: 'full',
    canActivate: [AuthGuard],
    component: UserInterfaceComponent
  }
];

export const UserInterfaceRoutes = RouterModule.forChild(UserInterface);
