import { Component, OnInit } from '@angular/core';
import { UserState } from 'src/app/store/state/user.state';
import { Store, Select } from '@ngxs/store';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-user-interface',
  templateUrl: './user-interface.component.html',
  styleUrls: ['./user-interface.component.scss']
})
export class UserInterfaceComponent implements OnInit {

  username = '';
  email = '';
  role = '';
  @Select(UserState.getUser) user$: Observable<any>;

  constructor() {
    this.user$.subscribe(user => {
      this.username = user.username;
      this.email = user.email;
      this.role = user.role;
    });
  }

  ngOnInit() { }

}
