import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simulation-detail',
  templateUrl: './simulation-detail.component.html',
  styleUrls: ['./simulation-detail.component.scss']
})
export class SimulationDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
