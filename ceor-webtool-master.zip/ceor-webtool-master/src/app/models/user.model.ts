import { Token } from './submodels/token.model';
export interface User {
  _id?: string;
  name?: string;
  lastname?: string;
  password?: string;
  role?: string;
  email?: string;
  token?: Token['token'];
  position: any;
}
