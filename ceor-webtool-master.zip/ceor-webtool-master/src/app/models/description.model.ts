import { ReservoirDescription } from './submodels/reservoir-description.model';
import { FluidsDescription } from './submodels/fluids-description.model';
import { RockFluidDescription } from './submodels/rock-fluid-description.model';
import { InitialConditionsDescription } from './submodels/initial-conditions-description.model';
import { NumericalControlDescription } from './submodels/numerical-control-description.model';
import { WellsAndTimeDescription } from './submodels/wells-and-time-description.model';
import { SettingsDescription } from './submodels/settings-description.model';
import { Token } from './submodels/token.model';


export interface Description {
  reservoirDescription?: ReservoirDescription;
  fluidsDescription?: FluidsDescription;
  rockFluidDescription?: RockFluidDescription;
  initialConditionsDescription?: InitialConditionsDescription;
  numericalControlDescription?: NumericalControlDescription;
  wellsAndTimeDescription?: WellsAndTimeDescription;
  settingsDescription?: SettingsDescription;
  token?: Token['token'];
}
