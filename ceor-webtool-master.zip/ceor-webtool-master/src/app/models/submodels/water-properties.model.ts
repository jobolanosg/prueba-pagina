export interface WaterProperties {
  referencePressure?: number;
  volumetricFactor?: number;
  viscosity?: number;
  compressibility?: number;
  viscosityDependencePressure?: number;
}
