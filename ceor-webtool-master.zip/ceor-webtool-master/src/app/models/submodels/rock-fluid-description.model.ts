import { RockFluidDescriptionByFlowUnit } from './rock-fluid-description-by-flow-unit.model';
import { Simulations } from '../simulations.model';

export interface RockFluidDescription {
  simulations_id?: Simulations['_id'];
  rockFluidDescriptionByFlowUnit?: Array<RockFluidDescriptionByFlowUnit>;
}
