import { Mesh } from './mesh.model';
import { Simulations } from '../simulations.model';

export interface ReservoirDescription {
  simulations_id?: Simulations['_id'];
  mesh?: Mesh;
  poreCompressibility?: number;
  referencePressure?: number;
  matrixDensity?: number;
}
