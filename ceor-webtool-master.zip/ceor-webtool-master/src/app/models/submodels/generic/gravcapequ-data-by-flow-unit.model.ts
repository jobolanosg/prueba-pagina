export interface GravcapequDataByFlowUnit {
  referencePressure?: number;
  referenceDepth?: number;
  gasOilContactDepth?: number;
  oilWaterContactDepth?: number;
  oilResidualSaturationAtGasZone?: Boolean;
  oilResidualSaturationAtWaterzone?: Boolean;
}
