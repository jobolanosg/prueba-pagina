export interface Perforations {
  iIndex?: number;
  jIndex?: number;
  kIndex?: number;
}
