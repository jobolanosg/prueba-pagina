import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthService } from '../service/auth/auth.service';
import { Router } from '@angular/router';

import { Store } from '@ngxs/store';
import { UserState } from '../store/state/user.state';

@Injectable({
  providedIn: 'root'
})

export class AuthGuard implements CanActivate {

  constructor(private Auth: AuthService,
    private router: Router, private store: Store) {
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const token = this.store.selectSnapshot(UserState.getToken);
    if (token === null || token === undefined) {
      this.router.navigate(['']);
    }
    return true;
  }
}
